export interface CalendarBooking {
  id: string
  startTime: string // "14:00"
  endTime: string // "16:00"
  date: string // "2025-01-15"
  resourceId: string
  customer: {
    name: string
    phone: string
  }
  guests: number
  service: "Karaoke" | "Venue Hire" | "Event Tickets"
  status: "confirmed" | "pending" | "cancelled" | "completed"
  revenue: number
  notes?: string
}

export interface CalendarResource {
  id: string
  name: string
  type: "karaoke" | "venue" | "event"
  capacity: number
  color: string
}

// Mock resources
export const mockCalendarResources: CalendarResource[] = [
  {
    id: "karaoke-a",
    name: "Karaoke Room A",
    type: "karaoke",
    capacity: 8,
    color: "#f97316", // orange
  },
  {
    id: "karaoke-b",
    name: "Karaoke Room B",
    type: "karaoke",
    capacity: 6,
    color: "#f97316", // orange
  },
  {
    id: "karaoke-c",
    name: "Karaoke Room C",
    type: "karaoke",
    capacity: 10,
    color: "#f97316", // orange
  },
  {
    id: "main-venue",
    name: "Main Venue",
    type: "venue",
    capacity: 50,
    color: "#22c55e", // green
  },
]

// Mock calendar bookings for today
export const mockCalendarBookings: CalendarBooking[] = [
  {
    id: "cal-001",
    startTime: "10:00",
    endTime: "12:00",
    date: "2025-01-15",
    resourceId: "karaoke-a",
    customer: {
      name: "Sarah Johnson",
      phone: "+44 7123 456789",
    },
    guests: 4,
    service: "Karaoke",
    status: "confirmed",
    revenue: 60,
    notes: "Birthday party",
  },
  {
    id: "cal-002",
    startTime: "14:00",
    endTime: "17:00",
    date: "2025-01-15",
    resourceId: "karaoke-b",
    customer: {
      name: "Mike Chen",
      phone: "+44 7456 123789",
    },
    guests: 6,
    service: "Karaoke",
    status: "pending",
    revenue: 90,
  },
  {
    id: "cal-003",
    startTime: "12:30",
    endTime: "16:30",
    date: "2025-01-15",
    resourceId: "main-venue",
    customer: {
      name: "Tech Startup Ltd",
      phone: "+44 7987 654321",
    },
    guests: 25,
    service: "Venue Hire",
    status: "confirmed",
    revenue: 320,
    notes: "Corporate event with catering",
  },
  {
    id: "cal-004",
    startTime: "18:00",
    endTime: "21:00",
    date: "2025-01-15",
    resourceId: "karaoke-c",
    customer: {
      name: "David Brown",
      phone: "+44 7321 987654",
    },
    guests: 8,
    service: "Karaoke",
    status: "confirmed",
    revenue: 120,
  },
  {
    id: "cal-005",
    startTime: "19:00",
    endTime: "22:00",
    date: "2025-01-15",
    resourceId: "main-venue",
    customer: {
      name: "Birthday Party Co",
      phone: "+44 7654 321987",
    },
    guests: 15,
    service: "Venue Hire",
    status: "cancelled",
    revenue: 0,
    notes: "Cancelled due to illness",
  },
  {
    id: "cal-006",
    startTime: "15:00",
    endTime: "16:00",
    date: "2025-01-15",
    resourceId: "karaoke-a",
    customer: {
      name: "Emma Wilson",
      phone: "+44 7789 456123",
    },
    guests: 2,
    service: "Karaoke",
    status: "confirmed",
    revenue: 30,
  },
]

// Helper functions
export const getBookingsForDate = (date: string): CalendarBooking[] =>
  mockCalendarBookings.filter((booking) => booking.date === date)

export const getBookingsForResource = (resourceId: string, date: string): CalendarBooking[] =>
  mockCalendarBookings.filter((booking) => booking.resourceId === resourceId && booking.date === date)

export const generateTimeSlots = (): string[] => {
  const slots = []
  for (let hour = 10; hour <= 23; hour++) {
    slots.push(`${hour.toString().padStart(2, "0")}:00`)
  }
  return slots
}

export const formatTime = (time: string): string => {
  const [hours, minutes] = time.split(":")
  const hour = Number.parseInt(hours)
  const ampm = hour >= 12 ? "PM" : "AM"
  const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
  return `${displayHour}:${minutes} ${ampm}`
}

export const getTimeSlotPosition = (time: string): number => {
  const [hours] = time.split(":").map(Number)
  return hours - 10 // 10 AM is position 0
}

export const getBookingDuration = (startTime: string, endTime: string): number => {
  const [startHours, startMinutes] = startTime.split(":").map(Number)
  const [endHours, endMinutes] = endTime.split(":").map(Number)

  const startTotalMinutes = startHours * 60 + startMinutes
  const endTotalMinutes = endHours * 60 + endMinutes

  return (endTotalMinutes - startTotalMinutes) / 60 // Return hours
}
