"use client"

import type React from "react"
import { ChevronUp, ChevronDown, Eye, Plus, Phone, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Customer } from "@/mock-data/customers"

interface CustomersTableProps {
  customers: Customer[]
  onSort: (column: string) => void
  sortColumn: string
  sortOrder: "asc" | "desc"
  onViewProfile: (customerId: string) => void
  onCreateBooking: (customerId: string) => void
}

export function CustomersTable({
  customers,
  onSort,
  sortColumn,
  sortOrder,
  onViewProfile,
  onCreateBooking,
}: CustomersTableProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-GB", {
      style: "currency",
      currency: "GBP",
    }).format(amount)
  }

  const getStatusBadge = (status: Customer["status"]) => {
    const variants = {
      "first-time": "bg-blue-100 text-blue-800 border-blue-200",
      returning: "bg-green-100 text-green-800 border-green-200",
      vip: "bg-orange-100 text-orange-800 border-orange-200",
    }

    const labels = {
      "first-time": "First-time",
      returning: "Returning",
      vip: "VIP",
    }

    return (
      <Badge variant="outline" className={variants[status]}>
        {labels[status]}
      </Badge>
    )
  }

  const SortableHeader = ({ column, children }: { column: string; children: React.ReactNode }) => (
    <TableHead className="cursor-pointer hover:bg-stone-50 select-none" onClick={() => onSort(column)}>
      <div className="flex items-center space-x-1">
        <span>{children}</span>
        {sortColumn === column &&
          (sortOrder === "asc" ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />)}
      </div>
    </TableHead>
  )

  const handleViewProfile = (customer: Customer) => {
    onViewProfile(customer.id)
  }

  const handleNewBooking = (customer: Customer) => {
    onCreateBooking(customer.id)
  }

  return (
    <div className="border border-stone-200 rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-stone-50">
              <SortableHeader column="name">Customer</SortableHeader>
              <TableHead>Contact</TableHead>
              <SortableHeader column="totalBookings">Bookings</SortableHeader>
              <SortableHeader column="lastVisit">Last Visit</SortableHeader>
              <SortableHeader column="customerSince">Customer Since</SortableHeader>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {customers.map((customer) => (
              <TableRow key={customer.id} className="hover:bg-stone-50">
                <TableCell>
                  <div>
                    <div className="font-medium text-stone-900">
                      {customer.firstName} {customer.lastName}
                    </div>
                    <div className="text-sm text-stone-500">{formatCurrency(customer.totalSpent)} total spent</div>
                  </div>
                </TableCell>

                <TableCell>
                  <div className="space-y-1">
                    <div className="flex items-center text-sm text-stone-600">
                      <Mail className="h-3 w-3 mr-1" />
                      <span className="truncate max-w-48">{customer.email}</span>
                    </div>
                    <div className="flex items-center text-sm text-stone-600">
                      <Phone className="h-3 w-3 mr-1" />
                      <span>{customer.phone}</span>
                    </div>
                  </div>
                </TableCell>

                <TableCell>
                  <div>
                    <div className="font-medium">{customer.totalBookings}</div>
                    <div className="text-sm text-stone-500">Avg: {formatCurrency(customer.averageBookingValue)}</div>
                  </div>
                </TableCell>

                <TableCell>
                  {customer.lastVisit ? (
                    <div>
                      <div className="font-medium">{formatDate(customer.lastVisit)}</div>
                      <div className="text-sm text-stone-500">
                        {customer.preferredServices.slice(0, 2).join(", ")}
                        {customer.preferredServices.length > 2 && "..."}
                      </div>
                    </div>
                  ) : (
                    <span className="text-stone-400">Never</span>
                  )}
                </TableCell>

                <TableCell>
                  <div className="font-medium">{formatDate(customer.customerSince)}</div>
                </TableCell>

                <TableCell>{getStatusBadge(customer.status)}</TableCell>

                <TableCell className="text-right">
                  <div className="flex items-center justify-end space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewProfile(customer)}
                      className="text-stone-600 hover:text-stone-900"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      View
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleNewBooking(customer)}
                      className="text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Book
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {customers.length === 0 && (
        <div className="text-center py-12">
          <div className="text-stone-500 mb-2">No customers found</div>
          <div className="text-sm text-stone-400">Try adjusting your search or filters</div>
        </div>
      )}
    </div>
  )
}
