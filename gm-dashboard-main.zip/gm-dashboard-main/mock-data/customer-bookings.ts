export interface CustomerBooking {
  id: string
  customerId: string
  date: string
  startTime: string
  endTime: string
  service: "Karaoke" | "Venue Hire" | "Event Tickets"
  room: string
  guests: number
  amount: number
  status: "confirmed" | "completed" | "cancelled" | "no-show"
  notes?: string
  createdAt: string
}

// Generate detailed booking history for customers
export const generateCustomerBookings = (customerId: string, totalBookings: number): CustomerBooking[] => {
  const bookings: CustomerBooking[] = []
  const services: Array<"Karaoke" | "Venue Hire" | "Event Tickets"> = ["Karaoke", "Venue Hire", "Event Tickets"]
  const rooms = {
    Karaoke: ["Karaoke Room 1", "Karaoke Room 2", "Karaoke Room 3", "VIP Karaoke Suite"],
    "Venue Hire": ["Main Hall", "Conference Room A", "Conference Room B", "Rooftop Terrace"],
    "Event Tickets": ["Concert Hall", "Theater", "Exhibition Space", "Outdoor Stage"],
  }

  for (let i = 0; i < totalBookings; i++) {
    const service = services[Math.floor(Math.random() * services.length)]
    const roomOptions = rooms[service]
    const room = roomOptions[Math.floor(Math.random() * roomOptions.length)]

    // Generate dates going back in time
    const daysAgo = Math.floor(Math.random() * 365) + i * 30
    const bookingDate = new Date()
    bookingDate.setDate(bookingDate.getDate() - daysAgo)

    const startHour = Math.floor(Math.random() * 12) + 10 // 10 AM to 10 PM
    const duration = Math.floor(Math.random() * 4) + 1 // 1-4 hours
    const endHour = startHour + duration

    const guests = Math.floor(Math.random() * 20) + 2
    const basePrice = service === "Karaoke" ? 50 : service === "Venue Hire" ? 100 : 25
    const amount = basePrice * duration + guests * 5

    // Most bookings are completed, some confirmed, few cancelled
    let status: CustomerBooking["status"] = "completed"
    if (i < 2)
      status = "confirmed" // Recent bookings
    else if (Math.random() < 0.05) status = "cancelled"
    else if (Math.random() < 0.02) status = "no-show"

    bookings.push({
      id: `booking-${customerId}-${i + 1}`,
      customerId,
      date: bookingDate.toISOString().split("T")[0],
      startTime: `${startHour.toString().padStart(2, "0")}:00`,
      endTime: `${endHour.toString().padStart(2, "0")}:00`,
      service,
      room,
      guests,
      amount,
      status,
      notes: Math.random() < 0.3 ? "Special requirements noted" : undefined,
      createdAt: new Date(bookingDate.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
    })
  }

  return bookings.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

// Get customer booking statistics
export const getCustomerBookingStats = (bookings: CustomerBooking[]) => {
  const totalBookings = bookings.length
  const totalSpent = bookings.reduce((sum, booking) => sum + booking.amount, 0)
  const averageBookingValue = totalBookings > 0 ? totalSpent / totalBookings : 0

  // Find favorite service
  const serviceCounts = bookings.reduce(
    (acc, booking) => {
      acc[booking.service] = (acc[booking.service] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const favoriteService =
    Object.entries(serviceCounts).reduce((a, b) => (serviceCounts[a[0]] > serviceCounts[b[0]] ? a : b))?.[0] || "None"

  // Find most common booking time
  const hourCounts = bookings.reduce(
    (acc, booking) => {
      const hour = Number.parseInt(booking.startTime.split(":")[0])
      acc[hour] = (acc[hour] || 0) + 1
      return acc
    },
    {} as Record<number, number>,
  )

  const mostCommonHour = Object.entries(hourCounts).reduce((a, b) =>
    hourCounts[Number.parseInt(a[0])] > hourCounts[Number.parseInt(b[0])] ? a : b,
  )?.[0]

  const mostCommonTime = mostCommonHour ? `${mostCommonHour.padStart(2, "0")}:00` : "No pattern"

  // Find most common day of week
  const dayCounts = bookings.reduce(
    (acc, booking) => {
      const dayOfWeek = new Date(booking.date).getDay()
      acc[dayOfWeek] = (acc[dayOfWeek] || 0) + 1
      return acc
    },
    {} as Record<number, number>,
  )

  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
  const mostCommonDayIndex = Object.entries(dayCounts).reduce((a, b) =>
    dayCounts[Number.parseInt(a[0])] > dayCounts[Number.parseInt(b[0])] ? a : b,
  )?.[0]

  const mostCommonDay = mostCommonDayIndex ? dayNames[Number.parseInt(mostCommonDayIndex)] : "No pattern"

  return {
    totalBookings,
    totalSpent,
    averageBookingValue,
    favoriteService,
    mostCommonTime,
    mostCommonDay,
    completedBookings: bookings.filter((b) => b.status === "completed").length,
    cancelledBookings: bookings.filter((b) => b.status === "cancelled").length,
    noShowBookings: bookings.filter((b) => b.status === "no-show").length,
  }
}

// Mock function to get customer bookings
export const getCustomerBookings = (customerId: string): CustomerBooking[] => {
  // In a real app, this would fetch from an API
  // For now, we'll generate bookings based on the customer's total bookings from the customer data
  const customer = mockCustomers.find((c) => c.id === customerId)
  if (!customer) return []

  return generateCustomerBookings(customerId, customer.totalBookings)
}

// Import mockCustomers from the existing file
import { mockCustomers } from "./customers"
