"use client"

import type * as React from "react"
import { useRouter, usePathname } from "next/navigation"
import { Calendar, Home, Users, BarChart3, Settings, ChevronRight, Building2 } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const router = useRouter()
  const pathname = usePathname()

  // Navigation data structure for admin-only application
  const navigationData = {
    user: {
      name: "Sarah Johnson",
      email: "sarah@manor.com",
      avatar: "/placeholder.svg?height=32&width=32",
      role: "Venue Manager",
    },
    venues: [
      {
        name: "Manor",
        logo: "/favicon.png",
        plan: "Primary Venue",
      },
      {
        name: "Hippie Club",
        logo: "/placeholder.svg?height=32&width=32",
        plan: "Coming Soon",
      },
    ],
    navMain: [
      {
        title: "Dashboard",
        url: "/dashboard",
        icon: Home,
      },
      {
        title: "Customers",
        url: "/customers",
        icon: Users,
        // Remove the items array completely - no subitems needed
      },
      {
        title: "Calendar",
        url: "/calendar",
        icon: Calendar,
        items: [
          {
            title: "Calendar View",
            url: "/calendar",
          },
          {
            title: "Availability Management",
            url: "/calendar/availability",
          },
        ],
      },
      {
        title: "Bookings",
        url: "/bookings",
        icon: Calendar,
        items: [
          {
            title: "All Bookings",
            url: "/bookings",
          },
          {
            title: "Today's Schedule",
            url: "/bookings/today",
          },
          {
            title: "Create Booking",
            url: "/bookings/create",
          },
        ],
      },
      {
        title: "Reports",
        url: "/reports",
        icon: BarChart3,
        items: [
          {
            title: "Revenue Reports",
            url: "/reports/revenue",
          },
          {
            title: "Booking Analytics",
            url: "/reports/bookings",
          },
          {
            title: "Customer Insights",
            url: "/reports/customers",
          },
          {
            title: "Performance KPIs",
            url: "/reports/kpis",
          },
        ],
      },
      {
        title: "Settings",
        url: "/settings",
        icon: Settings,
        items: [
          {
            title: "Venue Settings",
            url: "/settings/venue",
          },
          {
            title: "Pricing Rules",
            url: "/settings/pricing",
          },
          {
            title: "Staff Management",
            url: "/settings/staff",
          },
          {
            title: "Integrations",
            url: "/settings/integrations",
          },
        ],
      },
    ],
  }

  const handleNavigation = (url: string) => {
    router.push(url)
  }

  const isItemActive = (item: any) => {
    if (item.items) {
      // For items with subitems, check if current path starts with the item's base URL
      return pathname.startsWith(item.url)
    }
    // For direct items, check exact match
    return pathname === item.url
  }

  const isSubItemActive = (subItem: any) => {
    return pathname === subItem.url
  }

  return (
    <Sidebar collapsible="icon" className="border-r" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton
                  size="lg"
                  className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                >
                  <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-orange-500 text-white">
                    <Building2 className="size-4" />
                  </div>
                  <div className="grid flex-1 text-left text-sm leading-tight min-w-0">
                    <span className="truncate font-semibold">{navigationData.venues[0].name}</span>
                    <span className="truncate text-xs text-sidebar-foreground/70">{navigationData.venues[0].plan}</span>
                  </div>
                  <ChevronRight className="ml-auto size-4" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
                align="start"
                side="bottom"
                sideOffset={4}
              >
                {navigationData.venues.map((venue, index) => (
                  <DropdownMenuItem
                    key={venue.name}
                    onClick={() => console.log("Switch to venue:", venue.name)}
                    className="gap-2 p-2"
                  >
                    <div className="flex size-6 items-center justify-center rounded-sm border bg-orange-500 text-white">
                      <Building2 className="size-4" />
                    </div>
                    <div className="grid flex-1 text-left text-sm leading-tight">
                      <span className="truncate font-semibold">{venue.name}</span>
                      <span className="truncate text-xs text-muted-foreground">{venue.plan}</span>
                    </div>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      <SidebarContent className="overflow-hidden">
        <SidebarGroup>
          <SidebarGroupLabel>Management</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationData.navMain.map((item) => (
                <Collapsible key={item.title} asChild defaultOpen={isItemActive(item)} className="group/collapsible">
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton
                        tooltip={item.title}
                        onClick={() => !item.items && handleNavigation(item.url)}
                        isActive={isItemActive(item)}
                        className="w-full"
                      >
                        {item.icon && <item.icon className="size-4 flex-shrink-0" />}
                        <span className="truncate">{item.title}</span>
                        {item.items && (
                          <ChevronRight className="ml-auto size-4 flex-shrink-0 transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                        )}
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    {item.items && (
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton asChild isActive={isSubItemActive(subItem)}>
                                <button onClick={() => handleNavigation(subItem.url)} className="w-full text-left">
                                  <span className="truncate">{subItem.title}</span>
                                </button>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    )}
                  </SidebarMenuItem>
                </Collapsible>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton
                  size="lg"
                  className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                >
                  <Avatar className="h-8 w-8 rounded-lg">
                    <AvatarImage
                      src={navigationData.user.avatar || "/placeholder.svg"}
                      alt={navigationData.user.name}
                    />
                    <AvatarFallback className="rounded-lg bg-orange-500 text-white">
                      {navigationData.user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="grid flex-1 text-left text-sm leading-tight min-w-0">
                    <span className="truncate font-semibold">{navigationData.user.name}</span>
                    <span className="truncate text-xs text-sidebar-foreground/70">{navigationData.user.role}</span>
                  </div>
                  <ChevronRight className="ml-auto size-4" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
                side="bottom"
                align="end"
                sideOffset={4}
              >
                <DropdownMenuItem onClick={() => console.log("View profile")}>
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => console.log("Account settings")}>
                  <span>Account Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => console.log("Notifications")}>
                  <span>Notifications</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => console.log("Sign out")}>
                  <span>Sign out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
