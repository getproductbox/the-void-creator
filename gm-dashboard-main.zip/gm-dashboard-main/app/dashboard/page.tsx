import { Calendar, DollarSign, Users } from "lucide-react"
import { MetricCard } from "./components/metric-card"
import { ScheduleTable } from "./components/schedule-table"
import { QuickActions } from "./components/quick-actions"
import { mockDashboardMetrics, mockTodaysBookings } from "../../mock-data/dashboard"

export default function Dashboard() {
  const metrics = mockDashboardMetrics
  const todaysBookings = mockTodaysBookings

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-stone-200 pb-4">
        <h1 className="text-3xl font-bold text-stone-900">Dashboard</h1>
        <p className="text-stone-600 mt-1">Welcome back! Here's what's happening at Manor today.</p>
      </div>

      {/* Quick Actions - Now positioned above metrics */}
      <QuickActions />

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Today's Bookings"
          value={metrics.todaysBookings.total}
          subtitle={`${metrics.todaysBookings.total} total reservations`}
          breakdown={[
            {
              label: "Karaoke",
              value: metrics.todaysBookings.breakdown.karaoke,
              color: "#f97316",
            },
            {
              label: "Venue Hire",
              value: metrics.todaysBookings.breakdown.venueHire,
              color: "#22c55e",
            },
            {
              label: "Event Tickets",
              value: metrics.todaysBookings.breakdown.tickets,
              color: "#3b82f6",
            },
          ]}
          icon={<Calendar className="h-4 w-4" />}
        />

        <MetricCard
          title="Today's Revenue"
          value={`£${metrics.todaysRevenue.amount.toFixed(2)}`}
          trend={{
            value: metrics.todaysRevenue.comparison.percentage,
            direction: metrics.todaysRevenue.comparison.trend,
            label: metrics.todaysRevenue.comparison.period,
          }}
          icon={<DollarSign className="h-4 w-4" />}
        />

        <MetricCard
          title="Current Occupancy"
          value={`${metrics.currentOccupancy.percentage}%`}
          subtitle={`${metrics.currentOccupancy.occupied} of ${metrics.currentOccupancy.total} rooms`}
          breakdown={[
            {
              label: "Available",
              value: metrics.currentOccupancy.roomsStatus.available,
              color: "#22c55e",
            },
            {
              label: "Occupied",
              value: metrics.currentOccupancy.roomsStatus.occupied,
              color: "#f97316",
            },
            {
              label: "Maintenance",
              value: metrics.currentOccupancy.roomsStatus.maintenance,
              color: "#ef4444",
            },
          ]}
          icon={<Users className="h-4 w-4" />}
        />
      </div>

      {/* Main Content Grid - Only Schedule Table now */}
      <div className="w-full">
        <ScheduleTable bookings={todaysBookings} />
      </div>
    </div>
  )
}
