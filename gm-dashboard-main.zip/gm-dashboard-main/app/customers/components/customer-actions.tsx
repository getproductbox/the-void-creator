"use client"

import { Plus, Mail, Edit, MoreHorizontal, Archive, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import type { Customer } from "@/mock-data/customers"

interface CustomerActionsProps {
  customer: Customer
  onCreateBooking: () => void
  onEditCustomer: () => void
  onSendEmail: () => void
  onArchiveCustomer: () => void
}

export function CustomerActions({
  customer,
  onCreateBooking,
  onEditCustomer,
  onSendEmail,
  onArchiveCustomer,
}: CustomerActionsProps) {
  return (
    <div className="space-y-4">
      {/* Primary Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Button onClick={onCreateBooking} className="bg-orange-500 hover:bg-orange-600 w-full">
          <Plus className="h-4 w-4 mr-2" />
          <span className="truncate">Create New Booking</span>
        </Button>
        <Button variant="outline" onClick={onEditCustomer} className="w-full">
          <Edit className="h-4 w-4 mr-2" />
          <span className="truncate">Edit Customer</span>
        </Button>
      </div>

      {/* Secondary Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button variant="outline" onClick={onSendEmail} className="flex-1">
          <Mail className="h-4 w-4 mr-2" />
          <span className="truncate">Send Email</span>
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="flex-1 sm:flex-none">
              <MoreHorizontal className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">More Actions</span>
              <span className="sm:hidden">More</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem onClick={() => console.log("View all bookings")}>
              <Users className="h-4 w-4 mr-2" />
              View All Bookings
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => console.log("Merge duplicate")}>
              <Users className="h-4 w-4 mr-2" />
              Merge Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onArchiveCustomer} className="text-red-600">
              <Archive className="h-4 w-4 mr-2" />
              Archive Customer
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
