"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function TypographyTestPage() {
  return (
    <div className="min-h-screen bg-stone-50 p-8">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Page Header */}
        <div className="text-center space-y-4">
          <h1 className="gm-heading-1 text-stone-900">Plus Jakarta Sans Typography Test</h1>
          <p className="gm-body-large text-stone-600 max-w-2xl mx-auto">
            This page demonstrates the Plus Jakarta Sans font family across all components and text elements in the GM
            platform design system.
          </p>
        </div>

        {/* Typography Hierarchy */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Typography Hierarchy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h1 className="gm-heading-1 text-stone-900">Heading 1 - ExtraBold 800</h1>
              <p className="gm-caption text-stone-500 mt-1">51px / 3.157rem</p>
            </div>
            <div>
              <h2 className="gm-heading-2 text-stone-900">Heading 2 - Bold 700</h2>
              <p className="gm-caption text-stone-500 mt-1">38px / 2.369rem</p>
            </div>
            <div>
              <h3 className="gm-heading-3 text-stone-900">Heading 3 - SemiBold 600</h3>
              <p className="gm-caption text-stone-500 mt-1">28px / 1.777rem</p>
            </div>
            <div>
              <h4 className="gm-heading-4 text-stone-900">Heading 4 - SemiBold 600</h4>
              <p className="gm-caption text-stone-500 mt-1">21px / 1.333rem</p>
            </div>
            <div>
              <p className="gm-body-large text-stone-900">
                Body Large - Regular 400 - Used for important content that needs more prominence
              </p>
              <p className="gm-caption text-stone-500 mt-1">18px / 1.125rem</p>
            </div>
            <div>
              <p className="gm-body text-stone-900">
                Body Text - Regular 400 - Standard body text used throughout the application
              </p>
              <p className="gm-caption text-stone-500 mt-1">16px / 1rem</p>
            </div>
            <div>
              <p className="gm-body-small text-stone-900">
                Body Small - Regular 400 - Secondary information and supporting details
              </p>
              <p className="gm-caption text-stone-500 mt-1">14px / 0.875rem</p>
            </div>
            <div>
              <p className="gm-caption text-stone-900">CAPTION - MEDIUM 500 - UPPERCASE</p>
              <p className="gm-caption text-stone-500 mt-1">12px / 0.75rem</p>
            </div>
          </CardContent>
        </Card>

        {/* Buttons */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Button Typography</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button size="lg">Large Button</Button>
              <Button>Default Button</Button>
              <Button size="sm">Small Button</Button>
              <Button variant="secondary">Secondary</Button>
              <Button variant="outline">Outline</Button>
              <Button variant="ghost">Ghost</Button>
            </div>
          </CardContent>
        </Card>

        {/* Form Elements */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Form Typography</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="font-medium">
                  Email Address
                </Label>
                <Input id="email" type="email" placeholder="Enter your email address" className="font-plus-jakarta" />
                <p className="gm-body-small text-stone-500">We'll never share your email with anyone else.</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="font-medium">
                  Phone Number
                </Label>
                <Input id="phone" type="tel" placeholder="+44 7123 456789" className="font-plus-jakarta" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message" className="font-medium">
                Message
              </Label>
              <Textarea
                id="message"
                placeholder="Enter your message here..."
                className="font-plus-jakarta min-h-[100px]"
              />
            </div>
          </CardContent>
        </Card>

        {/* Badges and Status */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Badges & Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <Badge variant="default">Default</Badge>
              <Badge variant="secondary">Secondary</Badge>
              <Badge variant="destructive">Error</Badge>
              <Badge variant="outline">Outline</Badge>
              <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Success</Badge>
              <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Warning</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Table Typography */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Table Typography</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-semibold">Customer Name</TableHead>
                  <TableHead className="font-semibold">Booking Date</TableHead>
                  <TableHead className="font-semibold">Room</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">John Smith</TableCell>
                  <TableCell>Jan 15, 2025</TableCell>
                  <TableCell>Karaoke Room A</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Confirmed</Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium">£45.00</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Sarah Johnson</TableCell>
                  <TableCell>Jan 16, 2025</TableCell>
                  <TableCell>Main Venue</TableCell>
                  <TableCell>
                    <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium">£120.00</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Font Weight Demonstration */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Font Weight Scale</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="font-light text-lg">Light 300 - Plus Jakarta Sans</p>
                <p className="font-normal text-lg">Regular 400 - Plus Jakarta Sans</p>
                <p className="font-medium text-lg">Medium 500 - Plus Jakarta Sans</p>
                <p className="font-semibold text-lg">SemiBold 600 - Plus Jakarta Sans</p>
              </div>
              <div>
                <p className="font-bold text-lg">Bold 700 - Plus Jakarta Sans</p>
                <p className="font-extrabold text-lg">ExtraBold 800 - Plus Jakarta Sans</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Readability Test */}
        <Card>
          <CardHeader>
            <CardTitle className="gm-heading-3">Readability Test</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="prose prose-stone max-w-none">
              <p className="gm-body-large">
                Plus Jakarta Sans is a versatile sans-serif typeface designed for excellent readability across digital
                interfaces. Its clean, modern letterforms provide optimal legibility at various sizes while maintaining
                a friendly, approachable character.
              </p>

              <p className="gm-body">
                The font family includes multiple weights from Light (300) to ExtraBold (800), offering designers
                flexibility in creating clear information hierarchies. The slightly rounded corners and balanced
                proportions make it particularly well-suited for user interface design and extended reading.
              </p>

              <p className="gm-body-small">
                In smaller sizes, Plus Jakarta Sans maintains excellent clarity thanks to its generous x-height and
                carefully crafted spacing. This makes it ideal for form labels, captions, and secondary information that
                users need to read quickly and accurately.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
