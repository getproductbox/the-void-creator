"use client"

import { Calendar, Clock, Users, DollarSign, ExternalLink } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"

interface BookingHistoryProps {
  bookings: any[]
  bookingStats: any
  onViewAllBookings: () => void
}

export function BookingHistory({ bookings, bookingStats, onViewAllBookings }: BookingHistoryProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "completed":
        return "bg-green-100 text-green-800 border-green-200"
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-200"
      case "no-show":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-stone-100 text-stone-800 border-stone-200"
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5) // Remove seconds
  }

  // Show last 10 bookings
  const recentBookings = bookings.slice(0, 10)

  return (
    <div className="space-y-4 lg:space-y-6">
      {/* Booking Statistics - Compact grid */}
      {bookingStats && (
        <div>
          <h3 className="text-base lg:text-lg font-semibold text-stone-900 mb-3 lg:mb-4">Booking Overview</h3>
          <div className="grid grid-cols-2 gap-2 lg:gap-3">
            <div className="bg-green-50 rounded-lg p-2 lg:p-3">
              <div className="flex items-center gap-1 lg:gap-2 mb-1">
                <Calendar className="h-3 w-3 text-green-600 shrink-0" />
                <span className="text-xs font-medium text-green-700 truncate">Completed</span>
              </div>
              <p className="text-base lg:text-lg font-bold text-green-900">{bookingStats.completedBookings}</p>
            </div>

            <div className="bg-red-50 rounded-lg p-2 lg:p-3">
              <div className="flex items-center gap-1 lg:gap-2 mb-1">
                <Calendar className="h-3 w-3 text-red-600 shrink-0" />
                <span className="text-xs font-medium text-red-700 truncate">Cancelled</span>
              </div>
              <p className="text-base lg:text-lg font-bold text-red-900">{bookingStats.cancelledBookings}</p>
            </div>
          </div>
        </div>
      )}

      <Separator />

      {/* Recent Bookings - Responsive layout */}
      <div>
        <div className="flex items-center justify-between mb-3 lg:mb-4">
          <h3 className="text-base lg:text-lg font-semibold text-stone-900">Recent Bookings</h3>
          {bookings.length > 10 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onViewAllBookings}
              className="text-orange-600 hover:text-orange-700 text-xs lg:text-sm h-8"
            >
              <span className="hidden sm:inline">View All ({bookings.length})</span>
              <span className="sm:hidden">All ({bookings.length})</span>
              <ExternalLink className="h-3 w-3 ml-1 shrink-0" />
            </Button>
          )}
        </div>

        {recentBookings.length === 0 ? (
          <div className="text-center py-6 lg:py-8">
            <Calendar className="h-10 w-10 lg:h-12 lg:w-12 text-stone-300 mx-auto mb-3 lg:mb-4" />
            <h4 className="text-stone-600 font-medium text-sm lg:text-base">No Booking History</h4>
            <p className="text-stone-500 text-xs lg:text-sm mt-1">This customer hasn't made any bookings yet.</p>
          </div>
        ) : (
          <div className="space-y-2 lg:space-y-3">
            {recentBookings.map((booking) => (
              <div
                key={booking.id}
                className="border border-stone-200 rounded-lg p-3 lg:p-4 hover:bg-stone-50 transition-colors"
              >
                <div className="flex items-start justify-between mb-2 lg:mb-3">
                  <div className="min-w-0 flex-1 mr-2">
                    <h4 className="font-medium text-stone-900 text-sm lg:text-base truncate">{booking.service}</h4>
                    <p className="text-xs lg:text-sm text-stone-600 truncate">{booking.room}</p>
                  </div>
                  <Badge className={`${getStatusColor(booking.status)} text-xs shrink-0`}>{booking.status}</Badge>
                </div>

                <div className="grid grid-cols-2 gap-2 lg:gap-4 text-xs lg:text-sm">
                  <div className="flex items-center gap-1 lg:gap-2 text-stone-600 min-w-0">
                    <Calendar className="h-3 w-3 shrink-0" />
                    <span className="truncate">{formatDate(booking.date)}</span>
                  </div>
                  <div className="flex items-center gap-1 lg:gap-2 text-stone-600 min-w-0">
                    <Clock className="h-3 w-3 shrink-0" />
                    <span className="truncate">
                      {formatTime(booking.startTime)} - {formatTime(booking.endTime)}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 lg:gap-2 text-stone-600 min-w-0">
                    <Users className="h-3 w-3 shrink-0" />
                    <span className="truncate">{booking.guests} guests</span>
                  </div>
                  <div className="flex items-center gap-1 lg:gap-2 text-stone-600 min-w-0">
                    <DollarSign className="h-3 w-3 shrink-0" />
                    <span className="truncate">£{booking.amount}</span>
                  </div>
                </div>

                {booking.notes && (
                  <div className="mt-2 lg:mt-3 pt-2 lg:pt-3 border-t border-stone-100">
                    <p className="text-xs text-stone-500 break-words">{booking.notes}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
