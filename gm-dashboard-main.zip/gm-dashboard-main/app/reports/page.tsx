export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <div className="border-b border-stone-200 pb-4">
        <h1 className="text-3xl font-bold text-stone-900">Reports & Analytics</h1>
        <p className="text-stone-600 mt-1">View performance metrics, revenue reports, and business insights.</p>
      </div>

      <div className="bg-white rounded-lg border border-stone-200 p-8 text-center">
        <h2 className="text-xl font-semibold text-stone-700 mb-2">Analytics Dashboard</h2>
        <p className="text-stone-500">This page will contain comprehensive reports and analytics.</p>
      </div>
    </div>
  )
}
