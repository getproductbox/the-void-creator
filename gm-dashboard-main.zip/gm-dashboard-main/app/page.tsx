import { redirect } from "next/navigation"

export default function HomePage() {
  // Redirect to dashboard since this is an admin-only app
  redirect("/dashboard")
}
