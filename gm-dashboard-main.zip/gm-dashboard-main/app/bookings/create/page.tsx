"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CreateBookingForm } from "./components/create-booking-form"
import { BookingSummary } from "./components/booking-summary"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export interface BookingFormData {
  // Customer Information
  customerName: string
  customerEmail: string
  customerPhone: string

  // Booking Details
  service: "Karaoke" | "Venue Hire" | "Event Tickets" | ""
  date: string
  startTime: string
  endTime: string
  duration: number
  guests: number
  room: string

  // Additional Information
  notes: string
  specialRequests: string

  // Pricing
  basePrice: number
  fees: Array<{ name: string; amount: number }>
  discount: number
  total: number
}

export default function CreateBookingPage() {
  const router = useRouter()
  const [formData, setFormData] = useState<BookingFormData>({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    service: "",
    date: "",
    startTime: "",
    endTime: "",
    duration: 2,
    guests: 1,
    room: "",
    notes: "",
    specialRequests: "",
    basePrice: 0,
    fees: [],
    discount: 0,
    total: 0,
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSummary, setShowSummary] = useState(false)

  const handleFormDataChange = (newData: Partial<BookingFormData>) => {
    setFormData((prev) => ({ ...prev, ...newData }))
  }

  const handlePreview = () => {
    setShowSummary(true)
  }

  const handleBackToForm = () => {
    setShowSummary(false)
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // In a real app, this would make an API call to create the booking
      console.log("Creating booking:", formData)

      // Redirect to bookings list with success message
      router.push("/bookings?created=true")
    } catch (error) {
      console.error("Error creating booking:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleBack = () => {
    router.back()
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={handleBack} className="p-2">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-stone-900">Create New Booking</h1>
          <p className="text-stone-600 mt-1">
            {showSummary ? "Review and confirm booking details" : "Fill in the booking information below"}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form Section */}
        <div className="lg:col-span-2">
          {!showSummary ? (
            <CreateBookingForm formData={formData} onFormDataChange={handleFormDataChange} onPreview={handlePreview} />
          ) : (
            <BookingSummary
              formData={formData}
              onBack={handleBackToForm}
              onSubmit={handleSubmit}
              isSubmitting={isSubmitting}
            />
          )}
        </div>

        {/* Sidebar - Booking Summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-6">
            {/* Quick Summary Card */}
            <div className="bg-white border border-stone-200 rounded-lg p-6 space-y-4">
              <h3 className="font-semibold text-stone-900">Booking Summary</h3>

              {formData.service && (
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-stone-600">Service:</span>
                    <span className="font-medium">{formData.service}</span>
                  </div>

                  {formData.date && (
                    <div className="flex justify-between">
                      <span className="text-stone-600">Date:</span>
                      <span className="font-medium">
                        {new Date(formData.date).toLocaleDateString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          year: "numeric",
                        })}
                      </span>
                    </div>
                  )}

                  {formData.startTime && formData.endTime && (
                    <div className="flex justify-between">
                      <span className="text-stone-600">Time:</span>
                      <span className="font-medium">
                        {formData.startTime} - {formData.endTime}
                      </span>
                    </div>
                  )}

                  {formData.guests > 0 && (
                    <div className="flex justify-between">
                      <span className="text-stone-600">Guests:</span>
                      <span className="font-medium">{formData.guests}</span>
                    </div>
                  )}

                  {formData.room && (
                    <div className="flex justify-between">
                      <span className="text-stone-600">Room:</span>
                      <span className="font-medium">{formData.room}</span>
                    </div>
                  )}

                  {formData.total > 0 && (
                    <>
                      <div className="border-t border-stone-200 pt-3">
                        <div className="flex justify-between font-semibold">
                          <span>Total:</span>
                          <span>£{formData.total.toFixed(2)}</span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}

              {!formData.service && (
                <p className="text-sm text-stone-500 italic">Fill in the form to see booking details</p>
              )}
            </div>

            {/* Help Card */}
            <div className="mt-6 bg-orange-50 border border-orange-200 rounded-lg p-4">
              <h4 className="font-medium text-orange-900 mb-2">Need Help?</h4>
              <p className="text-sm text-orange-800 mb-3">Having trouble creating a booking? Here are some tips:</p>
              <ul className="text-sm text-orange-800 space-y-1">
                <li>• Check room availability before selecting</li>
                <li>• Verify customer contact information</li>
                <li>• Add special requests in the notes section</li>
                <li>• Review pricing before confirming</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
