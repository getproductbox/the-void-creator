"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Settings, Users, Clock, Calendar, TrendingUp, Plus, Trash2 } from "lucide-react"
import {
  mockRoomSettings,
  generateTimeSlots,
  formatTime,
  type RoomSettings as RoomSettingsType,
} from "@/mock-data/availability"

interface RoomSettingsProps {
  onChanges: () => void
}

export function RoomSettings({ onChanges }: RoomSettingsProps) {
  const [roomSettings, setRoomSettings] = useState<RoomSettingsType[]>(mockRoomSettings)
  const timeSlots = generateTimeSlots()

  const handleSettingChange = (roomId: string, field: keyof RoomSettingsType, value: any) => {
    const updated = roomSettings.map((room) => (room.id === roomId ? { ...room, [field]: value } : room))
    setRoomSettings(updated)
    onChanges()
  }

  const handlePeakHourChange = (
    roomId: string,
    index: number,
    field: "startTime" | "endTime" | "multiplier",
    value: string | number,
  ) => {
    const updated = roomSettings.map((room) => {
      if (room.id === roomId) {
        const newPeakHours = [...room.priceModifiers.peakHours]
        newPeakHours[index] = { ...newPeakHours[index], [field]: value }
        return {
          ...room,
          priceModifiers: {
            ...room.priceModifiers,
            peakHours: newPeakHours,
          },
        }
      }
      return room
    })
    setRoomSettings(updated)
    onChanges()
  }

  const addPeakHour = (roomId: string) => {
    const updated = roomSettings.map((room) => {
      if (room.id === roomId) {
        return {
          ...room,
          priceModifiers: {
            ...room.priceModifiers,
            peakHours: [...room.priceModifiers.peakHours, { startTime: "18:00", endTime: "22:00", multiplier: 1.2 }],
          },
        }
      }
      return room
    })
    setRoomSettings(updated)
    onChanges()
  }

  const removePeakHour = (roomId: string, index: number) => {
    const updated = roomSettings.map((room) => {
      if (room.id === roomId) {
        const newPeakHours = room.priceModifiers.peakHours.filter((_, i) => i !== index)
        return {
          ...room,
          priceModifiers: {
            ...room.priceModifiers,
            peakHours: newPeakHours,
          },
        }
      }
      return room
    })
    setRoomSettings(updated)
    onChanges()
  }

  const getStatusColor = (status: RoomSettingsType["status"]) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "maintenance":
        return "bg-yellow-100 text-yellow-800"
      case "closed":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Room Settings
          </CardTitle>
          <CardDescription>Configure capacity, booking rules, and pricing for each room</CardDescription>
        </CardHeader>
      </Card>

      {/* Room Configuration Cards */}
      <div className="grid gap-6">
        {roomSettings.map((room) => (
          <Card key={room.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {room.name}
                    <Badge className={getStatusColor(room.status)}>{room.status}</Badge>
                  </CardTitle>
                  <CardDescription>Configure settings for {room.name.toLowerCase()}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Label htmlFor={`status-${room.id}`} className="text-sm">
                    Status:
                  </Label>
                  <Select value={room.status} onValueChange={(value) => handleSettingChange(room.id, "status", value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Basic Settings */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor={`capacity-${room.id}`} className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Capacity
                  </Label>
                  <Input
                    id={`capacity-${room.id}`}
                    type="number"
                    value={room.capacity}
                    onChange={(e) => handleSettingChange(room.id, "capacity", Number.parseInt(e.target.value))}
                    min="1"
                  />
                </div>
                <div>
                  <Label htmlFor={`min-duration-${room.id}`} className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Min Duration (hours)
                  </Label>
                  <Input
                    id={`min-duration-${room.id}`}
                    type="number"
                    value={room.minBookingDuration}
                    onChange={(e) =>
                      handleSettingChange(room.id, "minBookingDuration", Number.parseInt(e.target.value))
                    }
                    min="1"
                    step="0.5"
                  />
                </div>
                <div>
                  <Label htmlFor={`max-duration-${room.id}`} className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Max Duration (hours)
                  </Label>
                  <Input
                    id={`max-duration-${room.id}`}
                    type="number"
                    value={room.maxBookingDuration}
                    onChange={(e) =>
                      handleSettingChange(room.id, "maxBookingDuration", Number.parseInt(e.target.value))
                    }
                    min="1"
                  />
                </div>
                <div>
                  <Label htmlFor={`advance-limit-${room.id}`} className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Advance Booking (days)
                  </Label>
                  <Input
                    id={`advance-limit-${room.id}`}
                    type="number"
                    value={room.advanceBookingLimit}
                    onChange={(e) =>
                      handleSettingChange(room.id, "advanceBookingLimit", Number.parseInt(e.target.value))
                    }
                    min="1"
                  />
                </div>
              </div>

              <Separator />

              {/* Peak Hours Pricing */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <Label className="flex items-center gap-2 text-base font-medium">
                      <TrendingUp className="h-4 w-4" />
                      Peak Hours Pricing
                    </Label>
                    <p className="text-sm text-stone-600 mt-1">Set price multipliers for busy periods</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => addPeakHour(room.id)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Peak Hour
                  </Button>
                </div>

                <div className="space-y-3">
                  {room.priceModifiers.peakHours.map((peakHour, index) => (
                    <div key={index} className="flex items-center gap-4 p-3 border border-stone-200 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Label className="text-sm">From:</Label>
                        <Select
                          value={peakHour.startTime}
                          onValueChange={(value) => handlePeakHourChange(room.id, index, "startTime", value)}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {formatTime(time)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center gap-2">
                        <Label className="text-sm">To:</Label>
                        <Select
                          value={peakHour.endTime}
                          onValueChange={(value) => handlePeakHourChange(room.id, index, "endTime", value)}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {formatTime(time)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center gap-2">
                        <Label className="text-sm">Multiplier:</Label>
                        <Input
                          type="number"
                          value={peakHour.multiplier}
                          onChange={(e) =>
                            handlePeakHourChange(room.id, index, "multiplier", Number.parseFloat(e.target.value))
                          }
                          className="w-20"
                          min="1"
                          max="3"
                          step="0.1"
                        />
                        <span className="text-sm text-stone-600">×</span>
                      </div>

                      <Badge variant="secondary" className="ml-auto">
                        +{Math.round((peakHour.multiplier - 1) * 100)}%
                      </Badge>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removePeakHour(room.id, index)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}

                  {room.priceModifiers.peakHours.length === 0 && (
                    <div className="text-center py-4 text-stone-500">
                      <TrendingUp className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No peak hours configured</p>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
