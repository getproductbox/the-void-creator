"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Copy, RotateCcw, Clock } from "lucide-react"
import {
  mockOperatingHours,
  mockRoomSettings,
  generateTimeSlots,
  formatTime,
  type OperatingHours as OperatingHoursType,
} from "@/mock-data/availability"

interface OperatingHoursProps {
  onChanges: () => void
}

export function OperatingHours({ onChanges }: OperatingHoursProps) {
  const [operatingHours, setOperatingHours] = useState<OperatingHoursType[]>(mockOperatingHours)
  const [selectedRoom, setSelectedRoom] = useState<string>("main-venue")
  const timeSlots = generateTimeSlots()
  const rooms = [
    { id: "main-venue", name: "Main Venue" },
    ...mockRoomSettings.filter((room) => room.id !== "main-venue").map((room) => ({ id: room.id, name: room.name })),
  ]

  const handleDayToggle = (dayIndex: number, isOpen: boolean) => {
    const updated = [...operatingHours]
    updated[dayIndex].isOpen = isOpen
    setOperatingHours(updated)
    onChanges()
  }

  const handleTimeChange = (dayIndex: number, field: "openTime" | "closeTime", value: string) => {
    const updated = [...operatingHours]
    if (selectedRoom === "main-venue") {
      updated[dayIndex][field] = value
    } else {
      if (!updated[dayIndex].roomSpecific) {
        updated[dayIndex].roomSpecific = {}
      }
      if (!updated[dayIndex].roomSpecific![selectedRoom]) {
        updated[dayIndex].roomSpecific![selectedRoom] = {
          openTime: updated[dayIndex].openTime,
          closeTime: updated[dayIndex].closeTime,
          isOpen: updated[dayIndex].isOpen,
        }
      }
      updated[dayIndex].roomSpecific![selectedRoom][field] = value
    }
    setOperatingHours(updated)
    onChanges()
  }

  const handleRoomDayToggle = (dayIndex: number, isOpen: boolean) => {
    const updated = [...operatingHours]
    if (!updated[dayIndex].roomSpecific) {
      updated[dayIndex].roomSpecific = {}
    }
    if (!updated[dayIndex].roomSpecific![selectedRoom]) {
      updated[dayIndex].roomSpecific![selectedRoom] = {
        openTime: updated[dayIndex].openTime,
        closeTime: updated[dayIndex].closeTime,
        isOpen: updated[dayIndex].isOpen,
      }
    }
    updated[dayIndex].roomSpecific![selectedRoom].isOpen = isOpen
    setOperatingHours(updated)
    onChanges()
  }

  const copyToAllDays = () => {
    const firstDay = operatingHours[0]
    const updated = operatingHours.map((day) => ({
      ...day,
      isOpen: firstDay.isOpen,
      openTime: firstDay.openTime,
      closeTime: firstDay.closeTime,
      roomSpecific:
        selectedRoom !== "main-venue"
          ? {
              ...day.roomSpecific,
              [selectedRoom]: firstDay.roomSpecific?.[selectedRoom] || {
                openTime: firstDay.openTime,
                closeTime: firstDay.closeTime,
                isOpen: firstDay.isOpen,
              },
            }
          : day.roomSpecific,
    }))
    setOperatingHours(updated)
    onChanges()
  }

  const resetToDefault = () => {
    setOperatingHours(mockOperatingHours)
    onChanges()
  }

  const getCurrentHours = (day: OperatingHoursType) => {
    if (selectedRoom === "main-venue") {
      return {
        isOpen: day.isOpen,
        openTime: day.openTime,
        closeTime: day.closeTime,
      }
    }
    return (
      day.roomSpecific?.[selectedRoom] || {
        isOpen: day.isOpen,
        openTime: day.openTime,
        closeTime: day.closeTime,
      }
    )
  }

  return (
    <div className="space-y-6">
      {/* Room Selector */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Operating Hours
              </CardTitle>
              <CardDescription>Set opening and closing times for each day of the week</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedRoom} onValueChange={setSelectedRoom}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {rooms.map((room) => (
                    <SelectItem key={room.id} value={room.id}>
                      {room.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-6">
            <Button variant="outline" size="sm" onClick={copyToAllDays}>
              <Copy className="h-4 w-4 mr-2" />
              Copy Monday to All Days
            </Button>
            <Button variant="outline" size="sm" onClick={resetToDefault}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset to Default
            </Button>
          </div>

          <div className="space-y-4">
            {operatingHours.map((day, index) => {
              const currentHours = getCurrentHours(day)
              return (
                <div key={day.day} className="flex items-center gap-4 p-4 border border-stone-200 rounded-lg">
                  <div className="w-24">
                    <span className="font-medium text-stone-900">{day.day}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Switch
                      checked={currentHours.isOpen}
                      onCheckedChange={(checked) =>
                        selectedRoom === "main-venue"
                          ? handleDayToggle(index, checked)
                          : handleRoomDayToggle(index, checked)
                      }
                    />
                    <span className="text-sm text-stone-600">{currentHours.isOpen ? "Open" : "Closed"}</span>
                  </div>

                  {currentHours.isOpen && (
                    <>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-stone-600">From:</span>
                        <Select
                          value={currentHours.openTime}
                          onValueChange={(value) => handleTimeChange(index, "openTime", value)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {formatTime(time)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-sm text-stone-600">To:</span>
                        <Select
                          value={currentHours.closeTime}
                          onValueChange={(value) => handleTimeChange(index, "closeTime", value)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time} value={time}>
                                {formatTime(time)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <Badge variant="secondary" className="ml-auto">
                        {(() => {
                          const open = Number.parseInt(currentHours.openTime.split(":")[0])
                          const close = Number.parseInt(currentHours.closeTime.split(":")[0])
                          const hours = close >= open ? close - open : 24 - open + close
                          return `${hours}h open`
                        })()}
                      </Badge>
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
