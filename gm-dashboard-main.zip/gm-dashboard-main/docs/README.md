docs/
├── README.md                           # This file
├── product/                           # Product-related documentation
│   ├── product-requirements.md        # Product Requirements Document (PRD)
│   ├── design-spec.md                # UX/UI Design System Specification
│   ├── business-logic.md             # Core business rules and logic
│   └── user-flows.md                 # User journey and flow documentation
└── technical/                        # Technical documentation
    ├── api-specification.md          # API endpoints and specifications
    ├── entity-relationship-diagram.md # Database ERD and schema documentation
    ├── system-architecture.md        # High-level system architecture
    └── technical-decisions.md        # Architecture decisions and rationale
