"use client"

import { Users, UserPlus, TrendingUp } from "lucide-react"

interface CustomerStatsProps {
  totalCustomers: number
  newThisMonth: number
  returningRate: number
}

export function CustomerStats({ totalCustomers, newThisMonth, returningRate }: CustomerStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Total Customers */}
      <div className="bg-white rounded-lg border border-stone-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-stone-600">Total Customers</p>
            <p className="text-3xl font-bold text-stone-900 mt-2">{totalCustomers}</p>
            <p className="text-sm text-stone-500 mt-1">Active customer database</p>
          </div>
          <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
        </div>
      </div>

      {/* New This Month */}
      <div className="bg-white rounded-lg border border-stone-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-stone-600">New This Month</p>
            <p className="text-3xl font-bold text-green-900 mt-2">{newThisMonth}</p>
            <p className="text-sm text-stone-500 mt-1">First-time customers</p>
          </div>
          <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
            <UserPlus className="h-6 w-6 text-green-600" />
          </div>
        </div>
      </div>

      {/* Returning Rate */}
      <div className="bg-white rounded-lg border border-stone-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-stone-600">Returning Rate</p>
            <p className="text-3xl font-bold text-orange-900 mt-2">{returningRate}%</p>
            <p className="text-sm text-stone-500 mt-1">Customer retention</p>
          </div>
          <div className="h-12 w-12 bg-orange-100 rounded-lg flex items-center justify-center">
            <TrendingUp className="h-6 w-6 text-orange-600" />
          </div>
        </div>
      </div>
    </div>
  )
}
