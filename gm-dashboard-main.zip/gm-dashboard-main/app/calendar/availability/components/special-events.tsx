"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CalendarDays, Plus, Trash2, User, Mail, Phone, Repeat } from "lucide-react"
import { mockSpecialEvents, mockRoomSettings, type SpecialEvent } from "@/mock-data/availability"

interface SpecialEventsProps {
  onChanges: () => void
}

export function SpecialEvents({ onChanges }: SpecialEventsProps) {
  const [specialEvents, setSpecialEvents] = useState<SpecialEvent[]>(mockSpecialEvents)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newEvent, setNewEvent] = useState<Partial<SpecialEvent>>({
    title: "",
    affectedRooms: [],
    contactName: "",
    contactEmail: "",
    contactPhone: "",
    notes: "",
  })

  const rooms = [
    { id: "main-venue", name: "Main Venue" },
    ...mockRoomSettings.filter((room) => room.id !== "main-venue").map((room) => ({ id: room.id, name: room.name })),
  ]

  const handleAddEvent = () => {
    if (
      !newEvent.title ||
      !newEvent.startDate ||
      !newEvent.startTime ||
      !newEvent.endTime ||
      !newEvent.affectedRooms?.length
    ) {
      return
    }

    const event: SpecialEvent = {
      id: Date.now().toString(),
      title: newEvent.title!,
      startDate: newEvent.startDate!,
      endDate: newEvent.endDate || newEvent.startDate!,
      startTime: newEvent.startTime!,
      endTime: newEvent.endTime!,
      affectedRooms: newEvent.affectedRooms!,
      contactName: newEvent.contactName!,
      contactEmail: newEvent.contactEmail!,
      contactPhone: newEvent.contactPhone!,
      notes: newEvent.notes,
      isRecurring: newEvent.isRecurring,
      recurringPattern: newEvent.recurringPattern,
    }

    setSpecialEvents([...specialEvents, event])
    setNewEvent({
      title: "",
      affectedRooms: [],
      contactName: "",
      contactEmail: "",
      contactPhone: "",
      notes: "",
    })
    setShowAddForm(false)
    onChanges()
  }

  const handleDeleteEvent = (id: string) => {
    setSpecialEvents(specialEvents.filter((e) => e.id !== id))
    onChanges()
  }

  const handleRoomToggle = (roomId: string, checked: boolean) => {
    const currentRooms = newEvent.affectedRooms || []
    if (checked) {
      setNewEvent({
        ...newEvent,
        affectedRooms: [...currentRooms, roomId],
      })
    } else {
      setNewEvent({
        ...newEvent,
        affectedRooms: currentRooms.filter((id) => id !== roomId),
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
    return `${displayHour}:${minutes} ${ampm}`
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                Special Events
              </CardTitle>
              <CardDescription>Manage private events and corporate bookings that affect availability</CardDescription>
            </div>
            <Button onClick={() => setShowAddForm(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Special Event
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Add Event Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Special Event</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="event-title">Event Title</Label>
              <Input
                id="event-title"
                value={newEvent.title || ""}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                placeholder="e.g., Corporate Team Building Event"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start-date">Start Date</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={newEvent.startDate || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, startDate: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="end-date">End Date</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={newEvent.endDate || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, endDate: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start-time">Start Time</Label>
                <Input
                  id="start-time"
                  type="time"
                  value={newEvent.startTime || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="end-time">End Time</Label>
                <Input
                  id="end-time"
                  type="time"
                  value={newEvent.endTime || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
                />
              </div>
            </div>

            <div>
              <Label>Affected Rooms</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {rooms.map((room) => (
                  <div key={room.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`event-${room.id}`}
                      checked={newEvent.affectedRooms?.includes(room.id)}
                      onCheckedChange={(checked) => handleRoomToggle(room.id, checked as boolean)}
                    />
                    <Label htmlFor={`event-${room.id}`} className="text-sm">
                      {room.name}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="contact-name">Contact Name</Label>
                <Input
                  id="contact-name"
                  value={newEvent.contactName || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, contactName: e.target.value })}
                  placeholder="John Smith"
                />
              </div>
              <div>
                <Label htmlFor="contact-email">Contact Email</Label>
                <Input
                  id="contact-email"
                  type="email"
                  value={newEvent.contactEmail || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, contactEmail: e.target.value })}
                  placeholder="john@company.com"
                />
              </div>
              <div>
                <Label htmlFor="contact-phone">Contact Phone</Label>
                <Input
                  id="contact-phone"
                  type="tel"
                  value={newEvent.contactPhone || ""}
                  onChange={(e) => setNewEvent({ ...newEvent, contactPhone: e.target.value })}
                  placeholder="+44 20 7123 4567"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="event-notes">Notes</Label>
              <Textarea
                id="event-notes"
                value={newEvent.notes || ""}
                onChange={(e) => setNewEvent({ ...newEvent, notes: e.target.value })}
                placeholder="Additional details about the event..."
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="event-recurring"
                checked={newEvent.isRecurring || false}
                onCheckedChange={(checked) => setNewEvent({ ...newEvent, isRecurring: checked as boolean })}
              />
              <Label htmlFor="event-recurring">Recurring event</Label>
            </div>

            {newEvent.isRecurring && (
              <div>
                <Label htmlFor="recurring-pattern">Recurring Pattern</Label>
                <Select
                  value={newEvent.recurringPattern}
                  onValueChange={(value) =>
                    setNewEvent({ ...newEvent, recurringPattern: value as SpecialEvent["recurringPattern"] })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select pattern" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={handleAddEvent}>Add Event</Button>
              <Button variant="outline" onClick={() => setShowAddForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Events List */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Special Events</CardTitle>
        </CardHeader>
        <CardContent>
          {specialEvents.length === 0 ? (
            <div className="text-center py-8 text-stone-500">
              <CalendarDays className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No special events scheduled</p>
            </div>
          ) : (
            <div className="space-y-4">
              {specialEvents.map((event) => (
                <div key={event.id} className="border border-stone-200 rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-stone-900">{event.title}</h3>
                        {event.isRecurring && (
                          <Badge variant="outline" className="flex items-center gap-1">
                            <Repeat className="h-3 w-3" />
                            {event.recurringPattern}
                          </Badge>
                        )}
                      </div>

                      <div className="flex items-center gap-4 text-sm text-stone-600 mb-3">
                        <span>
                          {formatDate(event.startDate)}
                          {event.endDate !== event.startDate && ` - ${formatDate(event.endDate)}`}
                        </span>
                        <span>
                          {formatTime(event.startTime)} - {formatTime(event.endTime)}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-sm text-stone-600">Rooms:</span>
                        {event.affectedRooms.map((roomId) => {
                          const room = rooms.find((r) => r.id === roomId)
                          return (
                            <Badge key={roomId} variant="secondary" className="text-xs">
                              {room?.name}
                            </Badge>
                          )
                        })}
                      </div>

                      <div className="space-y-1 text-sm">
                        <div className="flex items-center gap-2 text-stone-600">
                          <User className="h-4 w-4" />
                          <span>{event.contactName}</span>
                        </div>
                        <div className="flex items-center gap-2 text-stone-600">
                          <Mail className="h-4 w-4" />
                          <span>{event.contactEmail}</span>
                        </div>
                        <div className="flex items-center gap-2 text-stone-600">
                          <Phone className="h-4 w-4" />
                          <span>{event.contactPhone}</span>
                        </div>
                      </div>

                      {event.notes && (
                        <p className="text-sm text-stone-600 mt-2 p-2 bg-stone-50 rounded">{event.notes}</p>
                      )}
                    </div>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteEvent(event.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
