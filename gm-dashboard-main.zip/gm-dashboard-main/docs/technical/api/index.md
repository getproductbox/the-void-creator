# API Documentation

This directory contains all API documentation for the application.

## Structure

- **endpoints/**: Individual endpoint documentation
- **schemas/**: Data model schemas
- **examples/**: Code examples and tutorials
- **changelog/**: API version changes and updates

## Documentation Standards

1. Use the [API documentation template](../../templates/api-doc-template.md)
2. Include request/response examples
3. Document all parameters and their types
4. Provide error handling information
5. Keep documentation in sync with code changes

## Tools

- **OpenAPI/Swagger**: For interactive API documentation
- **Postman Collections**: For API testing
- **Code Examples**: In multiple programming languages
