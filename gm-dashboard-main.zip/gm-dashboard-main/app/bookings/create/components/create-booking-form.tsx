"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Clock, Users, MapPin, FileText, AlertCircle } from "lucide-react"
import type { BookingFormData } from "../page"

interface CreateBookingFormProps {
  formData: BookingFormData
  onFormDataChange: (data: Partial<BookingFormData>) => void
  onPreview: () => void
}

interface FormErrors {
  [key: string]: string
}

// Mock data for rooms and pricing
const roomsByService = {
  Karaoke: [
    { id: "karaoke-a", name: "Karaoke Room A", capacity: 8, hourlyRate: 30 },
    { id: "karaoke-b", name: "Karaoke Room B", capacity: 6, hourlyRate: 25 },
    { id: "karaoke-c", name: "Karaoke Room C", capacity: 10, hourlyRate: 35 },
  ],
  "Venue Hire": [
    { id: "main-hall", name: "Main Hall", capacity: 50, hourlyRate: 80 },
    { id: "private-room", name: "Private Room", capacity: 30, hourlyRate: 60 },
  ],
  "Event Tickets": [{ id: "general", name: "General Admission", capacity: 100, hourlyRate: 15 }],
}

export function CreateBookingForm({ formData, onFormDataChange, onPreview }: CreateBookingFormProps) {
  const [errors, setErrors] = useState<FormErrors>({})
  const [availableRooms, setAvailableRooms] = useState<any[]>([])

  // Update available rooms when service changes
  useEffect(() => {
    if (formData.service && formData.service in roomsByService) {
      setAvailableRooms(roomsByService[formData.service as keyof typeof roomsByService])
      // Reset room selection when service changes
      onFormDataChange({ room: "", basePrice: 0, total: 0 })
    } else {
      setAvailableRooms([])
    }
  }, [formData.service])

  // Calculate pricing when relevant fields change
  useEffect(() => {
    if (formData.room && formData.duration > 0) {
      const selectedRoom = availableRooms.find((room) => room.id === formData.room)
      if (selectedRoom) {
        const basePrice = selectedRoom.hourlyRate * formData.duration
        const serviceFee = basePrice * 0.1 // 10% service fee
        const fees = [{ name: "Service fee", amount: serviceFee }]
        const total = basePrice + serviceFee - formData.discount

        onFormDataChange({
          basePrice,
          fees,
          total: Math.max(0, total),
        })
      }
    }
  }, [formData.room, formData.duration, formData.discount, availableRooms])

  const validateField = (name: string, value: any): string => {
    switch (name) {
      case "customerName":
        return !value ? "Customer name is required" : ""
      case "customerEmail":
        if (!value) return "Email is required"
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        return !emailRegex.test(value) ? "Please enter a valid email address" : ""
      case "customerPhone":
        if (!value) return "Phone number is required"
        const phoneRegex = /^(\+44|0)[0-9]{10}$/
        return !phoneRegex.test(value.replace(/\s/g, "")) ? "Please enter a valid UK phone number" : ""
      case "service":
        return !value ? "Please select a service" : ""
      case "date":
        if (!value) return "Date is required"
        const selectedDate = new Date(value)
        const today = new Date()
        today.setHours(0, 0, 0, 0)
        return selectedDate < today ? "Date cannot be in the past" : ""
      case "startTime":
        return !value ? "Start time is required" : ""
      case "endTime":
        if (!value) return "End time is required"
        if (formData.startTime && value <= formData.startTime) {
          return "End time must be after start time"
        }
        return ""
      case "guests":
        if (!value || value < 1) return "At least 1 guest is required"
        const selectedRoom = availableRooms.find((room) => room.id === formData.room)
        if (selectedRoom && value > selectedRoom.capacity) {
          return `Maximum ${selectedRoom.capacity} guests for this room`
        }
        return ""
      case "room":
        return !value ? "Please select a room" : ""
      default:
        return ""
    }
  }

  const handleFieldChange = (name: string, value: any) => {
    // Update form data
    onFormDataChange({ [name]: value })

    // Validate field and update errors
    const error = validateField(name, value)
    setErrors((prev) => ({
      ...prev,
      [name]: error,
    }))

    // Special handling for time fields to calculate duration
    if (name === "startTime" || name === "endTime") {
      const startTime = name === "startTime" ? value : formData.startTime
      const endTime = name === "endTime" ? value : formData.endTime

      if (startTime && endTime) {
        const start = new Date(`2000-01-01T${startTime}:00`)
        const end = new Date(`2000-01-01T${endTime}:00`)
        const durationHours = (end.getTime() - start.getTime()) / (1000 * 60 * 60)

        if (durationHours > 0) {
          onFormDataChange({ duration: durationHours })
        }
      }
    }
  }

  const validateForm = (): boolean => {
    const requiredFields = [
      "customerName",
      "customerEmail",
      "customerPhone",
      "service",
      "date",
      "startTime",
      "endTime",
      "guests",
      "room",
    ]

    const newErrors: FormErrors = {}
    let isValid = true

    requiredFields.forEach((field) => {
      const error = validateField(field, formData[field as keyof BookingFormData])
      if (error) {
        newErrors[field] = error
        isValid = false
      }
    })

    setErrors(newErrors)
    return isValid
  }

  const handlePreview = () => {
    if (validateForm()) {
      onPreview()
    }
  }

  const getTomorrowDate = () => {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    return tomorrow.toISOString().split("T")[0]
  }

  return (
    <div className="space-y-6">
      {/* Customer Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Customer Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerName">Full Name *</Label>
              <Input
                id="customerName"
                value={formData.customerName}
                onChange={(e) => handleFieldChange("customerName", e.target.value)}
                placeholder="Enter customer's full name"
                className={errors.customerName ? "border-red-500" : ""}
              />
              {errors.customerName && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.customerName}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerPhone">Phone Number *</Label>
              <Input
                id="customerPhone"
                type="tel"
                value={formData.customerPhone}
                onChange={(e) => handleFieldChange("customerPhone", e.target.value)}
                placeholder="+44 7123 456789"
                className={errors.customerPhone ? "border-red-500" : ""}
              />
              {errors.customerPhone && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.customerPhone}
                </p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="customerEmail">Email Address *</Label>
            <Input
              id="customerEmail"
              type="email"
              value={formData.customerEmail}
              onChange={(e) => handleFieldChange("customerEmail", e.target.value)}
              placeholder="customer@example.com"
              className={errors.customerEmail ? "border-red-500" : ""}
            />
            {errors.customerEmail && (
              <p className="text-sm text-red-600 flex items-center gap-1">
                <AlertCircle className="h-4 w-4" />
                {errors.customerEmail}
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Booking Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Booking Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="service">Service Type *</Label>
              <Select value={formData.service} onValueChange={(value) => handleFieldChange("service", value)}>
                <SelectTrigger className={errors.service ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select a service" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Karaoke">Karaoke</SelectItem>
                  <SelectItem value="Venue Hire">Venue Hire</SelectItem>
                  <SelectItem value="Event Tickets">Event Tickets</SelectItem>
                </SelectContent>
              </Select>
              {errors.service && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.service}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleFieldChange("date", e.target.value)}
                min={getTomorrowDate()}
                className={errors.date ? "border-red-500" : ""}
              />
              {errors.date && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.date}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime">Start Time *</Label>
              <Input
                id="startTime"
                type="time"
                value={formData.startTime}
                onChange={(e) => handleFieldChange("startTime", e.target.value)}
                className={errors.startTime ? "border-red-500" : ""}
              />
              {errors.startTime && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.startTime}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="endTime">End Time *</Label>
              <Input
                id="endTime"
                type="time"
                value={formData.endTime}
                onChange={(e) => handleFieldChange("endTime", e.target.value)}
                className={errors.endTime ? "border-red-500" : ""}
              />
              {errors.endTime && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.endTime}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="guests">Number of Guests *</Label>
              <Input
                id="guests"
                type="number"
                min="1"
                value={formData.guests}
                onChange={(e) => handleFieldChange("guests", Number.parseInt(e.target.value) || 0)}
                className={errors.guests ? "border-red-500" : ""}
              />
              {errors.guests && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.guests}
                </p>
              )}
            </div>
          </div>

          {formData.duration > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800 flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Duration: {formData.duration} hour{formData.duration !== 1 ? "s" : ""}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Room Selection */}
      {availableRooms.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Room Selection
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="room">Available Rooms *</Label>
              <Select value={formData.room} onValueChange={(value) => handleFieldChange("room", value)}>
                <SelectTrigger className={errors.room ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select a room" />
                </SelectTrigger>
                <SelectContent>
                  {availableRooms.map((room) => (
                    <SelectItem key={room.id} value={room.id}>
                      {room.name} (Capacity: {room.capacity}, £{room.hourlyRate}/hour)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.room && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="h-4 w-4" />
                  {errors.room}
                </p>
              )}
            </div>

            {formData.room && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <p className="text-sm text-green-800">
                  Room selected: {availableRooms.find((r) => r.id === formData.room)?.name}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Additional Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Additional Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="notes">Booking Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleFieldChange("notes", e.target.value)}
              placeholder="Any additional notes about this booking..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="specialRequests">Special Requests</Label>
            <Textarea
              id="specialRequests"
              value={formData.specialRequests}
              onChange={(e) => handleFieldChange("specialRequests", e.target.value)}
              placeholder="Special dietary requirements, accessibility needs, equipment requests, etc."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-end gap-4">
        <Button variant="outline" onClick={() => window.history.back()}>
          Cancel
        </Button>
        <Button
          onClick={handlePreview}
          className="bg-orange-500 hover:bg-orange-600"
          disabled={!formData.service || !formData.customerName}
        >
          Review Booking
        </Button>
      </div>
    </div>
  )
}
