export interface OperatingHours {
  day: string
  isOpen: boolean
  openTime: string
  closeTime: string
  roomSpecific?: {
    [roomId: string]: {
      openTime: string
      closeTime: string
      isOpen: boolean
    }
  }
}

export interface BlackoutDate {
  id: string
  date: string
  endDate?: string
  reason: string
  type: "maintenance" | "private-event" | "holiday" | "other"
  affectedRooms: string[]
  notes?: string
  isRecurring?: boolean
  recurringPattern?: "weekly" | "monthly" | "yearly"
}

export interface RoomSettings {
  id: string
  name: string
  capacity: number
  minBookingDuration: number // in hours
  maxBookingDuration: number // in hours
  advanceBookingLimit: number // in days
  status: "active" | "maintenance" | "closed"
  priceModifiers: {
    peakHours: {
      startTime: string
      endTime: string
      multiplier: number
    }[]
  }
}

export interface SpecialEvent {
  id: string
  title: string
  startDate: string
  endDate: string
  startTime: string
  endTime: string
  affectedRooms: string[]
  contactName: string
  contactEmail: string
  contactPhone: string
  notes?: string
  isRecurring?: boolean
  recurringPattern?: "weekly" | "monthly"
}

// Mock data
export const mockOperatingHours: OperatingHours[] = [
  {
    day: "Monday",
    isOpen: true,
    openTime: "12:00",
    closeTime: "23:00",
    roomSpecific: {
      "room-1": { openTime: "12:00", closeTime: "23:00", isOpen: true },
      "room-2": { openTime: "14:00", closeTime: "23:00", isOpen: true },
      "room-3": { openTime: "12:00", closeTime: "22:00", isOpen: true },
    },
  },
  {
    day: "Tuesday",
    isOpen: true,
    openTime: "12:00",
    closeTime: "23:00",
    roomSpecific: {
      "room-1": { openTime: "12:00", closeTime: "23:00", isOpen: true },
      "room-2": { openTime: "14:00", closeTime: "23:00", isOpen: true },
      "room-3": { openTime: "12:00", closeTime: "22:00", isOpen: true },
    },
  },
  {
    day: "Wednesday",
    isOpen: true,
    openTime: "12:00",
    closeTime: "23:00",
    roomSpecific: {
      "room-1": { openTime: "12:00", closeTime: "23:00", isOpen: true },
      "room-2": { openTime: "14:00", closeTime: "23:00", isOpen: true },
      "room-3": { openTime: "12:00", closeTime: "22:00", isOpen: true },
    },
  },
  {
    day: "Thursday",
    isOpen: true,
    openTime: "12:00",
    closeTime: "00:00",
    roomSpecific: {
      "room-1": { openTime: "12:00", closeTime: "00:00", isOpen: true },
      "room-2": { openTime: "14:00", closeTime: "00:00", isOpen: true },
      "room-3": { openTime: "12:00", closeTime: "23:00", isOpen: true },
    },
  },
  {
    day: "Friday",
    isOpen: true,
    openTime: "12:00",
    closeTime: "01:00",
    roomSpecific: {
      "room-1": { openTime: "12:00", closeTime: "01:00", isOpen: true },
      "room-2": { openTime: "14:00", closeTime: "01:00", isOpen: true },
      "room-3": { openTime: "12:00", closeTime: "00:00", isOpen: true },
    },
  },
  {
    day: "Saturday",
    isOpen: true,
    openTime: "11:00",
    closeTime: "01:00",
    roomSpecific: {
      "room-1": { openTime: "11:00", closeTime: "01:00", isOpen: true },
      "room-2": { openTime: "11:00", closeTime: "01:00", isOpen: true },
      "room-3": { openTime: "11:00", closeTime: "00:00", isOpen: true },
    },
  },
  {
    day: "Sunday",
    isOpen: true,
    openTime: "12:00",
    closeTime: "22:00",
    roomSpecific: {
      "room-1": { openTime: "12:00", closeTime: "22:00", isOpen: true },
      "room-2": { openTime: "14:00", closeTime: "22:00", isOpen: true },
      "room-3": { openTime: "12:00", closeTime: "21:00", isOpen: true },
    },
  },
]

export const mockBlackoutDates: BlackoutDate[] = [
  {
    id: "1",
    date: "2025-01-01",
    reason: "New Year's Day",
    type: "holiday",
    affectedRooms: ["room-1", "room-2", "room-3", "main-venue"],
    notes: "Closed for New Year's Day holiday",
  },
  {
    id: "2",
    date: "2025-01-15",
    endDate: "2025-01-16",
    reason: "Sound System Maintenance",
    type: "maintenance",
    affectedRooms: ["room-1", "room-2"],
    notes: "Upgrading sound equipment in karaoke rooms",
  },
  {
    id: "3",
    date: "2025-02-14",
    reason: "Private Valentine's Event",
    type: "private-event",
    affectedRooms: ["main-venue"],
    notes: "Corporate Valentine's party booking",
  },
  {
    id: "4",
    date: "2025-03-17",
    reason: "St. Patrick's Day Maintenance",
    type: "maintenance",
    affectedRooms: ["room-3"],
    notes: "Deep cleaning after St. Patrick's Day celebrations",
    isRecurring: true,
    recurringPattern: "yearly",
  },
]

export const mockRoomSettings: RoomSettings[] = [
  {
    id: "main-venue",
    name: "Main Venue",
    capacity: 150,
    minBookingDuration: 2,
    maxBookingDuration: 8,
    advanceBookingLimit: 90,
    status: "active",
    priceModifiers: {
      peakHours: [
        { startTime: "19:00", endTime: "23:00", multiplier: 1.5 },
        { startTime: "12:00", endTime: "14:00", multiplier: 1.2 },
      ],
    },
  },
  {
    id: "room-1",
    name: "Karaoke Room 1",
    capacity: 12,
    minBookingDuration: 1,
    maxBookingDuration: 4,
    advanceBookingLimit: 30,
    status: "active",
    priceModifiers: {
      peakHours: [{ startTime: "18:00", endTime: "22:00", multiplier: 1.3 }],
    },
  },
  {
    id: "room-2",
    name: "Karaoke Room 2",
    capacity: 8,
    minBookingDuration: 1,
    maxBookingDuration: 4,
    advanceBookingLimit: 30,
    status: "active",
    priceModifiers: {
      peakHours: [{ startTime: "18:00", endTime: "22:00", multiplier: 1.3 }],
    },
  },
  {
    id: "room-3",
    name: "Karaoke Room 3",
    capacity: 6,
    minBookingDuration: 1,
    maxBookingDuration: 3,
    advanceBookingLimit: 30,
    status: "maintenance",
    priceModifiers: {
      peakHours: [{ startTime: "18:00", endTime: "22:00", multiplier: 1.3 }],
    },
  },
]

export const mockSpecialEvents: SpecialEvent[] = [
  {
    id: "1",
    title: "Corporate Team Building Event",
    startDate: "2025-01-25",
    endDate: "2025-01-25",
    startTime: "18:00",
    endTime: "22:00",
    affectedRooms: ["main-venue"],
    contactName: "Sarah Mitchell",
    contactEmail: "sarah.mitchell@techcorp.com",
    contactPhone: "+44 20 7123 4567",
    notes: "Tech company team building with karaoke competition",
  },
  {
    id: "2",
    title: "Birthday Party Package",
    startDate: "2025-02-08",
    endDate: "2025-02-08",
    startTime: "15:00",
    endTime: "18:00",
    affectedRooms: ["room-1", "room-2"],
    contactName: "James Wilson",
    contactEmail: "james.wilson@email.com",
    contactPhone: "+44 7890 123456",
    notes: "21st birthday celebration, decorations included",
  },
  {
    id: "3",
    title: "Weekly Karaoke League",
    startDate: "2025-01-20",
    endDate: "2025-12-31",
    startTime: "19:00",
    endTime: "22:00",
    affectedRooms: ["room-3"],
    contactName: "Manor Events Team",
    contactEmail: "events@manor.com",
    contactPhone: "+44 20 7000 0000",
    notes: "Weekly karaoke competition league",
    isRecurring: true,
    recurringPattern: "weekly",
  },
]

// Utility functions
export const generateTimeSlots = () => {
  const slots = []
  for (let hour = 0; hour < 24; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const timeString = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`
      slots.push(timeString)
    }
  }
  return slots
}

export const formatTime = (time: string) => {
  const [hours, minutes] = time.split(":")
  const hour = Number.parseInt(hours)
  const ampm = hour >= 12 ? "PM" : "AM"
  const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
  return `${displayHour}:${minutes} ${ampm}`
}
