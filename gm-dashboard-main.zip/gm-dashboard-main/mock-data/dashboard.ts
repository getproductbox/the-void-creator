export interface DashboardMetrics {
  todaysBookings: {
    total: number
    breakdown: {
      karaoke: number
      venueHire: number
      tickets: number
    }
  }
  todaysRevenue: {
    amount: number
    comparison: {
      percentage: number
      trend: "up" | "down" | "neutral"
      period: string
    }
  }
  currentOccupancy: {
    percentage: number
    occupied: number
    total: number
    roomsStatus: {
      available: number
      occupied: number
      maintenance: number
    }
  }
}

export interface TodaysBooking {
  id: string
  time: string
  service: "Karaoke" | "Venue Hire" | "Event Tickets"
  customer: {
    name: string
    phone: string
  }
  guests: number
  status: "confirmed" | "pending" | "cancelled" | "completed"
  room?: string
  duration: number
  revenue: number
}

// Mock dashboard metrics
export const mockDashboardMetrics: DashboardMetrics = {
  todaysBookings: {
    total: 18,
    breakdown: {
      karaoke: 12,
      venueHire: 4,
      tickets: 2,
    },
  },
  todaysRevenue: {
    amount: 1247.5,
    comparison: {
      percentage: 15.3,
      trend: "up",
      period: "vs yesterday",
    },
  },
  currentOccupancy: {
    percentage: 67,
    occupied: 8,
    total: 12,
    roomsStatus: {
      available: 4,
      occupied: 8,
      maintenance: 0,
    },
  },
}

// Mock today's bookings
export const mockTodaysBookings: TodaysBooking[] = [
  {
    id: "booking-001",
    time: "10:00",
    service: "Karaoke",
    customer: {
      name: "Sarah Johnson",
      phone: "+44 7123 456789",
    },
    guests: 4,
    status: "confirmed",
    room: "Room A",
    duration: 2,
    revenue: 60,
  },
  {
    id: "booking-002",
    time: "12:30",
    service: "Venue Hire",
    customer: {
      name: "Tech Startup Ltd",
      phone: "+44 7987 654321",
    },
    guests: 25,
    status: "confirmed",
    room: "Main Hall",
    duration: 4,
    revenue: 320,
  },
  {
    id: "booking-003",
    time: "14:00",
    service: "Karaoke",
    customer: {
      name: "Mike Chen",
      phone: "+44 7456 123789",
    },
    guests: 6,
    status: "pending",
    room: "Room B",
    duration: 3,
    revenue: 90,
  },
  {
    id: "booking-004",
    time: "16:00",
    service: "Event Tickets",
    customer: {
      name: "Emma Wilson",
      phone: "+44 7789 456123",
    },
    guests: 2,
    status: "confirmed",
    duration: 3,
    revenue: 45,
  },
  {
    id: "booking-005",
    time: "18:30",
    service: "Karaoke",
    customer: {
      name: "David Brown",
      phone: "+44 7321 987654",
    },
    guests: 8,
    status: "cancelled",
    room: "Room C",
    duration: 2,
    revenue: 0,
  },
  {
    id: "booking-006",
    time: "20:00",
    service: "Venue Hire",
    customer: {
      name: "Birthday Party Co",
      phone: "+44 7654 321987",
    },
    guests: 15,
    status: "confirmed",
    room: "Private Room",
    duration: 3,
    revenue: 180,
  },
]

// Helper functions
export const getDashboardMetrics = (): DashboardMetrics => mockDashboardMetrics

export const getTodaysBookings = (): TodaysBooking[] => mockTodaysBookings

export const getBookingsByStatus = (status: TodaysBooking["status"]): TodaysBooking[] =>
  mockTodaysBookings.filter((booking) => booking.status === status)

export const getTotalRevenue = (): number => mockTodaysBookings.reduce((total, booking) => total + booking.revenue, 0)
