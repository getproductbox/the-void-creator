"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, Edit, Phone, Check, Clock, Users, Calendar } from "lucide-react"
import type { Booking } from "../../../../mock-data/bookings"
import { formatCurrency, formatTimeRange } from "../../../../mock-data/bookings"

interface TodaysScheduleTableProps {
  bookings: Booking[]
  onViewBooking: (booking: Booking) => void
  onEditBooking: (booking: Booking) => void
  onUpdateStatus: (booking: Booking, status: Booking["status"]) => void
}

type FilterType = "all" | "active" | "upcoming" | "pending"

const StatusBadge = ({ status }: { status: Booking["status"] }) => {
  const statusConfig = {
    confirmed: {
      color: "bg-green-100 text-green-700 border-green-200",
      icon: "✓",
      label: "Confirmed",
    },
    pending: {
      color: "bg-yellow-100 text-yellow-700 border-yellow-200",
      icon: "⏳",
      label: "Pending",
    },
    cancelled: {
      color: "bg-red-100 text-red-700 border-red-200",
      icon: "✕",
      label: "Cancelled",
    },
    completed: {
      color: "bg-blue-100 text-blue-700 border-blue-200",
      icon: "✓",
      label: "Completed",
    },
  }

  const config = statusConfig[status]

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${config.color}`}
    >
      <span>{config.icon}</span>
      {config.label}
    </span>
  )
}

const getBookingTimeStatus = (booking: Booking): "past" | "active" | "upcoming" => {
  const now = new Date()
  const currentTime = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

  if (booking.endTime <= currentTime) return "past"
  if (booking.startTime <= currentTime && booking.endTime > currentTime) return "active"
  return "upcoming"
}

const TimeStatusIndicator = ({ booking }: { booking: Booking }) => {
  const timeStatus = getBookingTimeStatus(booking)

  const indicators = {
    past: { color: "bg-stone-400", label: "Past" },
    active: { color: "bg-green-500 animate-pulse", label: "Active Now" },
    upcoming: { color: "bg-orange-500", label: "Upcoming" },
  }

  const indicator = indicators[timeStatus]

  return (
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${indicator.color}`} />
      <span className="text-xs text-stone-500 hidden sm:inline">{indicator.label}</span>
    </div>
  )
}

export function TodaysScheduleTable({
  bookings,
  onViewBooking,
  onEditBooking,
  onUpdateStatus,
}: TodaysScheduleTableProps) {
  const [activeFilter, setActiveFilter] = useState<FilterType>("all")

  const handleCallCustomer = (phone: string) => {
    console.log("Call customer:", phone)
    // In a real app, this would initiate a call or copy to clipboard
  }

  const handleConfirmBooking = (booking: Booking) => {
    onUpdateStatus(booking, "confirmed")
  }

  // Filter bookings based on active filter
  const filteredBookings = bookings.filter((booking) => {
    switch (activeFilter) {
      case "active":
        return getBookingTimeStatus(booking) === "active" && booking.status === "confirmed"
      case "upcoming":
        return getBookingTimeStatus(booking) === "upcoming" && booking.status === "confirmed"
      case "pending":
        return booking.status === "pending"
      default:
        return true
    }
  })

  // Get counts for filter tabs
  const filterCounts = {
    all: bookings.length,
    active: bookings.filter((b) => getBookingTimeStatus(b) === "active" && b.status === "confirmed").length,
    upcoming: bookings.filter((b) => getBookingTimeStatus(b) === "upcoming" && b.status === "confirmed").length,
    pending: bookings.filter((b) => b.status === "pending").length,
  }

  if (bookings.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="text-stone-400 mb-4">
            <Calendar className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="text-lg font-semibold text-stone-700 mb-2">No bookings today</h3>
          <p className="text-stone-500">There are no bookings scheduled for today.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <CardTitle>Today's Schedule</CardTitle>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1 bg-stone-100 rounded-lg p-1">
            {[
              { key: "all" as FilterType, label: "All" },
              { key: "active" as FilterType, label: "Active" },
              { key: "upcoming" as FilterType, label: "Upcoming" },
              { key: "pending" as FilterType, label: "Pending" },
            ].map((filter) => (
              <button
                key={filter.key}
                onClick={() => setActiveFilter(filter.key)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  activeFilter === filter.key
                    ? "bg-white text-orange-600 shadow-sm"
                    : "text-stone-600 hover:text-stone-900"
                }`}
              >
                {filter.label}
                {filterCounts[filter.key] > 0 && (
                  <span className="ml-1 text-xs bg-stone-200 text-stone-600 px-1.5 py-0.5 rounded-full">
                    {filterCounts[filter.key]}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {filteredBookings.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-stone-400 mb-2">
              <Clock className="h-8 w-8 mx-auto" />
            </div>
            <p className="text-stone-500">No bookings match the selected filter.</p>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-stone-200">
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Status</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Time</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Service</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Customer</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Guests</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Revenue</th>
                    <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBookings.map((booking) => (
                    <tr key={booking.id} className="border-b border-stone-100 hover:bg-stone-50">
                      <td className="py-4 px-2">
                        <div className="flex items-center gap-3">
                          <TimeStatusIndicator booking={booking} />
                          <StatusBadge status={booking.status} />
                        </div>
                      </td>
                      <td className="py-4 px-2">
                        <div className="text-sm font-medium text-stone-900">
                          {formatTimeRange(booking.startTime, booking.endTime)}
                        </div>
                        {booking.room && <div className="text-xs text-stone-500">{booking.room}</div>}
                      </td>
                      <td className="py-4 px-2">
                        <div className="text-sm text-stone-900">{booking.service}</div>
                        {booking.notes && (
                          <div className="text-xs text-stone-500 truncate max-w-32" title={booking.notes}>
                            {booking.notes}
                          </div>
                        )}
                      </td>
                      <td className="py-4 px-2">
                        <div className="text-sm font-medium text-stone-900">{booking.customer.name}</div>
                        <div className="flex items-center gap-1 mt-1">
                          <Phone className="h-3 w-3 text-stone-400" />
                          <button
                            onClick={() => handleCallCustomer(booking.customer.phone)}
                            className="text-xs text-stone-500 hover:text-orange-600 transition-colors"
                          >
                            {booking.customer.phone}
                          </button>
                        </div>
                      </td>
                      <td className="py-4 px-2">
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-stone-400" />
                          <span className="text-sm text-stone-900">{booking.guests}</span>
                        </div>
                      </td>
                      <td className="py-4 px-2">
                        <span className="text-sm font-medium text-stone-900">{formatCurrency(booking.amount)}</span>
                      </td>
                      <td className="py-4 px-2">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewBooking(booking)}
                            className="h-8 w-8 p-0"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onEditBooking(booking)}
                            className="h-8 w-8 p-0"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          {booking.status === "pending" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleConfirmBooking(booking)}
                              className="h-8 w-8 p-0 text-green-600 hover:text-green-700 hover:bg-green-50"
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="lg:hidden space-y-4">
              {filteredBookings.map((booking) => (
                <div key={booking.id} className="border border-stone-200 rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <TimeStatusIndicator booking={booking} />
                      <div>
                        <div className="font-medium text-stone-900">{booking.customer.name}</div>
                        <div className="text-sm text-stone-600">{booking.reference}</div>
                      </div>
                    </div>
                    <StatusBadge status={booking.status} />
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-stone-500">Time</div>
                      <div className="font-medium">{formatTimeRange(booking.startTime, booking.endTime)}</div>
                      {booking.room && <div className="text-xs text-stone-500">{booking.room}</div>}
                    </div>
                    <div>
                      <div className="text-stone-500">Service</div>
                      <div className="font-medium">{booking.service}</div>
                    </div>
                    <div>
                      <div className="text-stone-500">Guests</div>
                      <div className="font-medium flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {booking.guests}
                      </div>
                    </div>
                    <div>
                      <div className="text-stone-500">Revenue</div>
                      <div className="font-medium">{formatCurrency(booking.amount)}</div>
                    </div>
                  </div>

                  {booking.notes && (
                    <div className="text-sm">
                      <div className="text-stone-500">Notes</div>
                      <div className="text-stone-700 italic">{booking.notes}</div>
                    </div>
                  )}

                  <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                    <Button variant="outline" size="sm" onClick={() => onViewBooking(booking)} className="flex-1">
                      <Eye className="h-4 w-4 mr-2" />
                      View
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => onEditBooking(booking)} className="flex-1">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                    {booking.status === "pending" && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleConfirmBooking(booking)}
                        className="flex-1 text-green-600 border-green-200 hover:bg-green-50"
                      >
                        <Check className="h-4 w-4 mr-2" />
                        Confirm
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
