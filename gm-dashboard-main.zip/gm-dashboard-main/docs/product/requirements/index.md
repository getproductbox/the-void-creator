# Product Requirements

This directory contains all Product Requirements Documents (PRDs) for the application.

## Current PRDs

- [PRD Template](../../templates/prd-template.md) - Use this template for new PRDs

## Guidelines

1. **Naming Convention**: Use descriptive names like `feature-name-prd.md`
2. **Version Control**: Update version numbers when making significant changes
3. **Review Process**: All PRDs should be reviewed by product and engineering teams
4. **Status Tracking**: Keep status updated (Draft/Review/Approved/Implemented)

## PRD Lifecycle

1. **Draft**: Initial PRD creation using template
2. **Review**: Stakeholder review and feedback
3. **Approved**: Final approval from product owner
4. **Implemented**: Feature development complete
5. **Archived**: Moved to archived folder when no longer relevant
