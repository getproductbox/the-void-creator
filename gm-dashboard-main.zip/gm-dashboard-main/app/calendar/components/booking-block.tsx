"use client"

import type React from "react"
import { useState } from "react"

import { Users, Clock, Phone } from "lucide-react"
import type { CalendarBooking } from "../../../mock-data/calendar"
import { getBookingDuration } from "../../../mock-data/calendar"

interface BookingBlockProps {
  booking: CalendarBooking
  onClick: (booking: CalendarBooking) => void
  style?: React.CSSProperties
}

export function BookingBlock({ booking, onClick, style }: BookingBlockProps) {
  const [isHovered, setIsHovered] = useState(false)
  const duration = getBookingDuration(booking.startTime, booking.endTime)

  const getStatusColor = (status: CalendarBooking["status"]) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 border-green-300 text-green-800"
      case "pending":
        return "bg-yellow-100 border-yellow-300 text-yellow-800"
      case "cancelled":
        return "bg-red-100 border-red-300 text-red-800"
      case "completed":
        return "bg-blue-100 border-blue-300 text-blue-800"
      default:
        return "bg-stone-100 border-stone-300 text-stone-800"
    }
  }

  const getStatusIcon = (status: CalendarBooking["status"]) => {
    switch (status) {
      case "confirmed":
        return "✓"
      case "pending":
        return "⏳"
      case "cancelled":
        return "✕"
      case "completed":
        return "✓"
      default:
        return "?"
    }
  }

  const formatTimeRange = (startTime: string, endTime: string) => {
    const formatTime = (time: string) => {
      const [hours, minutes] = time.split(":")
      const hour = Number.parseInt(hours)
      const ampm = hour >= 12 ? "PM" : "AM"
      const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
      return `${displayHour}:${minutes} ${ampm}`
    }
    return `${formatTime(startTime)} - ${formatTime(endTime)}`
  }

  // Determine if this is a short booking (1.5 hours or less)
  const isShortBooking = duration <= 1.5

  // Compact view for short bookings
  const CompactView = () => (
    <div className="space-y-1">
      {/* Status and customer name in one line */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 min-w-0 flex-1">
          <span className="text-xs font-medium flex-shrink-0">{getStatusIcon(booking.status)}</span>
          <span className="text-xs font-semibold truncate">{booking.customer.name}</span>
        </div>
        <div className="flex items-center gap-1 text-xs flex-shrink-0 ml-1">
          <Users className="h-3 w-3" />
          <span>{booking.guests}</span>
        </div>
      </div>

      {/* Service type */}
      <div className="text-xs opacity-75 truncate">{booking.service}</div>
    </div>
  )

  // Full view for longer bookings
  const FullView = () => (
    <div className="space-y-2">
      {/* Header with status and time */}
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium flex items-center gap-1 min-w-0 flex-1">
          <span className="flex-shrink-0">{getStatusIcon(booking.status)}</span>
          <span className="truncate">{booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}</span>
        </span>
        <div className="flex items-center gap-1 text-xs flex-shrink-0 ml-1">
          <Clock className="h-3 w-3" />
          <span className="hidden sm:inline">{formatTimeRange(booking.startTime, booking.endTime)}</span>
        </div>
      </div>

      {/* Customer name */}
      <div className="font-semibold text-sm truncate">{booking.customer.name}</div>

      {/* Service and guests */}
      <div className="flex items-center justify-between text-xs">
        <span className="truncate flex-1 mr-2">{booking.service}</span>
        <div className="flex items-center gap-1 flex-shrink-0">
          <Users className="h-3 w-3" />
          <span>{booking.guests}</span>
        </div>
      </div>

      {/* Phone number */}
      <div className="flex items-center gap-1 text-xs opacity-75">
        <Phone className="h-3 w-3 flex-shrink-0" />
        <span className="truncate">{booking.customer.phone}</span>
      </div>

      {/* Notes if available - only show if there's enough space */}
      {booking.notes && duration >= 2 && (
        <div className="text-xs italic opacity-75 truncate" title={booking.notes}>
          {booking.notes}
        </div>
      )}
    </div>
  )

  return (
    <div
      className={`
        absolute left-1 right-1 rounded-lg border-2 p-3 cursor-pointer
        transition-all duration-200 hover:shadow-md hover:scale-[1.02]
        ${getStatusColor(booking.status)}
        ${isShortBooking ? "p-2" : "p-3"}
      `}
      style={{
        ...style,
        zIndex: isHovered ? 50 : 10,
      }}
      onClick={() => onClick(booking)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Main content */}
      {isShortBooking ? <CompactView /> : <FullView />}

      {/* Hover tooltip for short bookings */}
      {isHovered && isShortBooking && (
        <div
          className="absolute bg-white border border-stone-300 rounded-lg shadow-xl p-3 min-w-64 max-w-80"
          style={{
            top: "-8px",
            left: "100%",
            marginLeft: "8px",
            zIndex: 100,
          }}
        >
          <div className="space-y-2">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-2">
              <span className="text-sm font-semibold flex items-center gap-2">
                <span>{getStatusIcon(booking.status)}</span>
                {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
              </span>
              <div className="flex items-center gap-1 text-sm text-stone-600">
                <Clock className="h-4 w-4" />
                {formatTimeRange(booking.startTime, booking.endTime)}
              </div>
            </div>

            {/* Customer details */}
            <div>
              <div className="font-semibold text-base">{booking.customer.name}</div>
              <div className="flex items-center gap-1 text-sm text-stone-600 mt-1">
                <Phone className="h-4 w-4" />
                {booking.customer.phone}
              </div>
            </div>

            {/* Booking details */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-stone-500">Service:</span>
                <div className="font-medium">{booking.service}</div>
              </div>
              <div>
                <span className="text-stone-500">Guests:</span>
                <div className="font-medium flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {booking.guests}
                </div>
              </div>
            </div>

            {/* Revenue */}
            <div className="text-sm">
              <span className="text-stone-500">Revenue:</span>
              <span className="font-semibold ml-2">£{booking.revenue}</span>
            </div>

            {/* Notes */}
            {booking.notes && (
              <div className="text-sm">
                <span className="text-stone-500">Notes:</span>
                <div className="italic text-stone-700 mt-1">{booking.notes}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
