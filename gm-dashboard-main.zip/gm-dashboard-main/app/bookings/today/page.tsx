"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, RefreshCw } from "lucide-react"
import { useRouter } from "next/navigation"
import { TodayMetricsCards } from "./components/today-metrics"
import { TodaysScheduleTable } from "./components/todays-schedule-table"
import { getTodaysBookings, getTodayMetrics, DEMO_TODAY } from "../../../mock-data/todays-schedule"
import type { Booking } from "../../../mock-data/bookings"

export default function TodaySchedulePage() {
  const router = useRouter()
  const [refreshKey, setRefreshKey] = useState(0)

  // Get today's data
  const todaysBookings = getTodaysBookings()
  const todayMetrics = getTodayMetrics()

  const handleCreateBooking = () => {
    router.push("/bookings/create")
  }

  const handleViewBooking = (booking: Booking) => {
    console.log("View booking:", booking)
    // In a real app, this would open a booking details modal or navigate to booking page
  }

  const handleEditBooking = (booking: Booking) => {
    console.log("Edit booking:", booking)
    // In a real app, this would open an edit booking modal or navigate to edit page
  }

  const handleUpdateStatus = (booking: Booking, status: Booking["status"]) => {
    console.log("Update booking status:", booking.id, "to", status)
    // In a real app, this would update the booking status via API
    // For now, we'll just trigger a refresh
    setRefreshKey((prev) => prev + 1)
  }

  const handleRefresh = () => {
    setRefreshKey((prev) => prev + 1)
    // In a real app, this would refetch data from the API
  }

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-6" key={refreshKey}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900">Today's Schedule</h1>
          <p className="text-stone-600 mt-1">{formatDate(DEMO_TODAY)} • Manage today's bookings and activities</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleRefresh} size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={handleCreateBooking} className="bg-orange-500 hover:bg-orange-600">
            <Plus className="h-4 w-4 mr-2" />
            Add Booking
          </Button>
        </div>
      </div>

      {/* Metrics Cards */}
      <TodayMetricsCards metrics={todayMetrics} />

      {/* Schedule Table */}
      <TodaysScheduleTable
        bookings={todaysBookings}
        onViewBooking={handleViewBooking}
        onEditBooking={handleEditBooking}
        onUpdateStatus={handleUpdateStatus}
      />

      {/* Quick Actions Footer */}
      {todaysBookings.length > 0 && (
        <div className="bg-stone-50 rounded-lg p-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="text-sm text-stone-600">
              <strong>Quick Actions:</strong> Use the action buttons to view details, edit bookings, or confirm pending
              reservations.
            </div>
            <div className="flex items-center gap-2 text-xs text-stone-500">
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span>Active</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-orange-500 rounded-full" />
                <span>Upcoming</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-stone-400 rounded-full" />
                <span>Past</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
