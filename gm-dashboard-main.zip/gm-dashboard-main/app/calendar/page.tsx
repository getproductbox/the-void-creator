"use client"

import { useState } from "react"
import { CalendarHeader } from "./components/calendar-header"
import { TimeGrid } from "./components/time-grid"
import { mockCalendarResources, getBookingsForDate } from "../../mock-data/calendar"
import type { CalendarBooking } from "../../mock-data/calendar"

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date(2025, 0, 15)) // January 15, 2025

  const handlePreviousDay = () => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() - 1)
    setCurrentDate(newDate)
  }

  const handleNextDay = () => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() + 1)
    setCurrentDate(newDate)
  }

  const handleToday = () => {
    setCurrentDate(new Date())
  }

  const handleBookingClick = (booking: CalendarBooking) => {
    console.log("Booking clicked:", booking)
    // In a real app, this would open a booking details modal or navigate to booking page
  }

  const handleSlotClick = (resourceId: string, time: string) => {
    console.log("Empty slot clicked:", { resourceId, time, date: currentDate.toISOString().split("T")[0] })
    // In a real app, this would open a create booking modal
  }

  // Get bookings for the current date
  const dateString = currentDate.toISOString().split("T")[0]
  const todaysBookings = getBookingsForDate(dateString)

  return (
    <div className="flex flex-col h-full">
      <CalendarHeader
        currentDate={currentDate}
        onPreviousDay={handlePreviousDay}
        onNextDay={handleNextDay}
        onToday={handleToday}
      />

      <TimeGrid
        resources={mockCalendarResources}
        bookings={todaysBookings}
        onBookingClick={handleBookingClick}
        onSlotClick={handleSlotClick}
      />
    </div>
  )
}
