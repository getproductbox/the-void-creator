"use client"

import { Mail, Phone, Calendar, DollarSign, TrendingUp, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import type { Customer } from "@/mock-data/customers"

interface CustomerInfoProps {
  customer: Customer
  bookingStats: any
}

export function CustomerInfo({ customer, bookingStats }: CustomerInfoProps) {
  const getStatusColor = (status: Customer["status"]) => {
    switch (status) {
      case "vip":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "returning":
        return "bg-green-100 text-green-800 border-green-200"
      case "first-time":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-stone-100 text-stone-800 border-stone-200"
    }
  }

  return (
    <div className="space-y-4 lg:space-y-6">
      {/* Contact Information - Compact layout */}
      <div>
        <h3 className="text-base lg:text-lg font-semibold text-stone-900 mb-3 lg:mb-4">Contact Information</h3>
        <div className="space-y-2 lg:space-y-3">
          <div className="flex items-start gap-3">
            <Mail className="h-4 w-4 text-stone-500 mt-0.5 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-stone-900 break-all">{customer.email}</p>
              <p className="text-xs text-stone-500">Primary email</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Phone className="h-4 w-4 text-stone-500 mt-0.5 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-stone-900">{customer.phone}</p>
              <p className="text-xs text-stone-500">Mobile phone</p>
            </div>
          </div>
        </div>
      </div>

      <Separator />

      {/* Customer Statistics - Responsive grid */}
      <div>
        <h3 className="text-base lg:text-lg font-semibold text-stone-900 mb-3 lg:mb-4">Customer Statistics</h3>
        <div className="grid grid-cols-2 gap-2 lg:gap-4">
          <div className="bg-stone-50 rounded-lg p-3 lg:p-4">
            <div className="flex items-center gap-2 mb-1 lg:mb-2">
              <Calendar className="h-3 w-3 lg:h-4 lg:w-4 text-orange-500 shrink-0" />
              <span className="text-xs lg:text-sm font-medium text-stone-700 truncate">Total Bookings</span>
            </div>
            <p className="text-lg lg:text-2xl font-bold text-stone-900">{customer.totalBookings}</p>
          </div>

          <div className="bg-stone-50 rounded-lg p-3 lg:p-4">
            <div className="flex items-center gap-2 mb-1 lg:mb-2">
              <DollarSign className="h-3 w-3 lg:h-4 lg:w-4 text-green-500 shrink-0" />
              <span className="text-xs lg:text-sm font-medium text-stone-700 truncate">Total Spent</span>
            </div>
            <p className="text-lg lg:text-2xl font-bold text-stone-900">£{customer.totalSpent.toLocaleString()}</p>
          </div>

          <div className="bg-stone-50 rounded-lg p-3 lg:p-4">
            <div className="flex items-center gap-2 mb-1 lg:mb-2">
              <TrendingUp className="h-3 w-3 lg:h-4 lg:w-4 text-blue-500 shrink-0" />
              <span className="text-xs lg:text-sm font-medium text-stone-700 truncate">Avg. Booking</span>
            </div>
            <p className="text-lg lg:text-2xl font-bold text-stone-900">£{customer.averageBookingValue}</p>
          </div>

          <div className="bg-stone-50 rounded-lg p-3 lg:p-4">
            <div className="flex items-center gap-2 mb-1 lg:mb-2">
              <Clock className="h-3 w-3 lg:h-4 lg:w-4 text-purple-500 shrink-0" />
              <span className="text-xs lg:text-sm font-medium text-stone-700 truncate">Last Visit</span>
            </div>
            <p className="text-xs lg:text-sm font-bold text-stone-900">
              {customer.lastVisit ? new Date(customer.lastVisit).toLocaleDateString() : "Never"}
            </p>
          </div>
        </div>
      </div>

      <Separator />

      {/* Customer Status & Preferences - Compact layout */}
      <div>
        <h3 className="text-base lg:text-lg font-semibold text-stone-900 mb-3 lg:mb-4">Status & Preferences</h3>
        <div className="space-y-3 lg:space-y-4">
          <div>
            <Label className="text-sm font-medium text-stone-700">Customer Status</Label>
            <div className="mt-2">
              <Badge className={getStatusColor(customer.status)}>
                {customer.status === "vip"
                  ? "VIP Customer"
                  : customer.status === "returning"
                    ? "Returning Customer"
                    : "First-time Customer"}
              </Badge>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium text-stone-700">Preferred Services</Label>
            <div className="flex flex-wrap gap-1 lg:gap-2 mt-2">
              {customer.preferredServices.map((service) => (
                <Badge key={service} variant="outline" className="text-xs">
                  {service}
                </Badge>
              ))}
            </div>
          </div>

          {bookingStats && (
            <div>
              <Label className="text-sm font-medium text-stone-700">Booking Patterns</Label>
              <div className="mt-2 space-y-1 text-xs lg:text-sm text-stone-600">
                <p className="break-words">
                  • Favorite service: <span className="font-medium">{bookingStats.favoriteService}</span>
                </p>
                <p className="break-words">
                  • Most common time: <span className="font-medium">{bookingStats.mostCommonTime}</span>
                </p>
                <p className="break-words">
                  • Preferred day: <span className="font-medium">{bookingStats.mostCommonDay}</span>
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      <Separator />

      {/* Communication Preferences - Compact switches */}
      <div>
        <h3 className="text-base lg:text-lg font-semibold text-stone-900 mb-3 lg:mb-4">Communication Preferences</h3>
        <div className="space-y-3 lg:space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="min-w-0 flex-1">
              <Label htmlFor="email-marketing" className="text-sm font-medium">
                Email Marketing
              </Label>
              <p className="text-xs text-stone-500 mt-0.5">Receive promotional emails and offers</p>
            </div>
            <Switch id="email-marketing" defaultChecked className="shrink-0" />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div className="min-w-0 flex-1">
              <Label htmlFor="sms-notifications" className="text-sm font-medium">
                SMS Notifications
              </Label>
              <p className="text-xs text-stone-500 mt-0.5">Booking confirmations and reminders</p>
            </div>
            <Switch id="sms-notifications" defaultChecked className="shrink-0" />
          </div>
        </div>
      </div>

      <Separator />

      {/* Customer Notes - Responsive textarea */}
      <div>
        <h3 className="text-base lg:text-lg font-semibold text-stone-900 mb-3 lg:mb-4">Staff Notes</h3>
        <Textarea
          placeholder="Add notes about this customer..."
          defaultValue={customer.notes || ""}
          className="min-h-[80px] lg:min-h-[100px] resize-none text-sm"
          readOnly
        />
        <p className="text-xs text-stone-500 mt-2">Click "Edit Customer" to modify notes</p>
      </div>
    </div>
  )
}
