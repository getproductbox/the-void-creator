"use client"

import type React from "react"
import { useRouter } from "next/navigation"

import { Calendar, FileText, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"

interface QuickActionButtonProps {
  onClick: () => void
  icon: React.ReactNode
  title: string
  description: string
  variant?: "primary" | "outline"
}

const QuickActionButton = ({ onClick, icon, title, description, variant = "outline" }: QuickActionButtonProps) => {
  const baseClasses = "h-16 px-4 py-3 flex items-center gap-3 transition-all duration-200 rounded-lg"
  const primaryClasses = "bg-orange-500 hover:bg-orange-600 text-white shadow-sm hover:shadow-md hover:-translate-y-0.5"
  const outlineClasses = "bg-white text-stone-700 border border-stone-300 hover:bg-stone-50 hover:border-stone-400"

  return (
    <Button
      onClick={onClick}
      variant="ghost"
      className={`${baseClasses} ${variant === "primary" ? primaryClasses : outlineClasses} justify-start w-full`}
    >
      <div className="flex-shrink-0">{icon}</div>
      <div className="flex-1 min-w-0 text-left">
        <div className="font-medium text-sm leading-tight">{title}</div>
        <div className={`text-xs mt-0.5 leading-tight ${variant === "primary" ? "text-white/90" : "text-stone-500"}`}>
          {description}
        </div>
      </div>
    </Button>
  )
}

export function QuickActions() {
  const router = useRouter()

  const handleCreateBooking = () => {
    router.push("/bookings/create")
  }

  const handleViewCalendar = () => {
    router.push("/calendar")
  }

  const handleTodaysReports = () => {
    router.push("/reports/daily")
  }

  const handleCustomerLookup = () => {
    router.push("/customers")
  }

  const quickActions = [
    {
      id: "create-booking",
      onClick: handleCreateBooking,
      icon: <Plus className="h-5 w-5" />,
      title: "Create New Booking",
      description: "Add a new reservation",
      variant: "primary" as const,
    },
    {
      id: "view-calendar",
      onClick: handleViewCalendar,
      icon: <Calendar className="h-5 w-5" />,
      title: "View Full Calendar",
      description: "See all bookings",
      variant: "outline" as const,
    },
    {
      id: "todays-reports",
      onClick: handleTodaysReports,
      icon: <FileText className="h-5 w-5" />,
      title: "Today's Reports",
      description: "View daily analytics",
      variant: "outline" as const,
    },
    {
      id: "customer-lookup",
      onClick: handleCustomerLookup,
      icon: <Search className="h-5 w-5" />,
      title: "Customer Lookup",
      description: "Find customer details",
      variant: "outline" as const,
    },
  ]

  return (
    <div className="w-full">
      {/* Mobile: Stack vertically */}
      <div className="grid grid-cols-1 gap-3 sm:hidden">
        {quickActions.map((action) => (
          <QuickActionButton
            key={action.id}
            onClick={action.onClick}
            icon={action.icon}
            title={action.title}
            description={action.description}
            variant={action.variant}
          />
        ))}
      </div>

      {/* Desktop/Tablet: Horizontal layout */}
      <div className="hidden sm:grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <QuickActionButton
            key={action.id}
            onClick={action.onClick}
            icon={action.icon}
            title={action.title}
            description={action.description}
            variant={action.variant}
          />
        ))}
      </div>

      {/* Keyboard shortcuts hint */}
      <div className="hidden lg:block mt-4">
        <p className="text-xs text-stone-500 text-center">
          <span className="font-medium">Quick shortcuts:</span> Ctrl+N (New Booking) • Ctrl+K (Search) • Ctrl+R
          (Reports)
        </p>
      </div>
    </div>
  )
}
