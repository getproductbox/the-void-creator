"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Users, FileText, DollarSign, ArrowLeft, Check } from "lucide-react"
import type { BookingFormData } from "../page"

interface BookingSummaryProps {
  formData: BookingFormData
  onBack: () => void
  onSubmit: () => void
  isSubmitting: boolean
}

export function BookingSummary({ formData, onBack, onSubmit, isSubmitting }: BookingSummaryProps) {
  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (time: string): string => {
    const [hours, minutes] = time.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
    return `${displayHour}:${minutes} ${ampm}`
  }

  const generateBookingReference = (): string => {
    const date = new Date(formData.date)
    const year = date.getFullYear()
    const month = (date.getMonth() + 1).toString().padStart(2, "0")
    const day = date.getDate().toString().padStart(2, "0")
    const random = Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, "0")
    return `MNR-${year}${month}${day}-${random}`
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onBack} className="p-2">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-stone-900">Review Booking Details</h2>
          <p className="text-stone-600">Please review all information before confirming</p>
        </div>
      </div>

      {/* Booking Reference */}
      <Card className="border-orange-200 bg-orange-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-orange-800">Booking Reference</p>
              <p className="font-mono font-bold text-orange-900">{generateBookingReference()}</p>
            </div>
            <div className="text-orange-600">
              <FileText className="h-6 w-6" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Customer Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-stone-600">Name</p>
              <p className="font-medium">{formData.customerName}</p>
            </div>
            <div>
              <p className="text-sm text-stone-600">Phone</p>
              <p className="font-medium">{formData.customerPhone}</p>
            </div>
          </div>
          <div>
            <p className="text-sm text-stone-600">Email</p>
            <p className="font-medium">{formData.customerEmail}</p>
          </div>
        </CardContent>
      </Card>

      {/* Booking Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Booking Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-stone-600">Service</p>
              <p className="font-medium">{formData.service}</p>
            </div>
            <div>
              <p className="text-sm text-stone-600">Date</p>
              <p className="font-medium">{formatDate(formData.date)}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-stone-600">Start Time</p>
              <p className="font-medium">{formatTime(formData.startTime)}</p>
            </div>
            <div>
              <p className="text-sm text-stone-600">End Time</p>
              <p className="font-medium">{formatTime(formData.endTime)}</p>
            </div>
            <div>
              <p className="text-sm text-stone-600">Duration</p>
              <p className="font-medium">
                {formData.duration} hour{formData.duration !== 1 ? "s" : ""}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-stone-600">Number of Guests</p>
              <p className="font-medium">{formData.guests}</p>
            </div>
            <div>
              <p className="text-sm text-stone-600">Room</p>
              <p className="font-medium">{formData.room}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Additional Information */}
      {(formData.notes || formData.specialRequests) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Additional Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {formData.notes && (
              <div>
                <p className="text-sm text-stone-600">Notes</p>
                <p className="font-medium">{formData.notes}</p>
              </div>
            )}
            {formData.specialRequests && (
              <div>
                <p className="text-sm text-stone-600">Special Requests</p>
                <p className="font-medium">{formData.specialRequests}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Pricing Summary */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Pricing Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span>Base price ({formData.duration}h)</span>
            <span>£{formData.basePrice.toFixed(2)}</span>
          </div>

          {formData.fees.map((fee, index) => (
            <div key={index} className="flex justify-between text-sm text-stone-600">
              <span>{fee.name}</span>
              <span>£{fee.amount.toFixed(2)}</span>
            </div>
          ))}

          {formData.discount > 0 && (
            <div className="flex justify-between text-sm text-green-600">
              <span>Discount</span>
              <span>-£{formData.discount.toFixed(2)}</span>
            </div>
          )}

          <div className="border-t border-green-200 pt-3">
            <div className="flex justify-between font-bold text-lg">
              <span>Total</span>
              <span>£{formData.total.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-between">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Edit
        </Button>

        <Button onClick={onSubmit} disabled={isSubmitting} className="bg-green-600 hover:bg-green-700">
          {isSubmitting ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              Creating Booking...
            </>
          ) : (
            <>
              <Check className="h-4 w-4 mr-2" />
              Confirm Booking
            </>
          )}
        </Button>
      </div>

      {/* Terms Notice */}
      <div className="bg-stone-50 border border-stone-200 rounded-lg p-4">
        <p className="text-xs text-stone-600">
          By confirming this booking, you agree to our terms and conditions. Cancellation policy: 24 hours notice
          required for full refund. Payment is due upon arrival unless otherwise arranged.
        </p>
      </div>
    </div>
  )
}
