"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Save, AlertTriangle } from "lucide-react"
import { OperatingHours } from "./components/operating-hours"
import { BlackoutDates } from "./components/blackout-dates"
import { RoomSettings } from "./components/room-settings"
import { SpecialEvents } from "./components/special-events"
import { AvailabilityPreview } from "./components/availability-preview"

export default function AvailabilityManagementPage() {
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [activeTab, setActiveTab] = useState("operating-hours")

  const handleSaveChanges = () => {
    // In a real app, this would save to the backend
    console.log("Saving availability changes...")
    setHasUnsavedChanges(false)
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-stone-200 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-stone-900">Availability Management</h1>
            <p className="text-stone-600 mt-1">
              Configure operating hours, blackout dates, and room availability settings.
            </p>
          </div>

          {hasUnsavedChanges && (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-amber-600">
                <AlertTriangle className="h-4 w-4" />
                <span className="text-sm font-medium">Unsaved changes</span>
              </div>
              <Button onClick={handleSaveChanges} className="bg-orange-500 hover:bg-orange-600">
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="xl:col-span-3">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="operating-hours">Operating Hours</TabsTrigger>
              <TabsTrigger value="blackout-dates">Blackout Dates</TabsTrigger>
              <TabsTrigger value="room-settings">Room Settings</TabsTrigger>
              <TabsTrigger value="special-events">Special Events</TabsTrigger>
            </TabsList>

            <TabsContent value="operating-hours" className="space-y-6">
              <OperatingHours onChanges={() => setHasUnsavedChanges(true)} />
            </TabsContent>

            <TabsContent value="blackout-dates" className="space-y-6">
              <BlackoutDates onChanges={() => setHasUnsavedChanges(true)} />
            </TabsContent>

            <TabsContent value="room-settings" className="space-y-6">
              <RoomSettings onChanges={() => setHasUnsavedChanges(true)} />
            </TabsContent>

            <TabsContent value="special-events" className="space-y-6">
              <SpecialEvents onChanges={() => setHasUnsavedChanges(true)} />
            </TabsContent>
          </Tabs>
        </div>

        {/* Preview Panel */}
        <div className="xl:col-span-1">
          <AvailabilityPreview activeTab={activeTab} />
        </div>
      </div>
    </div>
  )
}
