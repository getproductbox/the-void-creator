import type { Booking } from "./bookings"
import { mockBookings } from "./bookings"

// Get today's date in YYYY-MM-DD format
export const getTodayString = (): string => {
  return new Date().toISOString().split("T")[0]
}

// For demo purposes, let's use January 15, 2025 as "today"
export const DEMO_TODAY = "2025-01-15"

export interface TodayMetrics {
  totalBookings: number
  confirmedBookings: number
  pendingBookings: number
  totalRevenue: number
  totalGuests: number
  roomsInUse: number
  nextBooking?: {
    time: string
    customer: string
    room: string
  }
}

// Get today's bookings (using demo date)
export const getTodaysBookings = (): Booking[] => {
  return mockBookings
    .filter((booking) => booking.date === DEMO_TODAY)
    .sort((a, b) => a.startTime.localeCompare(b.startTime))
}

// Calculate today's metrics
export const getTodayMetrics = (): TodayMetrics => {
  const todaysBookings = getTodaysBookings()
  const confirmedBookings = todaysBookings.filter((b) => b.status === "confirmed")
  const pendingBookings = todaysBookings.filter((b) => b.status === "pending")

  const totalRevenue = todaysBookings
    .filter((b) => b.status !== "cancelled")
    .reduce((sum, booking) => sum + booking.amount, 0)

  const totalGuests = todaysBookings
    .filter((b) => b.status !== "cancelled")
    .reduce((sum, booking) => sum + booking.guests, 0)

  const roomsInUse = new Set(todaysBookings.filter((b) => b.status === "confirmed" && b.room).map((b) => b.room)).size

  // Find next booking (after current time)
  const now = new Date()
  const currentTime = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

  const nextBooking = todaysBookings
    .filter((b) => b.status === "confirmed" && b.startTime > currentTime)
    .sort((a, b) => a.startTime.localeCompare(b.startTime))[0]

  return {
    totalBookings: todaysBookings.length,
    confirmedBookings: confirmedBookings.length,
    pendingBookings: pendingBookings.length,
    totalRevenue,
    totalGuests,
    roomsInUse,
    nextBooking: nextBooking
      ? {
          time: nextBooking.startTime,
          customer: nextBooking.customer.name,
          room: nextBooking.room || "TBD",
        }
      : undefined,
  }
}

// Get bookings by time period
export const getBookingsByTimePeriod = (period: "morning" | "afternoon" | "evening"): Booking[] => {
  const todaysBookings = getTodaysBookings()

  return todaysBookings.filter((booking) => {
    const hour = Number.parseInt(booking.startTime.split(":")[0])

    switch (period) {
      case "morning":
        return hour >= 6 && hour < 12
      case "afternoon":
        return hour >= 12 && hour < 18
      case "evening":
        return hour >= 18 && hour <= 23
      default:
        return true
    }
  })
}

// Get current active bookings
export const getCurrentActiveBookings = (): Booking[] => {
  const now = new Date()
  const currentTime = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

  return getTodaysBookings().filter((booking) => {
    return booking.status === "confirmed" && booking.startTime <= currentTime && booking.endTime > currentTime
  })
}

// Get upcoming bookings (next 2 hours)
export const getUpcomingBookings = (): Booking[] => {
  const now = new Date()
  const currentTime = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`
  const twoHoursLater = new Date(now.getTime() + 2 * 60 * 60 * 1000)
  const twoHoursLaterTime = `${twoHoursLater.getHours().toString().padStart(2, "0")}:${twoHoursLater.getMinutes().toString().padStart(2, "0")}`

  return getTodaysBookings().filter((booking) => {
    return booking.status === "confirmed" && booking.startTime > currentTime && booking.startTime <= twoHoursLaterTime
  })
}
