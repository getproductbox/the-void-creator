"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Eye, Ban, ChevronUp, ChevronDown, Phone } from "lucide-react"
import type { Booking } from "../../../mock-data/bookings"
import { formatCurrency, formatDate, formatTimeRange } from "../../../mock-data/bookings"

interface BookingsTableProps {
  bookings: Booking[]
  onViewBooking: (booking: Booking) => void
  onCancelBooking: (booking: Booking) => void
}

type SortField = "reference" | "customer" | "service" | "date" | "guests" | "status" | "amount"
type SortOrder = "asc" | "desc"

const StatusBadge = ({ status }: { status: Booking["status"] }) => {
  const statusConfig = {
    confirmed: {
      color: "bg-green-100 text-green-700 border-green-200",
      icon: "✓",
      label: "Confirmed",
    },
    pending: {
      color: "bg-yellow-100 text-yellow-700 border-yellow-200",
      icon: "⏳",
      label: "Pending",
    },
    cancelled: {
      color: "bg-red-100 text-red-700 border-red-200",
      icon: "✕",
      label: "Cancelled",
    },
    completed: {
      color: "bg-blue-100 text-blue-700 border-blue-200",
      icon: "✓",
      label: "Completed",
    },
  }

  const config = statusConfig[status]

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${config.color}`}
    >
      <span>{config.icon}</span>
      {config.label}
    </span>
  )
}

const SortableHeader = ({
  children,
  field,
  currentSort,
  onSort,
}: {
  children: React.ReactNode
  field: SortField
  currentSort: { field: SortField; order: SortOrder } | null
  onSort: (field: SortField) => void
}) => {
  const isActive = currentSort?.field === field
  const isAsc = isActive && currentSort?.order === "asc"

  return (
    <button
      onClick={() => onSort(field)}
      className="flex items-center gap-1 text-left font-medium text-stone-600 hover:text-stone-900 transition-colors"
    >
      {children}
      <div className="flex flex-col">
        <ChevronUp className={`h-3 w-3 ${isActive && isAsc ? "text-orange-500" : "text-stone-300"}`} />
        <ChevronDown className={`h-3 w-3 -mt-1 ${isActive && !isAsc ? "text-orange-500" : "text-stone-300"}`} />
      </div>
    </button>
  )
}

export function BookingsTable({ bookings, onViewBooking, onCancelBooking }: BookingsTableProps) {
  const [sortConfig, setSortConfig] = useState<{ field: SortField; order: SortOrder } | null>(null)

  const handleSort = (field: SortField) => {
    let order: SortOrder = "asc"

    if (sortConfig && sortConfig.field === field && sortConfig.order === "asc") {
      order = "desc"
    }

    setSortConfig({ field, order })
  }

  const sortedBookings = sortConfig
    ? [...bookings].sort((a, b) => {
        let aValue: any
        let bValue: any

        switch (sortConfig.field) {
          case "reference":
            aValue = a.reference
            bValue = b.reference
            break
          case "customer":
            aValue = a.customer.name
            bValue = b.customer.name
            break
          case "service":
            aValue = a.service
            bValue = b.service
            break
          case "date":
            aValue = new Date(a.date + "T" + a.startTime)
            bValue = new Date(b.date + "T" + b.startTime)
            break
          case "guests":
            aValue = a.guests
            bValue = b.guests
            break
          case "status":
            aValue = a.status
            bValue = b.status
            break
          case "amount":
            aValue = a.amount
            bValue = b.amount
            break
          default:
            return 0
        }

        if (aValue < bValue) return sortConfig.order === "asc" ? -1 : 1
        if (aValue > bValue) return sortConfig.order === "asc" ? 1 : -1
        return 0
      })
    : bookings

  if (bookings.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="text-stone-400 mb-4">
            <Eye className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="text-lg font-semibold text-stone-700 mb-2">No bookings found</h3>
          <p className="text-stone-500">Try adjusting your filters to see more results.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="p-0">
        {/* Desktop Table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone-200">
                <th className="text-left py-4 px-4">
                  <SortableHeader field="reference" currentSort={sortConfig} onSort={handleSort}>
                    Reference
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4">
                  <SortableHeader field="customer" currentSort={sortConfig} onSort={handleSort}>
                    Customer
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4">
                  <SortableHeader field="service" currentSort={sortConfig} onSort={handleSort}>
                    Service
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4">
                  <SortableHeader field="date" currentSort={sortConfig} onSort={handleSort}>
                    Date & Time
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4">
                  <SortableHeader field="guests" currentSort={sortConfig} onSort={handleSort}>
                    Guests
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4">
                  <SortableHeader field="status" currentSort={sortConfig} onSort={handleSort}>
                    Status
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4">
                  <SortableHeader field="amount" currentSort={sortConfig} onSort={handleSort}>
                    Amount
                  </SortableHeader>
                </th>
                <th className="text-left py-4 px-4 w-24">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedBookings.map((booking) => (
                <tr key={booking.id} className="border-b border-stone-100 hover:bg-stone-50 transition-colors">
                  <td className="py-4 px-4">
                    <div className="font-medium text-stone-900">{booking.reference}</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="font-medium text-stone-900">{booking.customer.name}</div>
                    <div className="flex items-center gap-1 text-xs text-stone-500 mt-1">
                      <Phone className="h-3 w-3" />
                      {booking.customer.phone}
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="text-stone-900">{booking.service}</div>
                    {booking.room && <div className="text-xs text-stone-500 mt-1">{booking.room}</div>}
                  </td>
                  <td className="py-4 px-4">
                    <div className="text-stone-900">{formatDate(booking.date)}</div>
                    <div className="text-xs text-stone-500 mt-1">
                      {formatTimeRange(booking.startTime, booking.endTime)}
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-stone-900">{booking.guests}</span>
                  </td>
                  <td className="py-4 px-4">
                    <StatusBadge status={booking.status} />
                  </td>
                  <td className="py-4 px-4">
                    <span className="font-medium text-stone-900">{formatCurrency(booking.amount)}</span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="sm" onClick={() => onViewBooking(booking)} className="h-8 w-8 p-0">
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View booking</span>
                      </Button>
                      {booking.status !== "cancelled" && booking.status !== "completed" && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onCancelBooking(booking)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Ban className="h-4 w-4" />
                          <span className="sr-only">Cancel booking</span>
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Cards */}
        <div className="lg:hidden space-y-4 p-4">
          {sortedBookings.map((booking) => (
            <div key={booking.id} className="border border-stone-200 rounded-lg p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-medium text-stone-900">{booking.reference}</div>
                  <div className="text-sm text-stone-600">{booking.customer.name}</div>
                </div>
                <StatusBadge status={booking.status} />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-stone-500">Service</div>
                  <div className="font-medium">{booking.service}</div>
                  {booking.room && <div className="text-xs text-stone-500">{booking.room}</div>}
                </div>
                <div>
                  <div className="text-stone-500">Date & Time</div>
                  <div className="font-medium">{formatDate(booking.date)}</div>
                  <div className="text-xs text-stone-500">{formatTimeRange(booking.startTime, booking.endTime)}</div>
                </div>
                <div>
                  <div className="text-stone-500">Guests</div>
                  <div className="font-medium">{booking.guests}</div>
                </div>
                <div>
                  <div className="text-stone-500">Amount</div>
                  <div className="font-medium">{formatCurrency(booking.amount)}</div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                <Button variant="outline" size="sm" onClick={() => onViewBooking(booking)} className="flex-1">
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </Button>
                {booking.status !== "cancelled" && booking.status !== "completed" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onCancelBooking(booking)}
                    className="flex-1 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    <Ban className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
