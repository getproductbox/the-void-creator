"use client"

import { useState, useMemo } from "react"
import { BookingsFilters, type BookingFilters as BookingFiltersType } from "./bookings-filters"
import { BookingsTable } from "./bookings-table"
import { Pagination } from "./pagination"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { useRouter } from "next/navigation"
import {
  mockBookings,
  getBookingsByDateRange,
  getBookingsByStatus,
  getBookingsByService,
  searchBookings,
  type Booking,
} from "../../../mock-data/bookings"

export function BookingsList() {
  const router = useRouter()

  // Filter state
  const [filters, setFilters] = useState<BookingFiltersType>({
    dateFrom: "",
    dateTo: "",
    status: "all",
    service: "all",
    search: "",
  })

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(20)

  // Apply filters to bookings
  const filteredBookings = useMemo(() => {
    let result = mockBookings

    // Apply date range filter
    if (filters.dateFrom && filters.dateTo) {
      result = getBookingsByDateRange(result, filters.dateFrom, filters.dateTo)
    } else if (filters.dateFrom) {
      result = result.filter((booking) => booking.date >= filters.dateFrom)
    } else if (filters.dateTo) {
      result = result.filter((booking) => booking.date <= filters.dateTo)
    }

    // Apply status filter
    result = getBookingsByStatus(result, filters.status)

    // Apply service filter
    result = getBookingsByService(result, filters.service)

    // Apply search filter
    result = searchBookings(result, filters.search)

    return result
  }, [filters])

  // Calculate pagination
  const totalPages = Math.ceil(filteredBookings.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedBookings = filteredBookings.slice(startIndex, endIndex)

  // Reset to first page when filters change
  const handleFiltersChange = (newFilters: BookingFiltersType) => {
    setFilters(newFilters)
    setCurrentPage(1)
  }

  const handleClearFilters = () => {
    setFilters({
      dateFrom: "",
      dateTo: "",
      status: "all",
      service: "all",
      search: "",
    })
    setCurrentPage(1)
  }

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }

  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage)
    setCurrentPage(1)
  }

  const handleViewBooking = (booking: Booking) => {
    console.log("View booking:", booking)
    // In a real app, this would navigate to booking details or open a modal
  }

  const handleCancelBooking = (booking: Booking) => {
    console.log("Cancel booking:", booking)
    // In a real app, this would show a confirmation dialog and update the booking
  }

  const handleCreateBooking = () => {
    router.push("/bookings/create")
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-stone-900">All Bookings</h1>
          <p className="text-stone-600 mt-1">Manage all venue bookings and reservations</p>
        </div>
        <Button onClick={handleCreateBooking} className="bg-orange-500 hover:bg-orange-600">
          <Plus className="h-4 w-4 mr-2" />
          Create Booking
        </Button>
      </div>

      {/* Filters */}
      <BookingsFilters filters={filters} onFiltersChange={handleFiltersChange} onClearFilters={handleClearFilters} />

      {/* Results Summary */}
      <div className="text-sm text-stone-600">
        {filteredBookings.length === mockBookings.length
          ? `Showing all ${filteredBookings.length} bookings`
          : `Showing ${filteredBookings.length} of ${mockBookings.length} bookings`}
      </div>

      {/* Table */}
      <BookingsTable
        bookings={paginatedBookings}
        onViewBooking={handleViewBooking}
        onCancelBooking={handleCancelBooking}
      />

      {/* Pagination */}
      {filteredBookings.length > 0 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          totalItems={filteredBookings.length}
          itemsPerPage={itemsPerPage}
          onPageChange={handlePageChange}
          onItemsPerPageChange={handleItemsPerPageChange}
        />
      )}
    </div>
  )
}
