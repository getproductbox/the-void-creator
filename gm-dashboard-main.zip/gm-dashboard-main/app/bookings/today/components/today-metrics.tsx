import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, Users, DollarSign } from "lucide-react"
import type { TodayMetrics } from "../../../../mock-data/todays-schedule"
import { formatCurrency, formatTime } from "../../../../mock-data/bookings"

interface TodayMetricsProps {
  metrics: TodayMetrics
}

export function TodayMetricsCards({ metrics }: TodayMetricsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Total Bookings */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-stone-600">Today's Bookings</CardTitle>
          <Calendar className="h-4 w-4 text-stone-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-stone-900">{metrics.totalBookings}</div>
          <div className="text-xs text-stone-500 mt-1">
            {metrics.confirmedBookings} confirmed, {metrics.pendingBookings} pending
          </div>
        </CardContent>
      </Card>

      {/* Revenue */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-stone-600">Today's Revenue</CardTitle>
          <DollarSign className="h-4 w-4 text-stone-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-stone-900">{formatCurrency(metrics.totalRevenue)}</div>
          <div className="text-xs text-stone-500 mt-1">From confirmed bookings</div>
        </CardContent>
      </Card>

      {/* Total Guests */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-stone-600">Expected Guests</CardTitle>
          <Users className="h-4 w-4 text-stone-400" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-stone-900">{metrics.totalGuests}</div>
          <div className="text-xs text-stone-500 mt-1">{metrics.roomsInUse} rooms in use</div>
        </CardContent>
      </Card>

      {/* Next Booking */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-stone-600">Next Booking</CardTitle>
          <Clock className="h-4 w-4 text-stone-400" />
        </CardHeader>
        <CardContent>
          {metrics.nextBooking ? (
            <>
              <div className="text-2xl font-bold text-stone-900">{formatTime(metrics.nextBooking.time)}</div>
              <div className="text-xs text-stone-500 mt-1 truncate">
                {metrics.nextBooking.customer} • {metrics.nextBooking.room}
              </div>
            </>
          ) : (
            <>
              <div className="text-2xl font-bold text-stone-500">—</div>
              <div className="text-xs text-stone-500 mt-1">No upcoming bookings</div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
