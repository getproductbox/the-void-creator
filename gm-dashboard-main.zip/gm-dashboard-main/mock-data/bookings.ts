export interface Booking {
  id: string
  reference: string
  customer: {
    name: string
    email: string
    phone: string
  }
  service: "Karaoke" | "Venue Hire" | "Event Tickets"
  date: string
  startTime: string
  endTime: string
  guests: number
  status: "confirmed" | "pending" | "cancelled" | "completed"
  amount: number
  room?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

// Generate comprehensive mock booking data
export const mockBookings: Booking[] = [
  {
    id: "book-001",
    reference: "MNR-2025-001",
    customer: {
      name: "Sarah Johnson",
      email: "sarah.johnson@email.com",
      phone: "+44 7123 456789",
    },
    service: "Karaoke",
    date: "2025-01-15",
    startTime: "10:00",
    endTime: "12:00",
    guests: 4,
    status: "confirmed",
    amount: 60.0,
    room: "Room A",
    notes: "Birthday party",
    createdAt: "2025-01-10T09:30:00Z",
    updatedAt: "2025-01-10T09:30:00Z",
  },
  {
    id: "book-002",
    reference: "MNR-2025-002",
    customer: {
      name: "Tech Startup Ltd",
      email: "events@techstartup.com",
      phone: "+44 7987 654321",
    },
    service: "Venue Hire",
    date: "2025-01-15",
    startTime: "12:30",
    endTime: "16:30",
    guests: 25,
    status: "confirmed",
    amount: 320.0,
    room: "Main Hall",
    notes: "Corporate event with catering",
    createdAt: "2025-01-08T14:20:00Z",
    updatedAt: "2025-01-12T10:15:00Z",
  },
  {
    id: "book-003",
    reference: "MNR-2025-003",
    customer: {
      name: "Mike Chen",
      email: "mike.chen@email.com",
      phone: "+44 7456 123789",
    },
    service: "Karaoke",
    date: "2025-01-15",
    startTime: "14:00",
    endTime: "17:00",
    guests: 6,
    status: "pending",
    amount: 90.0,
    room: "Room B",
    createdAt: "2025-01-14T16:45:00Z",
    updatedAt: "2025-01-14T16:45:00Z",
  },
  {
    id: "book-004",
    reference: "MNR-2025-004",
    customer: {
      name: "Emma Wilson",
      email: "emma.wilson@email.com",
      phone: "+44 7789 456123",
    },
    service: "Event Tickets",
    date: "2025-01-15",
    startTime: "16:00",
    endTime: "19:00",
    guests: 2,
    status: "confirmed",
    amount: 45.0,
    createdAt: "2025-01-12T11:30:00Z",
    updatedAt: "2025-01-12T11:30:00Z",
  },
  {
    id: "book-005",
    reference: "MNR-2025-005",
    customer: {
      name: "David Brown",
      email: "david.brown@email.com",
      phone: "+44 7321 987654",
    },
    service: "Karaoke",
    date: "2025-01-15",
    startTime: "18:30",
    endTime: "20:30",
    guests: 8,
    status: "cancelled",
    amount: 0.0,
    room: "Room C",
    notes: "Cancelled due to illness",
    createdAt: "2025-01-09T13:15:00Z",
    updatedAt: "2025-01-14T09:20:00Z",
  },
  {
    id: "book-006",
    reference: "MNR-2025-006",
    customer: {
      name: "Birthday Party Co",
      email: "bookings@birthdayparty.co.uk",
      phone: "+44 7654 321987",
    },
    service: "Venue Hire",
    date: "2025-01-16",
    startTime: "20:00",
    endTime: "23:00",
    guests: 15,
    status: "confirmed",
    amount: 180.0,
    room: "Private Room",
    createdAt: "2025-01-11T15:45:00Z",
    updatedAt: "2025-01-11T15:45:00Z",
  },
  {
    id: "book-007",
    reference: "MNR-2025-007",
    customer: {
      name: "James Mitchell",
      email: "james.mitchell@email.com",
      phone: "+44 7111 222333",
    },
    service: "Karaoke",
    date: "2025-01-16",
    startTime: "15:00",
    endTime: "17:00",
    guests: 5,
    status: "pending",
    amount: 75.0,
    room: "Room A",
    createdAt: "2025-01-15T10:30:00Z",
    updatedAt: "2025-01-15T10:30:00Z",
  },
  {
    id: "book-008",
    reference: "MNR-2025-008",
    customer: {
      name: "Corporate Events Ltd",
      email: "admin@corporateevents.com",
      phone: "+44 7444 555666",
    },
    service: "Venue Hire",
    date: "2025-01-17",
    startTime: "09:00",
    endTime: "17:00",
    guests: 40,
    status: "confirmed",
    amount: 640.0,
    room: "Main Hall",
    notes: "All-day conference with lunch",
    createdAt: "2025-01-05T09:00:00Z",
    updatedAt: "2025-01-10T14:30:00Z",
  },
  {
    id: "book-009",
    reference: "MNR-2025-009",
    customer: {
      name: "Lisa Thompson",
      email: "lisa.thompson@email.com",
      phone: "+44 7777 888999",
    },
    service: "Karaoke",
    date: "2025-01-17",
    startTime: "19:00",
    endTime: "21:00",
    guests: 3,
    status: "confirmed",
    amount: 45.0,
    room: "Room B",
    createdAt: "2025-01-16T12:15:00Z",
    updatedAt: "2025-01-16T12:15:00Z",
  },
  {
    id: "book-010",
    reference: "MNR-2025-010",
    customer: {
      name: "Wedding Planners Inc",
      email: "bookings@weddingplanners.co.uk",
      phone: "+44 7000 111222",
    },
    service: "Venue Hire",
    date: "2025-01-18",
    startTime: "14:00",
    endTime: "22:00",
    guests: 60,
    status: "pending",
    amount: 800.0,
    room: "Main Hall",
    notes: "Wedding reception - pending final headcount",
    createdAt: "2025-01-12T16:20:00Z",
    updatedAt: "2025-01-14T11:45:00Z",
  },
  {
    id: "book-011",
    reference: "MNR-2025-011",
    customer: {
      name: "Alex Rodriguez",
      email: "alex.rodriguez@email.com",
      phone: "+44 7333 444555",
    },
    service: "Karaoke",
    date: "2025-01-18",
    startTime: "16:00",
    endTime: "18:00",
    guests: 7,
    status: "confirmed",
    amount: 84.0,
    room: "Room C",
    createdAt: "2025-01-17T14:30:00Z",
    updatedAt: "2025-01-17T14:30:00Z",
  },
  {
    id: "book-012",
    reference: "MNR-2025-012",
    customer: {
      name: "Student Union",
      email: "events@studentunion.ac.uk",
      phone: "+44 7666 777888",
    },
    service: "Event Tickets",
    date: "2025-01-19",
    startTime: "20:00",
    endTime: "23:00",
    guests: 50,
    status: "confirmed",
    amount: 250.0,
    notes: "Student night event",
    createdAt: "2025-01-10T10:00:00Z",
    updatedAt: "2025-01-15T09:30:00Z",
  },
  {
    id: "book-013",
    reference: "MNR-2025-013",
    customer: {
      name: "Rachel Green",
      email: "rachel.green@email.com",
      phone: "+44 7999 000111",
    },
    service: "Karaoke",
    date: "2025-01-19",
    startTime: "13:00",
    endTime: "15:00",
    guests: 4,
    status: "cancelled",
    amount: 0.0,
    room: "Room A",
    notes: "Customer requested cancellation",
    createdAt: "2025-01-16T11:20:00Z",
    updatedAt: "2025-01-18T10:15:00Z",
  },
  {
    id: "book-014",
    reference: "MNR-2025-014",
    customer: {
      name: "Business Networking Group",
      email: "admin@businessnetwork.com",
      phone: "+44 7222 333444",
    },
    service: "Venue Hire",
    date: "2025-01-20",
    startTime: "18:00",
    endTime: "21:00",
    guests: 30,
    status: "confirmed",
    amount: 240.0,
    room: "Private Room",
    notes: "Monthly networking event",
    createdAt: "2025-01-13T15:45:00Z",
    updatedAt: "2025-01-13T15:45:00Z",
  },
  {
    id: "book-015",
    reference: "MNR-2025-015",
    customer: {
      name: "Tom Wilson",
      email: "tom.wilson@email.com",
      phone: "+44 7555 666777",
    },
    service: "Karaoke",
    date: "2025-01-20",
    startTime: "21:30",
    endTime: "23:30",
    guests: 6,
    status: "pending",
    amount: 72.0,
    room: "Room B",
    createdAt: "2025-01-19T16:30:00Z",
    updatedAt: "2025-01-19T16:30:00Z",
  },
  {
    id: "book-016",
    reference: "MNR-2024-156",
    customer: {
      name: "Holiday Party Organizers",
      email: "bookings@holidayparty.com",
      phone: "+44 7888 999000",
    },
    service: "Venue Hire",
    date: "2024-12-31",
    startTime: "20:00",
    endTime: "02:00",
    guests: 80,
    status: "completed",
    amount: 960.0,
    room: "Main Hall",
    notes: "New Year's Eve celebration",
    createdAt: "2024-11-15T10:00:00Z",
    updatedAt: "2025-01-01T03:00:00Z",
  },
  {
    id: "book-017",
    reference: "MNR-2025-017",
    customer: {
      name: "Sophie Davis",
      email: "sophie.davis@email.com",
      phone: "+44 7123 987654",
    },
    service: "Karaoke",
    date: "2025-01-21",
    startTime: "14:00",
    endTime: "16:00",
    guests: 5,
    status: "confirmed",
    amount: 60.0,
    room: "Room A",
    createdAt: "2025-01-18T13:20:00Z",
    updatedAt: "2025-01-18T13:20:00Z",
  },
  {
    id: "book-018",
    reference: "MNR-2025-018",
    customer: {
      name: "Charity Fundraiser Committee",
      email: "events@charity.org.uk",
      phone: "+44 7456 789012",
    },
    service: "Venue Hire",
    date: "2025-01-22",
    startTime: "19:00",
    endTime: "23:00",
    guests: 45,
    status: "pending",
    amount: 360.0,
    room: "Main Hall",
    notes: "Charity gala dinner - awaiting final confirmation",
    createdAt: "2025-01-14T09:15:00Z",
    updatedAt: "2025-01-17T14:20:00Z",
  },
  {
    id: "book-019",
    reference: "MNR-2025-019",
    customer: {
      name: "Mark Johnson",
      email: "mark.johnson@email.com",
      phone: "+44 7789 012345",
    },
    service: "Event Tickets",
    date: "2025-01-22",
    startTime: "20:30",
    endTime: "22:30",
    guests: 3,
    status: "confirmed",
    amount: 37.5,
    createdAt: "2025-01-20T11:45:00Z",
    updatedAt: "2025-01-20T11:45:00Z",
  },
  {
    id: "book-020",
    reference: "MNR-2025-020",
    customer: {
      name: "Anna Martinez",
      email: "anna.martinez@email.com",
      phone: "+44 7012 345678",
    },
    service: "Karaoke",
    date: "2025-01-23",
    startTime: "17:00",
    endTime: "19:00",
    guests: 4,
    status: "confirmed",
    amount: 48.0,
    room: "Room C",
    createdAt: "2025-01-21T15:30:00Z",
    updatedAt: "2025-01-21T15:30:00Z",
  },
  {
    id: "book-021",
    reference: "MNR-2025-021",
    customer: {
      name: "Local Sports Club",
      email: "admin@sportsclub.com",
      phone: "+44 7345 678901",
    },
    service: "Venue Hire",
    date: "2025-01-24",
    startTime: "15:00",
    endTime: "18:00",
    guests: 35,
    status: "pending",
    amount: 280.0,
    room: "Private Room",
    notes: "Awards ceremony",
    createdAt: "2025-01-19T12:00:00Z",
    updatedAt: "2025-01-20T16:30:00Z",
  },
  {
    id: "book-022",
    reference: "MNR-2025-022",
    customer: {
      name: "Jennifer Lee",
      email: "jennifer.lee@email.com",
      phone: "+44 7678 901234",
    },
    service: "Karaoke",
    date: "2025-01-24",
    startTime: "20:00",
    endTime: "22:00",
    guests: 6,
    status: "confirmed",
    amount: 72.0,
    room: "Room B",
    createdAt: "2025-01-22T10:15:00Z",
    updatedAt: "2025-01-22T10:15:00Z",
  },
]

// Helper functions for filtering and sorting
export const getBookingsByDateRange = (bookings: Booking[], startDate: string, endDate: string): Booking[] => {
  return bookings.filter((booking) => booking.date >= startDate && booking.date <= endDate)
}

export const getBookingsByStatus = (bookings: Booking[], status: string): Booking[] => {
  if (status === "all") return bookings
  return bookings.filter((booking) => booking.status === status)
}

export const getBookingsByService = (bookings: Booking[], service: string): Booking[] => {
  if (service === "all") return bookings
  return bookings.filter((booking) => booking.service === service)
}

export const searchBookings = (bookings: Booking[], searchTerm: string): Booking[] => {
  if (!searchTerm.trim()) return bookings

  const term = searchTerm.toLowerCase()
  return bookings.filter(
    (booking) =>
      booking.reference.toLowerCase().includes(term) ||
      booking.customer.name.toLowerCase().includes(term) ||
      booking.customer.email.toLowerCase().includes(term) ||
      booking.customer.phone.includes(term),
  )
}

export const sortBookings = (bookings: Booking[], sortBy: string, sortOrder: "asc" | "desc"): Booking[] => {
  return [...bookings].sort((a, b) => {
    let aValue: any
    let bValue: any

    switch (sortBy) {
      case "reference":
        aValue = a.reference
        bValue = b.reference
        break
      case "customer":
        aValue = a.customer.name
        bValue = b.customer.name
        break
      case "service":
        aValue = a.service
        bValue = b.service
        break
      case "date":
        aValue = new Date(a.date + "T" + a.startTime)
        bValue = new Date(b.date + "T" + b.startTime)
        break
      case "guests":
        aValue = a.guests
        bValue = b.guests
        break
      case "status":
        aValue = a.status
        bValue = b.status
        break
      case "amount":
        aValue = a.amount
        bValue = b.amount
        break
      default:
        aValue = a.createdAt
        bValue = b.createdAt
    }

    if (aValue < bValue) return sortOrder === "asc" ? -1 : 1
    if (aValue > bValue) return sortOrder === "asc" ? 1 : -1
    return 0
  })
}

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "GBP",
  }).format(amount)
}

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  })
}

export const formatTime = (time: string): string => {
  const [hours, minutes] = time.split(":")
  const hour = Number.parseInt(hours)
  const ampm = hour >= 12 ? "PM" : "AM"
  const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
  return `${displayHour}:${minutes} ${ampm}`
}

export const formatTimeRange = (startTime: string, endTime: string): string => {
  return `${formatTime(startTime)} - ${formatTime(endTime)}`
}
