"use client"

import { useState, useEffect } from "react"
import { X, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CustomerInfo } from "./customer-info"
import { BookingHistory } from "./booking-history"
import { CustomerActions } from "./customer-actions"
import { CustomerEditForm } from "./customer-edit-form"
import { mockCustomers, type Customer } from "@/mock-data/customers"
import { getCustomerBookings, getCustomerBookingStats } from "@/mock-data/customer-bookings"

interface CustomerProfilePanelProps {
  customerId: string | null
  isOpen: boolean
  onClose: () => void
  onCustomerUpdated?: (customer: Customer) => void
  onCreateBooking?: (customerId: string) => void
}

export function CustomerProfilePanel({
  customerId,
  isOpen,
  onClose,
  onCustomerUpdated,
  onCreateBooking,
}: CustomerProfilePanelProps) {
  const [customer, setCustomer] = useState<Customer | null>(null)
  const [bookings, setBookings] = useState<any[]>([])
  const [bookingStats, setBookingStats] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isEditMode, setIsEditMode] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Load customer data when panel opens
  useEffect(() => {
    if (isOpen && customerId) {
      loadCustomerData(customerId)
    }
  }, [isOpen, customerId])

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose()
      }
    }

    document.addEventListener("keydown", handleEscape)
    return () => document.removeEventListener("keydown", handleEscape)
  }, [isOpen, onClose])

  // Prevent body scroll when panel is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  const loadCustomerData = async (id: string) => {
    setIsLoading(true)
    setError(null)

    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      const customerData = mockCustomers.find((c) => c.id === id)
      if (!customerData) {
        throw new Error("Customer not found")
      }

      const customerBookings = getCustomerBookings(id)
      const stats = getCustomerBookingStats(customerBookings)

      setCustomer(customerData)
      setBookings(customerBookings)
      setBookingStats(stats)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load customer data")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCustomerUpdate = (updatedCustomer: Customer) => {
    setCustomer(updatedCustomer)
    setIsEditMode(false)
    onCustomerUpdated?.(updatedCustomer)
  }

  const handleCreateBooking = () => {
    if (customer) {
      onCreateBooking?.(customer.id)
      onClose()
    }
  }

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50 z-40 transition-opacity duration-300" onClick={onClose} />

      {/* Panel - Responsive width with content squeezing */}
      <div
        className={`
        fixed right-0 top-0 h-full bg-white shadow-2xl z-50 
        transform transition-transform duration-300 ease-in-out
        
        /* Mobile: Full width */
        w-full
        
        /* Small tablets: 90% width */
        sm:w-[90%]
        
        /* Medium screens: Adaptive width based on available space */
        md:w-[min(480px,45vw)]
        
        /* Large screens with sidebar: Optimized for sidebar presence */
        lg:w-[min(420px,calc(100vw-280px-2rem))]
        
        /* Extra large screens: Maximum comfortable width */
        xl:w-[min(450px,calc(100vw-280px-4rem))]
        
        /* Ultra wide screens: Cap the maximum width */
        2xl:w-[min(480px,calc(100vw-280px-6rem))]
        
        ${isOpen ? "translate-x-0" : "translate-x-full"}
      `}
      >
        <div className="flex flex-col h-full">
          {/* Header - Compact on smaller screens */}
          <div className="flex items-center justify-between p-4 lg:p-6 border-b border-stone-200 bg-stone-50 shrink-0">
            <div className="min-w-0 flex-1 mr-4">
              <h2 className="text-lg lg:text-xl font-semibold text-stone-900 truncate">
                {isLoading
                  ? "Loading..."
                  : customer
                    ? `${customer.firstName} ${customer.lastName}`
                    : "Customer Profile"}
              </h2>
              {customer && (
                <p className="text-xs lg:text-sm text-stone-600 mt-1 truncate">
                  Customer since {new Date(customer.customerSince).toLocaleDateString()}
                </p>
              )}
            </div>
            <Button variant="ghost" size="sm" onClick={onClose} className="h-8 w-8 p-0 shrink-0">
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Content - Scrollable with optimized spacing */}
          <div className="flex-1 overflow-y-auto">
            {isLoading && (
              <div className="flex items-center justify-center h-64">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-orange-500" />
                  <p className="text-stone-600 text-sm">Loading customer data...</p>
                </div>
              </div>
            )}

            {error && (
              <div className="p-4 lg:p-6">
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h3 className="text-red-800 font-medium text-sm">Error Loading Customer</h3>
                  <p className="text-red-600 text-xs mt-1">{error}</p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => customerId && loadCustomerData(customerId)}
                    className="mt-3"
                  >
                    Try Again
                  </Button>
                </div>
              </div>
            )}

            {customer && !isLoading && !error && (
              <div className="space-y-4 lg:space-y-6">
                {/* Customer Actions - Compact layout */}
                <div className="p-4 lg:p-6 pb-0">
                  <CustomerActions
                    customer={customer}
                    onCreateBooking={handleCreateBooking}
                    onEditCustomer={() => setIsEditMode(true)}
                    onSendEmail={() => console.log("Send email to", customer.email)}
                    onArchiveCustomer={() => console.log("Archive customer", customer.id)}
                  />
                </div>

                {/* Customer Information or Edit Form */}
                {isEditMode ? (
                  <div className="px-4 lg:px-6">
                    <CustomerEditForm
                      customer={customer}
                      onSave={handleCustomerUpdate}
                      onCancel={() => setIsEditMode(false)}
                    />
                  </div>
                ) : (
                  <div className="px-4 lg:px-6">
                    <CustomerInfo customer={customer} bookingStats={bookingStats} />
                  </div>
                )}

                {/* Booking History */}
                {!isEditMode && (
                  <div className="px-4 lg:px-6 pb-4 lg:pb-6">
                    <BookingHistory
                      bookings={bookings}
                      bookingStats={bookingStats}
                      onViewAllBookings={() => console.log("View all bookings for", customer.id)}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
