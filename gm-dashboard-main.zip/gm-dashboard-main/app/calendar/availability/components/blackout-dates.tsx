"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, Plus, Trash2, Download } from "lucide-react"
import { mockBlackoutDates, mockRoomSettings, type BlackoutDate } from "@/mock-data/availability"

interface BlackoutDatesProps {
  onChanges: () => void
}

export function BlackoutDates({ onChanges }: BlackoutDatesProps) {
  const [blackoutDates, setBlackoutDates] = useState<BlackoutDate[]>(mockBlackoutDates)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newBlackout, setNewBlackout] = useState<Partial<BlackoutDate>>({
    reason: "",
    type: "maintenance",
    affectedRooms: [],
    notes: "",
  })

  const rooms = [
    { id: "main-venue", name: "Main Venue" },
    ...mockRoomSettings.filter((room) => room.id !== "main-venue").map((room) => ({ id: room.id, name: room.name })),
  ]

  const reasonOptions = [
    { value: "maintenance", label: "Maintenance" },
    { value: "private-event", label: "Private Event" },
    { value: "holiday", label: "Holiday" },
    { value: "other", label: "Other" },
  ]

  const handleAddBlackout = () => {
    if (!newBlackout.date || !newBlackout.reason || !newBlackout.affectedRooms?.length) {
      return
    }

    const blackout: BlackoutDate = {
      id: Date.now().toString(),
      date: newBlackout.date!,
      endDate: newBlackout.endDate,
      reason: newBlackout.reason!,
      type: newBlackout.type as BlackoutDate["type"],
      affectedRooms: newBlackout.affectedRooms!,
      notes: newBlackout.notes,
      isRecurring: newBlackout.isRecurring,
      recurringPattern: newBlackout.recurringPattern,
    }

    setBlackoutDates([...blackoutDates, blackout])
    setNewBlackout({
      reason: "",
      type: "maintenance",
      affectedRooms: [],
      notes: "",
    })
    setShowAddForm(false)
    onChanges()
  }

  const handleDeleteBlackout = (id: string) => {
    setBlackoutDates(blackoutDates.filter((b) => b.id !== id))
    onChanges()
  }

  const handleRoomToggle = (roomId: string, checked: boolean) => {
    const currentRooms = newBlackout.affectedRooms || []
    if (checked) {
      setNewBlackout({
        ...newBlackout,
        affectedRooms: [...currentRooms, roomId],
      })
    } else {
      setNewBlackout({
        ...newBlackout,
        affectedRooms: currentRooms.filter((id) => id !== roomId),
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
    })
  }

  const getTypeColor = (type: BlackoutDate["type"]) => {
    switch (type) {
      case "maintenance":
        return "bg-blue-100 text-blue-800"
      case "private-event":
        return "bg-purple-100 text-purple-800"
      case "holiday":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Blackout Dates
              </CardTitle>
              <CardDescription>Manage dates when the venue or specific rooms are unavailable</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Import Holidays
              </Button>
              <Button onClick={() => setShowAddForm(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Blackout Date
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Add Blackout Form */}
      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Blackout Date</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start-date">Start Date</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={newBlackout.date || ""}
                  onChange={(e) => setNewBlackout({ ...newBlackout, date: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="end-date">End Date (Optional)</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={newBlackout.endDate || ""}
                  onChange={(e) => setNewBlackout({ ...newBlackout, endDate: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="reason">Reason</Label>
                <Input
                  id="reason"
                  value={newBlackout.reason || ""}
                  onChange={(e) => setNewBlackout({ ...newBlackout, reason: e.target.value })}
                  placeholder="e.g., Equipment maintenance"
                />
              </div>
              <div>
                <Label htmlFor="type">Type</Label>
                <Select
                  value={newBlackout.type}
                  onValueChange={(value) => setNewBlackout({ ...newBlackout, type: value as BlackoutDate["type"] })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {reasonOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Affected Rooms</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {rooms.map((room) => (
                  <div key={room.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={room.id}
                      checked={newBlackout.affectedRooms?.includes(room.id)}
                      onCheckedChange={(checked) => handleRoomToggle(room.id, checked as boolean)}
                    />
                    <Label htmlFor={room.id} className="text-sm">
                      {room.name}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={newBlackout.notes || ""}
                onChange={(e) => setNewBlackout({ ...newBlackout, notes: e.target.value })}
                placeholder="Additional details about this blackout period..."
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="recurring"
                checked={newBlackout.isRecurring || false}
                onCheckedChange={(checked) => setNewBlackout({ ...newBlackout, isRecurring: checked as boolean })}
              />
              <Label htmlFor="recurring">Recurring blackout</Label>
            </div>

            {newBlackout.isRecurring && (
              <div>
                <Label htmlFor="pattern">Recurring Pattern</Label>
                <Select
                  value={newBlackout.recurringPattern}
                  onValueChange={(value) =>
                    setNewBlackout({ ...newBlackout, recurringPattern: value as BlackoutDate["recurringPattern"] })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select pattern" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={handleAddBlackout}>Add Blackout Date</Button>
              <Button variant="outline" onClick={() => setShowAddForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Blackout Dates List */}
      <Card>
        <CardHeader>
          <CardTitle>Current Blackout Dates</CardTitle>
        </CardHeader>
        <CardContent>
          {blackoutDates.length === 0 ? (
            <div className="text-center py-8 text-stone-500">
              <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No blackout dates configured</p>
            </div>
          ) : (
            <div className="space-y-3">
              {blackoutDates.map((blackout) => (
                <div
                  key={blackout.id}
                  className="flex items-center justify-between p-4 border border-stone-200 rounded-lg"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-medium">
                        {formatDate(blackout.date)}
                        {blackout.endDate && ` - ${formatDate(blackout.endDate)}`}
                      </span>
                      <Badge className={getTypeColor(blackout.type)}>{blackout.type.replace("-", " ")}</Badge>
                      {blackout.isRecurring && <Badge variant="outline">{blackout.recurringPattern}</Badge>}
                    </div>
                    <p className="text-stone-900 mb-1">{blackout.reason}</p>
                    <div className="flex items-center gap-2 text-sm text-stone-600">
                      <span>Affects:</span>
                      {blackout.affectedRooms.map((roomId) => {
                        const room = rooms.find((r) => r.id === roomId)
                        return (
                          <Badge key={roomId} variant="secondary" className="text-xs">
                            {room?.name}
                          </Badge>
                        )
                      })}
                    </div>
                    {blackout.notes && <p className="text-sm text-stone-600 mt-1">{blackout.notes}</p>}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteBlackout(blackout.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
