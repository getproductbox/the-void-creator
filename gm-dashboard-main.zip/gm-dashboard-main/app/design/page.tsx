"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, Users, Edit, AlertCircle, Settings } from "lucide-react"

// Design System Components
const ColorSwatch = ({ name, value, textColor = "black" }: { name: string; value: string; textColor?: string }) => (
  <div className="flex flex-col">
    <div
      className="w-20 h-20 rounded-lg border border-gray-200 flex items-center justify-center text-xs font-medium"
      style={{ backgroundColor: value, color: textColor }}
    >
      {name.split("-").pop()}
    </div>
    <div className="mt-2 text-xs">
      <div className="font-medium">{name}</div>
      <div className="text-gray-500">{value}</div>
    </div>
  </div>
)

const TypographyExample = ({
  className,
  children,
  description,
}: { className: string; children: React.ReactNode; description: string }) => (
  <div className="space-y-2">
    <div className={className}>{children}</div>
    <div className="text-sm text-gray-500">{description}</div>
  </div>
)

const SpacingExample = ({ size, value }: { size: string; value: string }) => (
  <div className="flex items-center gap-4">
    <div className="w-16 text-sm font-mono">{size}</div>
    <div className="bg-orange-500 h-4" style={{ width: value }} />
    <div className="text-sm text-gray-500">{value}</div>
  </div>
)

// Atomic Components
const GMButton = ({
  variant = "primary",
  size = "md",
  children,
  disabled = false,
  ...props
}: {
  variant?: "primary" | "secondary" | "ghost"
  size?: "sm" | "md" | "lg"
  children: React.ReactNode
  disabled?: boolean
  [key: string]: any
}) => {
  const baseClasses =
    "gm-button font-medium border-none cursor-pointer inline-flex items-center justify-center gap-2 transition-all duration-150 rounded-lg"

  const sizeClasses = {
    sm: "px-3 py-2 text-sm min-h-8",
    md: "px-4 py-3 text-base min-h-10",
    lg: "px-6 py-4 text-lg min-h-12",
  }

  const variantClasses = {
    primary:
      "bg-orange-500 text-white hover:bg-orange-600 hover:-translate-y-0.5 hover:shadow-md active:translate-y-0 active:bg-orange-700",
    secondary: "bg-white text-stone-700 border border-stone-300 hover:bg-stone-50 hover:border-stone-400",
    ghost: "bg-transparent text-orange-600 hover:bg-orange-50",
  }

  const disabledClasses = disabled ? "cursor-not-allowed opacity-60" : ""

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${disabledClasses}`}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  )
}

const GMInput = ({ error = false, ...props }) => (
  <input
    className={`w-full px-4 py-3 border rounded-lg bg-white transition-all duration-150 focus:outline-none focus:border-orange-500 focus:shadow-[0_0_0_3px_rgb(255_237_213)] ${
      error ? "border-red-500 focus:shadow-[0_0_0_3px_rgb(254_242_242)]" : "border-stone-300"
    } placeholder:text-stone-400`}
    {...props}
  />
)

const FormField = ({
  label,
  error,
  hint,
  required,
  children,
}: {
  label: string
  error?: string
  hint?: string
  required?: boolean
  children: React.ReactNode
}) => (
  <div className="space-y-2">
    <label className="block text-sm font-medium text-stone-700">
      {label}
      {required && <span className="text-red-500 ml-1">*</span>}
    </label>
    {hint && <p className="text-sm text-stone-500">{hint}</p>}
    {children}
    {error && (
      <p className="text-sm text-red-500 flex items-center gap-1" role="alert">
        <AlertCircle className="w-4 h-4" />
        {error}
      </p>
    )}
  </div>
)

const StatusBadge = ({
  status,
  size = "md",
}: { status: "confirmed" | "pending" | "cancelled" | "completed"; size?: "sm" | "md" }) => {
  const statusConfig = {
    confirmed: { color: "bg-green-100 text-green-700", icon: "✓" },
    pending: { color: "bg-yellow-100 text-yellow-700", icon: "⏳" },
    cancelled: { color: "bg-gray-100 text-gray-700", icon: "✕" },
    completed: { color: "bg-blue-100 text-blue-700", icon: "✓" },
  }

  const sizeClasses = size === "sm" ? "px-2 py-1 text-xs" : "px-3 py-1 text-sm"

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full font-medium ${statusConfig[status].color} ${sizeClasses}`}
    >
      <span>{statusConfig[status].icon}</span>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}

const TimeSlotSelector = () => {
  const [selected, setSelected] = useState("14:00")

  const slots = [
    { startTime: "12:00", price: 25, available: true },
    { startTime: "14:00", price: 30, available: true },
    { startTime: "16:00", price: 35, available: true },
    { startTime: "18:00", price: 40, available: false },
    { startTime: "20:00", price: 45, available: true },
  ]

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Available Times</h3>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {slots.map((slot) => (
          <button
            key={slot.startTime}
            className={`p-3 rounded-lg border-2 transition-all duration-150 ${
              selected === slot.startTime
                ? "border-orange-500 bg-orange-50"
                : slot.available
                  ? "border-stone-200 hover:border-stone-300 bg-white"
                  : "border-stone-200 bg-stone-50 cursor-not-allowed opacity-50"
            }`}
            onClick={() => slot.available && setSelected(slot.startTime)}
            disabled={!slot.available}
          >
            <div className="text-sm font-medium">{slot.startTime}</div>
            <div className="text-xs text-stone-600">£{slot.price}</div>
          </button>
        ))}
      </div>
    </div>
  )
}

const BookingSummary = () => {
  const booking = {
    service: "Karaoke Room",
    date: "2025-01-15",
    time: "14:00",
    duration: 2,
    guests: 6,
    venue: "Manor",
    room: "Room A",
  }

  const pricing = {
    basePrice: 60,
    fees: [{ name: "Service fee", amount: 5 }],
    total: 65,
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg">Booking Summary</CardTitle>
        <Button variant="ghost" size="sm">
          <Edit className="w-4 h-4 mr-1" />
          Edit
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <Calendar className="w-5 h-5 text-stone-500 mt-0.5" />
            <div>
              <p className="text-sm text-stone-500">Date & Time</p>
              <p className="font-medium">Jan 15, 2025 at 2:00 PM</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-stone-500 mt-0.5" />
            <div>
              <p className="text-sm text-stone-500">Duration</p>
              <p className="font-medium">{booking.duration} hours</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-stone-500 mt-0.5" />
            <div>
              <p className="text-sm text-stone-500">Guests</p>
              <p className="font-medium">{booking.guests} people</p>
            </div>
          </div>
        </div>

        <div className="border-t pt-4 space-y-2">
          <div className="flex justify-between">
            <span>Base price ({booking.duration}h)</span>
            <span>£{pricing.basePrice.toFixed(2)}</span>
          </div>
          {pricing.fees.map((fee) => (
            <div key={fee.name} className="flex justify-between text-sm text-stone-600">
              <span>{fee.name}</span>
              <span>£{fee.amount.toFixed(2)}</span>
            </div>
          ))}
          <div className="flex justify-between font-semibold text-lg border-t pt-2">
            <span>Total</span>
            <span>£{pricing.total.toFixed(2)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function DesignSystemPage() {
  return (
    <div className="min-h-screen bg-stone-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-stone-900 mb-4">GM Design System</h1>
          <p className="text-lg text-stone-600">
            A comprehensive design system for the GM venue booking platform, built on atomic design principles and
            featuring Plus Jakarta Sans typography for enhanced readability and modern aesthetics.
          </p>
        </div>

        {/* Design Tokens */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-stone-900 mb-8">Design Tokens</h2>

          {/* Colors */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Color System</h3>

            <div className="mb-8">
              <h4 className="text-lg font-medium text-stone-700 mb-4">Primary Palette</h4>
              <div className="flex flex-wrap gap-4">
                <ColorSwatch name="primary-50" value="#fff7ed" />
                <ColorSwatch name="primary-100" value="#ffedd5" />
                <ColorSwatch name="primary-200" value="#fed7aa" />
                <ColorSwatch name="primary-300" value="#fdba74" />
                <ColorSwatch name="primary-400" value="#fb923c" />
                <ColorSwatch name="primary-500" value="#f97316" textColor="white" />
                <ColorSwatch name="primary-600" value="#ea580c" textColor="white" />
                <ColorSwatch name="primary-700" value="#c2410c" textColor="white" />
                <ColorSwatch name="primary-800" value="#9a3412" textColor="white" />
                <ColorSwatch name="primary-900" value="#7c2d12" textColor="white" />
              </div>
            </div>

            <div className="mb-8">
              <h4 className="text-lg font-medium text-stone-700 mb-4">Neutral Palette</h4>
              <div className="flex flex-wrap gap-4">
                <ColorSwatch name="neutral-0" value="#ffffff" />
                <ColorSwatch name="neutral-50" value="#fafaf9" />
                <ColorSwatch name="neutral-100" value="#f5f5f4" />
                <ColorSwatch name="neutral-200" value="#e7e5e4" />
                <ColorSwatch name="neutral-300" value="#d6d3d1" />
                <ColorSwatch name="neutral-400" value="#a8a29e" textColor="white" />
                <ColorSwatch name="neutral-500" value="#78716c" textColor="white" />
                <ColorSwatch name="neutral-600" value="#57534e" textColor="white" />
                <ColorSwatch name="neutral-700" value="#44403c" textColor="white" />
                <ColorSwatch name="neutral-800" value="#292524" textColor="white" />
                <ColorSwatch name="neutral-900" value="#1c1917" textColor="white" />
              </div>
            </div>

            <div>
              <h4 className="text-lg font-medium text-stone-700 mb-4">Semantic Colors</h4>
              <div className="flex flex-wrap gap-4">
                <ColorSwatch name="success" value="#22c55e" textColor="white" />
                <ColorSwatch name="warning" value="#f59e0b" textColor="white" />
                <ColorSwatch name="error" value="#ef4444" textColor="white" />
                <ColorSwatch name="info" value="#3b82f6" textColor="white" />
              </div>
            </div>
          </div>

          {/* Typography */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Typography - Plus Jakarta Sans</h3>
            <div className="space-y-6">
              <TypographyExample className="gm-heading-1" description="Heading 1 - 51px, ExtraBold (800)">
                The quick brown fox
              </TypographyExample>
              <TypographyExample className="gm-heading-2" description="Heading 2 - 38px, Bold (700)">
                The quick brown fox
              </TypographyExample>
              <TypographyExample className="gm-heading-3" description="Heading 3 - 28px, SemiBold (600)">
                The quick brown fox
              </TypographyExample>
              <TypographyExample className="gm-heading-4" description="Heading 4 - 21px, SemiBold (600)">
                The quick brown fox
              </TypographyExample>
              <TypographyExample className="gm-body-large" description="Body Large - 18px, Regular (400)">
                The quick brown fox jumps over the lazy dog. This is an example of body large text used for important
                content that needs more prominence.
              </TypographyExample>
              <TypographyExample className="gm-body" description="Body - 16px, Regular (400)">
                The quick brown fox jumps over the lazy dog. This is the standard body text used throughout the
                application for most content.
              </TypographyExample>
              <TypographyExample className="gm-body-small" description="Body Small - 14px, Regular (400)">
                The quick brown fox jumps over the lazy dog. This is small body text used for secondary information and
                supporting details.
              </TypographyExample>
              <TypographyExample className="gm-caption" description="Caption - 12px, Medium (500), Uppercase">
                The quick brown fox
              </TypographyExample>
            </div>
          </div>

          {/* Spacing */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Spacing System</h3>
            <div className="space-y-3">
              <SpacingExample size="space-1" value="4px" />
              <SpacingExample size="space-2" value="8px" />
              <SpacingExample size="space-3" value="12px" />
              <SpacingExample size="space-4" value="16px" />
              <SpacingExample size="space-5" value="20px" />
              <SpacingExample size="space-6" value="24px" />
              <SpacingExample size="space-8" value="32px" />
              <SpacingExample size="space-10" value="40px" />
              <SpacingExample size="space-12" value="48px" />
              <SpacingExample size="space-16" value="64px" />
            </div>
          </div>
        </section>

        {/* Atomic Components */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-stone-900 mb-8">Atomic Components</h2>

          {/* Buttons */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Buttons</h3>

            <div className="mb-8">
              <h4 className="text-lg font-medium text-stone-700 mb-4">Variants</h4>
              <div className="flex flex-wrap gap-4">
                <GMButton variant="primary">Primary Button</GMButton>
                <GMButton variant="secondary">Secondary Button</GMButton>
                <GMButton variant="ghost">Ghost Button</GMButton>
                <GMButton variant="primary" disabled>
                  Disabled Button
                </GMButton>
              </div>
            </div>

            <div className="mb-8">
              <h4 className="text-lg font-medium text-stone-700 mb-4">Sizes</h4>
              <div className="flex flex-wrap items-center gap-4">
                <GMButton size="sm">Small</GMButton>
                <GMButton size="md">Medium</GMButton>
                <GMButton size="lg">Large</GMButton>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-medium text-stone-700 mb-4">With Icons</h4>
              <div className="flex flex-wrap gap-4">
                <GMButton variant="primary">
                  <Calendar className="w-4 h-4" />
                  Book Now
                </GMButton>
                <GMButton variant="secondary">
                  <Edit className="w-4 h-4" />
                  Edit
                </GMButton>
                <GMButton variant="ghost">
                  <Settings className="w-4 h-4" />
                  Settings
                </GMButton>
              </div>
            </div>
          </div>

          {/* Form Inputs */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Form Inputs</h3>
            <div className="max-w-md space-y-6">
              <FormField label="Email Address" required>
                <GMInput type="email" placeholder="Enter your email" />
              </FormField>

              <FormField label="Phone Number" hint="Include country code">
                <GMInput type="tel" placeholder="+44 7123 456789" />
              </FormField>

              <FormField label="Password" error="Password must be at least 8 characters">
                <GMInput type="password" placeholder="Enter password" error />
              </FormField>
            </div>
          </div>

          {/* Status Badges */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Status Badges</h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-lg font-medium text-stone-700 mb-3">Standard Size</h4>
                <div className="flex flex-wrap gap-3">
                  <StatusBadge status="confirmed" />
                  <StatusBadge status="pending" />
                  <StatusBadge status="cancelled" />
                  <StatusBadge status="completed" />
                </div>
              </div>

              <div>
                <h4 className="text-lg font-medium text-stone-700 mb-3">Small Size</h4>
                <div className="flex flex-wrap gap-3">
                  <StatusBadge status="confirmed" size="sm" />
                  <StatusBadge status="pending" size="sm" />
                  <StatusBadge status="cancelled" size="sm" />
                  <StatusBadge status="completed" size="sm" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Molecular Components */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-stone-900 mb-8">Molecular Components</h2>

          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Time Slot Selector</h3>
            <div className="max-w-2xl">
              <TimeSlotSelector />
            </div>
          </div>
        </section>

        {/* Organism Components */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-stone-900 mb-8">Organism Components</h2>

          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Booking Summary Card</h3>
            <BookingSummary />
          </div>
        </section>

        {/* Layout Examples */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-stone-900 mb-8">Layout Systems</h2>

          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-stone-800 mb-6">Grid System</h3>
            <div className="space-y-6">
              <div>
                <h4 className="text-lg font-medium text-stone-700 mb-3">2 Column Grid</h4>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-orange-100 p-6 rounded-lg text-center">Column 1</div>
                  <div className="bg-orange-100 p-6 rounded-lg text-center">Column 2</div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-medium text-stone-700 mb-3">3 Column Grid</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-orange-100 p-6 rounded-lg text-center">Column 1</div>
                  <div className="bg-orange-100 p-6 rounded-lg text-center">Column 2</div>
                  <div className="bg-orange-100 p-6 rounded-lg text-center">Column 3</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Usage Guidelines */}
        <section>
          <h2 className="text-3xl font-bold text-stone-900 mb-8">Usage Guidelines</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Do's</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Use consistent spacing from the 4px grid system</li>
                  <li>• Maintain proper color contrast ratios (4.5:1 minimum)</li>
                  <li>• Use semantic colors for status indicators</li>
                  <li>• Follow the established typography hierarchy</li>
                  <li>• Ensure components are accessible and keyboard navigable</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Don'ts</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Don't use colors outside the defined palette</li>
                  <li>• Don't create custom spacing values</li>
                  <li>• Don't mix different button styles in the same context</li>
                  <li>• Don't ignore accessibility requirements</li>
                  <li>• Don't modify component styles without updating the system</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </div>
  )
}
