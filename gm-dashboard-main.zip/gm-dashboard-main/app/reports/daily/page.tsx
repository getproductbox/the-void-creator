export default function DailyReportsPage() {
  return (
    <div className="space-y-6">
      <div className="border-b border-stone-200 pb-4">
        <h1 className="text-3xl font-bold text-stone-900">Daily Reports</h1>
        <p className="text-stone-600 mt-1">Today's performance metrics and operational insights.</p>
      </div>

      <div className="bg-white rounded-lg border border-stone-200 p-8 text-center">
        <h2 className="text-xl font-semibold text-stone-700 mb-2">Today's Performance</h2>
        <p className="text-stone-500">This page will show detailed daily reports and metrics.</p>
      </div>
    </div>
  )
}
