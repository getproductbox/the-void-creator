# User Guides

This directory contains user-facing documentation and guides.

## Guide Categories

- **Getting Started**: Onboarding and initial setup
- **Features**: Detailed feature explanations
- **Tutorials**: Step-by-step instructions
- **Troubleshooting**: Common issues and solutions

## Writing Guidelines

1. **Audience**: Write for end users, not developers
2. **Clarity**: Use simple, clear language
3. **Structure**: Use headings, bullet points, and numbered lists
4. **Screenshots**: Include relevant screenshots and diagrams
5. **Updates**: Keep guides current with product changes

## Review Process

- Technical writers review for clarity and accuracy
- Product team reviews for completeness
- User testing validates guide effectiveness
