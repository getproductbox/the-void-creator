"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, Edit, Phone } from "lucide-react"
import type { TodaysBooking } from "../../../../mock-data/dashboard"

interface ScheduleTableProps {
  bookings: TodaysBooking[]
}

const StatusBadge = ({ status }: { status: TodaysBooking["status"] }) => {
  const statusConfig = {
    confirmed: {
      color: "bg-green-100 text-green-700 border-green-200",
      icon: "✓",
      label: "Confirmed",
    },
    pending: {
      color: "bg-yellow-100 text-yellow-700 border-yellow-200",
      icon: "⏳",
      label: "Pending",
    },
    cancelled: {
      color: "bg-red-100 text-red-700 border-red-200",
      icon: "✕",
      label: "Cancelled",
    },
    completed: {
      color: "bg-blue-100 text-blue-700 border-blue-200",
      icon: "✓",
      label: "Completed",
    },
  }

  const config = statusConfig[status]

  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${config.color}`}
    >
      <span>{config.icon}</span>
      {config.label}
    </span>
  )
}

export function ScheduleTable({ bookings }: ScheduleTableProps) {
  const handleViewBooking = (bookingId: string) => {
    console.log("View booking:", bookingId)
  }

  const handleEditBooking = (bookingId: string) => {
    console.log("Edit booking:", bookingId)
  }

  const handleCallCustomer = (phone: string) => {
    console.log("Call customer:", phone)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Today's Schedule</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone-200">
                <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Time</th>
                <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Service</th>
                <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Customer</th>
                <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Guests</th>
                <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Status</th>
                <th className="text-left py-3 px-2 text-sm font-medium text-stone-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id} className="border-b border-stone-100 hover:bg-stone-50">
                  <td className="py-4 px-2">
                    <div className="text-sm font-medium text-stone-900">{booking.time}</div>
                    {booking.room && <div className="text-xs text-stone-500">{booking.room}</div>}
                  </td>
                  <td className="py-4 px-2">
                    <div className="text-sm text-stone-900">{booking.service}</div>
                    <div className="text-xs text-stone-500">{booking.duration}h duration</div>
                  </td>
                  <td className="py-4 px-2">
                    <div className="text-sm font-medium text-stone-900">{booking.customer.name}</div>
                    <div className="flex items-center gap-1 mt-1">
                      <Phone className="h-3 w-3 text-stone-400" />
                      <button
                        onClick={() => handleCallCustomer(booking.customer.phone)}
                        className="text-xs text-stone-500 hover:text-orange-600 transition-colors"
                      >
                        {booking.customer.phone}
                      </button>
                    </div>
                  </td>
                  <td className="py-4 px-2">
                    <span className="text-sm text-stone-900">{booking.guests}</span>
                  </td>
                  <td className="py-4 px-2">
                    <StatusBadge status={booking.status} />
                  </td>
                  <td className="py-4 px-2">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewBooking(booking.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditBooking(booking.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
