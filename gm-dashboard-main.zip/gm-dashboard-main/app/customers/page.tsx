"use client"

import { useState, useMemo } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CustomerStats } from "./components/customer-stats"
import { CustomerFilters } from "./components/customer-filters"
import { CustomersTable } from "./components/customers-table"
import { CustomerProfilePanel } from "./components/customer-profile-panel"
import { mockCustomers, getCustomerStats, filterCustomers, sortCustomers, type Customer } from "@/mock-data/customers"

const ITEMS_PER_PAGE = 20

export default function CustomersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date } | undefined>()
  const [sortColumn, setSortColumn] = useState("customerSince")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc")
  const [currentPage, setCurrentPage] = useState(1)

  // Profile panel state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null)
  const [isPanelOpen, setIsPanelOpen] = useState(false)

  // Get customer statistics
  const stats = getCustomerStats()

  // Filter and sort customers
  const filteredCustomers = useMemo(() => {
    const filtered = filterCustomers(mockCustomers, searchTerm, statusFilter, dateRange)
    return sortCustomers(filtered, sortColumn, sortOrder)
  }, [searchTerm, statusFilter, dateRange, sortColumn, sortOrder])

  // Paginate customers
  const paginatedCustomers = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
    return filteredCustomers.slice(startIndex, startIndex + ITEMS_PER_PAGE)
  }, [filteredCustomers, currentPage])

  const totalPages = Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE)

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortColumn(column)
      setSortOrder("asc")
    }
    setCurrentPage(1) // Reset to first page when sorting
  }

  const handleClearFilters = () => {
    setSearchTerm("")
    setStatusFilter("all")
    setDateRange(undefined)
    setCurrentPage(1)
  }

  const handleAddCustomer = () => {
    console.log("Add new customer")
    // TODO: Navigate to add customer form or open modal
  }

  const handleViewProfile = (customerId: string) => {
    setSelectedCustomerId(customerId)
    setIsPanelOpen(true)
  }

  const handleClosePanel = () => {
    setIsPanelOpen(false)
    setSelectedCustomerId(null)
  }

  const handleCustomerUpdated = (updatedCustomer: Customer) => {
    console.log("Customer updated:", updatedCustomer)
    // TODO: Update the customer in the main list
    // In a real app, this would update the state or refetch data
  }

  const handleCreateBooking = (customerId: string) => {
    console.log("Create booking for customer:", customerId)
    // TODO: Navigate to booking creation with customer pre-filled
  }

  // Update current page when filters change
  const handleSearchChange = (value: string) => {
    setSearchTerm(value)
    setCurrentPage(1)
  }

  const handleStatusFilterChange = (value: string) => {
    setStatusFilter(value)
    setCurrentPage(1)
  }

  const handleDateRangeChange = (range?: { from: Date; to: Date }) => {
    setDateRange(range)
    setCurrentPage(1)
  }

  return (
    <>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-stone-900">Customers</h1>
            <p className="text-stone-600 mt-1">Manage your customer database and relationships</p>
          </div>
          <Button onClick={handleAddCustomer} className="bg-orange-500 hover:bg-orange-600">
            <Plus className="h-4 w-4 mr-2" />
            Add New Customer
          </Button>
        </div>

        {/* Customer Statistics */}
        <CustomerStats
          totalCustomers={stats.totalCustomers}
          newThisMonth={stats.newThisMonth}
          returningRate={stats.returningRate}
        />

        {/* Filters */}
        <CustomerFilters
          searchTerm={searchTerm}
          onSearchChange={handleSearchChange}
          statusFilter={statusFilter}
          onStatusFilterChange={handleStatusFilterChange}
          dateRange={dateRange}
          onDateRangeChange={handleDateRangeChange}
          onClearFilters={handleClearFilters}
          totalResults={filteredCustomers.length}
        />

        {/* Customers Table */}
        <CustomersTable
          customers={paginatedCustomers}
          onSort={handleSort}
          sortColumn={sortColumn}
          sortOrder={sortOrder}
          onViewProfile={handleViewProfile}
          onCreateBooking={handleCreateBooking}
        />

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-stone-600">
              Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
              {Math.min(currentPage * ITEMS_PER_PAGE, filteredCustomers.length)} of {filteredCustomers.length} customers
            </p>

            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                Previous
              </Button>

              <div className="flex items-center space-x-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const pageNumber = i + 1
                  return (
                    <Button
                      key={pageNumber}
                      variant={currentPage === pageNumber ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(pageNumber)}
                      className={currentPage === pageNumber ? "bg-orange-500 hover:bg-orange-600" : ""}
                    >
                      {pageNumber}
                    </Button>
                  )
                })}
                {totalPages > 5 && (
                  <>
                    <span className="text-stone-400">...</span>
                    <Button
                      variant={currentPage === totalPages ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(totalPages)}
                      className={currentPage === totalPages ? "bg-orange-500 hover:bg-orange-600" : ""}
                    >
                      {totalPages}
                    </Button>
                  </>
                )}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Customer Profile Panel */}
      <CustomerProfilePanel
        customerId={selectedCustomerId}
        isOpen={isPanelOpen}
        onClose={handleClosePanel}
        onCustomerUpdated={handleCustomerUpdated}
        onCreateBooking={handleCreateBooking}
      />
    </>
  )
}
