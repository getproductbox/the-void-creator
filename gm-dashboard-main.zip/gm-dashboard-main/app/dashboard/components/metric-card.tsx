import type React from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface MetricCardProps {
  title: string
  value: string | number
  subtitle?: string
  trend?: {
    value: number
    direction: "up" | "down" | "neutral"
    label: string
  }
  breakdown?: Array<{
    label: string
    value: number
    color?: string
  }>
  icon?: React.ReactNode
}

export function MetricCard({ title, value, subtitle, trend, breakdown, icon }: MetricCardProps) {
  const getTrendIcon = () => {
    switch (trend?.direction) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <Minus className="h-4 w-4 text-stone-400" />
    }
  }

  const getTrendColor = () => {
    switch (trend?.direction) {
      case "up":
        return "text-green-600"
      case "down":
        return "text-red-600"
      default:
        return "text-stone-500"
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-stone-600">{title}</CardTitle>
        {icon && <div className="text-stone-400">{icon}</div>}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-stone-900">{value}</div>

        {subtitle && <p className="text-xs text-stone-500 mt-1">{subtitle}</p>}

        {trend && (
          <div className="flex items-center mt-2">
            {getTrendIcon()}
            <span className={`text-xs font-medium ml-1 ${getTrendColor()}`}>
              {trend.value > 0 ? "+" : ""}
              {trend.value}%
            </span>
            <span className="text-xs text-stone-500 ml-1">{trend.label}</span>
          </div>
        )}

        {breakdown && (
          <div className="mt-3 space-y-1">
            {breakdown.map((item, index) => (
              <div key={index} className="flex items-center justify-between text-xs">
                <div className="flex items-center">
                  {item.color && <div className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: item.color }} />}
                  <span className="text-stone-600">{item.label}</span>
                </div>
                <span className="font-medium text-stone-900">{item.value}</span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
