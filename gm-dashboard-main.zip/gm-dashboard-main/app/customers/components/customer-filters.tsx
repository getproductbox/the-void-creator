"use client"

import { useState } from "react"
import { Search, Filter, X, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"

interface CustomerFiltersProps {
  searchTerm: string
  onSearchChange: (value: string) => void
  statusFilter: string
  onStatusFilterChange: (value: string) => void
  dateRange?: { from: Date; to: Date }
  onDateRangeChange: (range?: { from: Date; to: Date }) => void
  onClearFilters: () => void
  totalResults: number
}

export function CustomerFilters({
  searchTerm,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  dateRange,
  onDateRangeChange,
  onClearFilters,
  totalResults,
}: CustomerFiltersProps) {
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false)

  const hasActiveFilters = searchTerm !== "" || statusFilter !== "all" || dateRange

  const formatDateRange = (range?: { from: Date; to: Date }) => {
    if (!range) return "Customer since..."

    const formatDate = (date: Date) => {
      return date.toLocaleDateString("en-GB", {
        day: "numeric",
        month: "short",
        year: "numeric",
      })
    }

    if (range.from && range.to) {
      return `${formatDate(range.from)} - ${formatDate(range.to)}`
    } else if (range.from) {
      return `From ${formatDate(range.from)}`
    } else if (range.to) {
      return `Until ${formatDate(range.to)}`
    }
    return "Customer since..."
  }

  return (
    <div className="space-y-4">
      {/* Search and Filter Controls */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-stone-400" />
          <Input
            placeholder="Search by name, email, or phone..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Status Filter */}
        <Select value={statusFilter} onValueChange={onStatusFilterChange}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="All Customers" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Customers</SelectItem>
            <SelectItem value="first-time">First-time</SelectItem>
            <SelectItem value="returning">Returning</SelectItem>
            <SelectItem value="vip">VIP</SelectItem>
          </SelectContent>
        </Select>

        {/* Date Range Picker */}
        <Popover open={isDatePickerOpen} onOpenChange={setIsDatePickerOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full sm:w-64 justify-start text-left font-normal">
              <Calendar className="mr-2 h-4 w-4" />
              {formatDateRange(dateRange)}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              initialFocus
              mode="range"
              defaultMonth={dateRange?.from}
              selected={dateRange}
              onSelect={(range) => {
                if (range?.from && range?.to) {
                  onDateRangeChange({ from: range.from, to: range.to })
                  setIsDatePickerOpen(false)
                } else if (range?.from) {
                  onDateRangeChange({ from: range.from, to: range.from })
                } else {
                  onDateRangeChange(undefined)
                }
              }}
              numberOfMonths={2}
            />
          </PopoverContent>
        </Popover>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button variant="outline" onClick={onClearFilters} className="w-full sm:w-auto">
            <X className="h-4 w-4 mr-2" />
            Clear
          </Button>
        )}
      </div>

      {/* Active Filters and Results */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          {searchTerm && (
            <Badge variant="secondary" className="gap-1">
              Search: {searchTerm}
              <X className="h-3 w-3 cursor-pointer hover:text-stone-700" onClick={() => onSearchChange("")} />
            </Badge>
          )}
          {statusFilter !== "all" && (
            <Badge variant="secondary" className="gap-1">
              Status: {statusFilter}
              <X className="h-3 w-3 cursor-pointer hover:text-stone-700" onClick={() => onStatusFilterChange("all")} />
            </Badge>
          )}
          {dateRange && (
            <Badge variant="secondary" className="gap-1">
              Date: {formatDateRange(dateRange)}
              <X className="h-3 w-3 cursor-pointer hover:text-stone-700" onClick={() => onDateRangeChange(undefined)} />
            </Badge>
          )}
        </div>

        <div className="text-sm text-stone-600">
          Showing {totalResults} customer{totalResults !== 1 ? "s" : ""}
        </div>
      </div>
    </div>
  )
}
