"use client"

import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react"

interface CalendarHeaderProps {
  currentDate: Date
  onPreviousDay: () => void
  onNextDay: () => void
  onToday: () => void
}

export function CalendarHeader({ currentDate, onPreviousDay, onNextDay, onToday }: CalendarHeaderProps) {
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString("en-GB", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const isToday = (date: Date): boolean => {
    const today = new Date()
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  return (
    <div className="flex items-center justify-between bg-white border-b border-stone-200 px-6 py-4">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-orange-500" />
          <h1 className="text-2xl font-bold text-stone-900">Calendar</h1>
        </div>
        <div className="text-lg text-stone-600">{formatDate(currentDate)}</div>
      </div>

      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={onPreviousDay} className="h-9 w-9 p-0">
          <ChevronLeft className="h-4 w-4" />
          <span className="sr-only">Previous day</span>
        </Button>

        <Button
          variant={isToday(currentDate) ? "default" : "outline"}
          size="sm"
          onClick={onToday}
          className={isToday(currentDate) ? "bg-orange-500 hover:bg-orange-600" : ""}
        >
          Today
        </Button>

        <Button variant="outline" size="sm" onClick={onNextDay} className="h-9 w-9 p-0">
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Next day</span>
        </Button>
      </div>
    </div>
  )
}
