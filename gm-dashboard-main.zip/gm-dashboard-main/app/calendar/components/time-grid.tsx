"use client"

import React from "react"

import { BookingBlock } from "./booking-block"
import type { CalendarBooking, CalendarResource } from "../../../mock-data/calendar"
import { generateTimeSlots, getTimeSlotPosition, getBookingDuration } from "../../../mock-data/calendar"

interface TimeGridProps {
  resources: CalendarResource[]
  bookings: CalendarBooking[]
  onBookingClick: (booking: CalendarBooking) => void
  onSlotClick: (resourceId: string, time: string) => void
}

export function TimeGrid({ resources, bookings, onBookingClick, onSlotClick }: TimeGridProps) {
  const timeSlots = generateTimeSlots()
  const SLOT_HEIGHT = 60 // Height of each hour slot in pixels

  const formatTime = (time: string): string => {
    const [hours, minutes] = time.split(":")
    const hour = Number.parseInt(hours)
    const ampm = hour >= 12 ? "PM" : "AM"
    const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
    return `${displayHour}:${minutes} ${ampm}`
  }

  const getBookingStyle = (booking: CalendarBooking): React.CSSProperties => {
    const startPosition = getTimeSlotPosition(booking.startTime)
    const duration = getBookingDuration(booking.startTime, booking.endTime)

    // Handle fractional hours (e.g., 30 minutes = 0.5 hours)
    const startMinutes = Number.parseInt(booking.startTime.split(":")[1])
    const minuteOffset = (startMinutes / 60) * SLOT_HEIGHT

    return {
      top: `${startPosition * SLOT_HEIGHT + minuteOffset}px`,
      height: `${duration * SLOT_HEIGHT - 4}px`, // -4px for gap between bookings
      zIndex: 10,
    }
  }

  const getResourceBookings = (resourceId: string): CalendarBooking[] => {
    return bookings.filter((booking) => booking.resourceId === resourceId)
  }

  return (
    <div className="flex-1 overflow-auto bg-white">
      <div className="min-w-[800px]">
        {/* Grid container */}
        <div
          className="grid gap-0 border-l border-stone-200"
          style={{
            gridTemplateColumns: `120px repeat(${resources.length}, 1fr)`,
          }}
        >
          {/* Header row */}
          <div className="sticky top-0 bg-white border-b border-stone-200 p-4 z-20">
            <span className="text-sm font-medium text-stone-600">Time</span>
          </div>
          {resources.map((resource) => (
            <div key={resource.id} className="sticky top-0 bg-white border-b border-l border-stone-200 p-4 z-20">
              <div className="text-sm font-semibold text-stone-900 truncate">{resource.name}</div>
              <div className="text-xs text-stone-500">Capacity: {resource.capacity}</div>
            </div>
          ))}

          {/* Time slots and resource columns */}
          {timeSlots.map((time, timeIndex) => (
            <React.Fragment key={time}>
              {/* Time column */}
              <div className="border-b border-stone-100 p-4 bg-stone-50" style={{ height: `${SLOT_HEIGHT}px` }}>
                <span className="text-sm text-stone-600">{formatTime(time)}</span>
              </div>

              {/* Resource columns */}
              {resources.map((resource) => (
                <div
                  key={`${resource.id}-${time}`}
                  className="relative border-b border-l border-stone-100 hover:bg-stone-50 cursor-pointer transition-colors"
                  style={{ height: `${SLOT_HEIGHT}px` }}
                  onClick={() => onSlotClick(resource.id, time)}
                >
                  {/* Render bookings for this resource - only on first time slot to avoid duplicates */}
                  {timeIndex === 0 && (
                    <>
                      {getResourceBookings(resource.id).map((booking) => (
                        <BookingBlock
                          key={booking.id}
                          booking={booking}
                          onClick={onBookingClick}
                          style={getBookingStyle(booking)}
                        />
                      ))}
                    </>
                  )}
                </div>
              ))}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  )
}
