import type React from "react"
import type { Metadata } from "next"
import ClientLayout from "./client-layout"
import { Plus_Jakarta_Sans } from "next/font/google"

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-plus-jakarta-sans",
  weight: ["300", "400", "500", "600", "700", "800"],
})

export const metadata: Metadata = {
  title: "GM Admin - Venue Management Platform",
  description: "Staff dashboard and management system for GM venue operations",
  icons: {
    icon: "/favicon.png",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <ClientLayout className={plusJakartaSans.variable}>{children}</ClientLayout>
}


import './globals.css'