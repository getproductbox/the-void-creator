"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Eye, AlertTriangle, CheckCircle, Clock } from "lucide-react"

interface AvailabilityPreviewProps {
  activeTab: string
}

export function AvailabilityPreview({ activeTab }: AvailabilityPreviewProps) {
  const getPreviewContent = () => {
    switch (activeTab) {
      case "operating-hours":
        return {
          title: "Operating Hours Preview",
          description: "How customers will see your opening times",
          content: (
            <div className="space-y-3">
              <div className="text-sm">
                <div className="font-medium mb-2">This Week's Hours:</div>
                <div className="space-y-1 text-stone-600">
                  <div className="flex justify-between">
                    <span>Monday</span>
                    <span>12:00 PM - 11:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tuesday</span>
                    <span>12:00 PM - 11:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Wednesday</span>
                    <span>12:00 PM - 11:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Thursday</span>
                    <span>12:00 PM - 12:00 AM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Friday</span>
                    <span>12:00 PM - 1:00 AM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Saturday</span>
                    <span>11:00 AM - 1:00 AM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday</span>
                    <span>12:00 PM - 10:00 PM</span>
                  </div>
                </div>
              </div>
            </div>
          ),
        }
      case "blackout-dates":
        return {
          title: "Blackout Dates Impact",
          description: "Dates unavailable for customer booking",
          content: (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                <span>3 upcoming blackout dates</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="p-2 bg-red-50 rounded text-red-800">
                  <div className="font-medium">Jan 1, 2025</div>
                  <div className="text-xs">New Year's Day - All rooms</div>
                </div>
                <div className="p-2 bg-blue-50 rounded text-blue-800">
                  <div className="font-medium">Jan 15-16, 2025</div>
                  <div className="text-xs">Maintenance - Rooms 1 & 2</div>
                </div>
                <div className="p-2 bg-purple-50 rounded text-purple-800">
                  <div className="font-medium">Feb 14, 2025</div>
                  <div className="text-xs">Private Event - Main Venue</div>
                </div>
              </div>
            </div>
          ),
        }
      case "room-settings":
        return {
          title: "Room Availability",
          description: "Current room status and booking limits",
          content: (
            <div className="space-y-3">
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                  <span className="font-medium">Main Venue</span>
                  <Badge className="bg-green-100 text-green-800">Active</Badge>
                </div>
                <div className="text-xs text-stone-600 ml-2">Capacity: 150 • 2-8h bookings • 90 days advance</div>

                <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                  <span className="font-medium">Karaoke Room 1</span>
                  <Badge className="bg-green-100 text-green-800">Active</Badge>
                </div>
                <div className="text-xs text-stone-600 ml-2">Capacity: 12 • 1-4h bookings • 30 days advance</div>

                <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                  <span className="font-medium">Karaoke Room 2</span>
                  <Badge className="bg-green-100 text-green-800">Active</Badge>
                </div>
                <div className="text-xs text-stone-600 ml-2">Capacity: 8 • 1-4h bookings • 30 days advance</div>

                <div className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                  <span className="font-medium">Karaoke Room 3</span>
                  <Badge className="bg-yellow-100 text-yellow-800">Maintenance</Badge>
                </div>
                <div className="text-xs text-stone-600 ml-2">Temporarily unavailable for booking</div>
              </div>
            </div>
          ),
        }
      case "special-events":
        return {
          title: "Event Conflicts",
          description: "Special events affecting availability",
          content: (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Clock className="h-4 w-4 text-blue-500" />
                <span>3 upcoming special events</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="p-2 bg-blue-50 rounded text-blue-800">
                  <div className="font-medium">Jan 25, 2025</div>
                  <div className="text-xs">Corporate Event - Main Venue</div>
                  <div className="text-xs">6:00 PM - 10:00 PM</div>
                </div>
                <div className="p-2 bg-purple-50 rounded text-purple-800">
                  <div className="font-medium">Feb 8, 2025</div>
                  <div className="text-xs">Birthday Party - Rooms 1 & 2</div>
                  <div className="text-xs">3:00 PM - 6:00 PM</div>
                </div>
                <div className="p-2 bg-green-50 rounded text-green-800">
                  <div className="font-medium">Weekly League</div>
                  <div className="text-xs">Every Monday - Room 3</div>
                  <div className="text-xs">7:00 PM - 10:00 PM</div>
                </div>
              </div>
            </div>
          ),
        }
      default:
        return {
          title: "Availability Preview",
          description: "Live preview of your availability settings",
          content: (
            <div className="text-center py-8 text-stone-500">
              <Eye className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Select a tab to see preview</p>
            </div>
          ),
        }
    }
  }

  const preview = getPreviewContent()

  return (
    <div className="space-y-4 sticky top-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            {preview.title}
          </CardTitle>
          <CardDescription>{preview.description}</CardDescription>
        </CardHeader>
        <CardContent>{preview.content}</CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Customer Impact</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <span>No conflicts with existing bookings</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            <span>Changes will affect 12 future bookings</span>
          </div>
          <Button variant="outline" size="sm" className="w-full">
            <Eye className="h-4 w-4 mr-2" />
            Preview Customer View
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
